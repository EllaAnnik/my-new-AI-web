// Pitchlords SPA. All DOM is built with textContent — no untrusted HTML is injected.
import { mount } from './football.js';
import { mount as mountMatches } from './matches.js';
const $app = document.getElementById('app');
const state = { user: null, clubs: [], unread: 0, notifs: [], popOpen: false, es: null };

// ---------- helpers ----------
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'class') el.className = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return el;
}
async function api(method, path, body) {
  const res = await fetch('/api' + path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  let json = {};
  try { json = await res.json(); } catch { /* empty */ }
  if (!res.ok) { const e = new Error(json.error || `Request failed (${res.status})`); e.status = res.status; e.code = json.code; throw e; }
  return json;
}
const money = (n) => '£' + Number(n).toLocaleString('en-GB');
const HEX = /^#[0-9a-fA-F]{6}$/;
function crest(club, cls = 'crest') {
  const c1 = HEX.test(club.color1) ? club.color1 : '#333', c2 = HEX.test(club.color2) ? club.color2 : '#999';
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', '0 0 64 64'); svg.setAttribute('class', cls); svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', club.name + ' crest');
  const mk = (t, a) => { const e = document.createElementNS(NS, t); for (const k in a) e.setAttribute(k, a[k]); svg.append(e); return e; };
  mk('path', { d: 'M32 3 55 11v22c0 14-10 23-23 28C19 56 9 47 9 33V11z', fill: c1 });
  mk('path', { d: 'M32 3 55 11v22c0 14-10 23-23 28z', fill: c2, opacity: '.28' });
  mk('path', { d: 'M32 3 55 11v22c0 14-10 23-23 28C19 56 9 47 9 33V11z', fill: 'none', stroke: c2, 'stroke-width': '3' });
  const t = mk('text', { x: 32, y: 39, 'text-anchor': 'middle', 'font-size': 17, 'font-weight': 900, fill: '#fff', style: 'paint-order:stroke;stroke:#0008;stroke-width:3px' });
  t.textContent = club.short_name;
  return svg;
}
function toast(title, body) {
  const t = h('div', { class: 'toast' }, h('b', {}, title), body ? h('div', { class: 'mute' }, body) : null);
  const box = document.getElementById('toasts');
  box.append(t);
  while (box.children.length > 3) box.firstChild.remove();
  setTimeout(() => t.remove(), 5000);
}
const brandMark = () => {
  const NS = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 32 32');
  const p = document.createElementNS(NS, 'path'); p.setAttribute('d', 'M16 3l11 5v9c0 6-5 10-11 12C10 27 5 23 5 17V8z'); p.setAttribute('fill', '#c6ff3d'); s.append(p);
  return s;
};

// ---------- auth ----------
function renderAuth(mode = 'login', error = '') {
  const isReg = mode === 'register';
  const form = h('form', { onsubmit: async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    const btn = e.target.querySelector('button.btn'); btn.disabled = true;
    try {
      await api('POST', isReg ? '/auth/register' : '/auth/login', f);
      await boot();
    } catch (err) { renderAuth(mode, err.message); }
  } },
    isReg ? [h('label', { for: 'email' }, 'Email'), h('input', { id: 'email', name: 'email', type: 'email', required: true, autocomplete: 'email' })] : null,
    h('label', { for: 'u' }, isReg ? 'Manager name' : 'Email or manager name'),
    h('input', { id: 'u', name: isReg ? 'username' : 'identifier', required: true, autocomplete: 'username', minlength: isReg ? 3 : 1, maxlength: 120 }),
    h('label', { for: 'p' }, 'Password'),
    h('input', { id: 'p', name: 'password', type: 'password', required: true, minlength: isReg ? 8 : 1, autocomplete: isReg ? 'new-password' : 'current-password' }),
    h('div', { class: 'err', role: 'alert' }, error),
    h('button', { class: 'btn', style: 'width:100%;margin-top:.4rem' }, isReg ? 'Create account' : 'Sign in'));
  $app.replaceChildren(h('div', { class: 'auth' }, h('div', { class: 'auth-card' },
    h('div', { class: 'brand' }, brandMark(), 'Pitchlords'),
    h('p', { class: 'mute' }, 'Run a club. Outwit real managers. Build a dynasty.'),
    h('div', { class: 'tabs' },
      h('button', { class: !isReg && 'on', onclick: () => renderAuth('login') }, 'Sign in'),
      h('button', { class: isReg && 'on', onclick: () => renderAuth('register') }, 'Register')),
    form)));
}

// ---------- shell ----------
const NAV = [
  ['home', 'Home', 1], ['club', 'My Club', 2], ['squad', 'Squad', 2], ['tactics', 'Tactics', 2],
  ['fixtures', 'Fixtures', 5], ['competitions', 'Competitions', 5], ['transfers', 'Transfers', 4],
  ['scouting', 'Scouting', 4], ['training', 'Training', 5], ['finances', 'Finances', 4],
  ['worlds', 'Game World', 1], ['messages', 'Messages', 6], ['profile', 'Manager Profile', 1],
];
const LIVE = new Set(['home', 'club', 'squad', 'tactics', 'fixtures', 'competitions', 'worlds', 'profile']);
function activeClubId() {
  const ids = state.clubs.map((c) => c.club_id);
  const saved = Number(localStorage.getItem('pl_club'));
  return ids.includes(saved) ? saved : ids[0] || null;
}
function routeInfo() {
  const [, name = 'home', id] = location.hash.split('/');
  return { name, id: id ? Number(id) : null };
}
function shell(active, title, content) {
  const nav = h('nav', { class: 'nav' }, NAV.map(([key, label, phase]) => {
    const live = LIVE.has(key);
    return h('a', { href: live ? '#/' + key : null, class: (active === key ? 'on ' : '') + (live ? '' : 'off'), 'aria-disabled': live ? null : 'true', title: live ? null : `Arrives in Phase ${phase}`, onclick: live ? null : (e) => e.preventDefault() },
      label, live ? null : h('span', { class: 'tag' }, 'P' + phase));
  }));
  const bell = h('button', { class: 'bell', 'aria-label': 'Notifications', onclick: async () => {
    state.popOpen = !state.popOpen;
    if (state.popOpen) { state.notifs = (await api('GET', '/notifications')).notifications; }
    draw();
    if (state.popOpen && state.unread) { await api('POST', '/notifications/read'); state.unread = 0; }
  } }, '🔔', state.unread ? h('b', {}, state.unread) : null);
  const pop = state.popOpen ? h('div', { class: 'pop' }, state.notifs.length ? state.notifs.map((n) => h('div', { class: 'n' + (n.read ? '' : ' unread') }, h('b', {}, n.title), h('div', { class: 'mute' }, n.body), h('small', {}, n.created_at))) : h('div', { class: 'empty' }, 'No notifications yet')) : null;
  return h('div', { class: 'shell' },
    h('aside', { class: 'side' }, h('div', { class: 'brand' }, brandMark(), 'Pitchlords'), nav),
    h('div', { class: 'main' },
      h('header', { class: 'top' }, h('div', {}, h('div', { class: 'eyebrow' }, 'Manager ' + state.user.username), h('h1', {}, title)), bell),
      pop, h('main', { class: 'page' }, content)));
}
let currentDraw = () => {};
function draw() { currentDraw(); }

// ---------- views ----------
async function viewHome() {
  const me = await api('GET', '/me'); state.clubs = me.clubs; state.unread = me.unread;
  let body;
  if (!state.clubs.length) {
    body = h('div', { class: 'card' }, h('h2', {}, 'You are between jobs'),
      h('p', { class: 'mute' }, 'Pick a Game World and take charge of a club to begin your career.'),
      h('a', { class: 'btn', href: '#/worlds', style: 'display:inline-block;text-decoration:none' }, 'Browse Game Worlds'));
  } else {
    const cards = [];
    for (const m of state.clubs) {
      const { world, clubs } = await api('GET', `/worlds/${m.world_id}`);
      const c = clubs.find((x) => x.id === m.club_id);
      const rank = clubs.filter((x) => x.reputation > c.reputation).length + 1;
      const sched = await api('GET', `/clubs/${m.club_id}/schedule`);
      const mine = new Set([m.club_id]);
      const upcoming = sched.fixtures.filter((f) => f.status === 'scheduled').slice(0, 3);
      const recent = sched.fixtures.filter((f) => f.status === 'played').slice(-5).reverse();
      cards.push(h('div', {},
        h('div', { class: 'hero' }, crest(c),
          h('div', {}, h('div', { class: 'eyebrow' }, `${world.code} · ${world.name} · Season ${world.season}`), h('h1', {}, c.name), h('div', { class: 'mute' }, `${c.stadium_name}, ${c.city}`)),
          h('div', { class: 'sp' }), h('a', { class: 'btn ghost sm', href: '#/worlds/' + world.id }, 'View world')),
        h('div', { class: 'grid g4' },
          stat('Reputation', c.reputation + ' / 100', true, h('div', { class: 'bar' }, h('i', { style: `width:${c.reputation}%` }))),
          stat('Reputation rank', `#${rank} of ${clubs.length}`),
          stat('Stadium capacity', c.stadium_capacity.toLocaleString('en-GB')),
          stat('League position', sched.rounds_played ? `${sched.position}${['th','st','nd','rd'][(sched.position % 100 > 10 && sched.position % 100 < 14) ? 0 : Math.min(sched.position % 10, 4) % 4] || 'th'}` : '–', true, h('div', { class: 'mute', style: 'font-size:.75rem' }, `${sched.rounds_played}/${sched.total_rounds} rounds`)),
          stat('Game date', mt.fmtDate(world.game_date))),
        h('div', { class: 'grid g2', style: 'margin-top:1rem' },
          h('div', { class: 'card' }, h('div', { class: 'row' }, h('h2', {}, 'Upcoming fixtures'), h('div', { class: 'sp' }), h('a', { href: '#/fixtures', class: 'btn ghost sm' }, 'All fixtures')),
            upcoming.length ? upcoming.map((f) => h('div', {}, h('div', { class: 'mute', style: 'font-size:.75rem;margin-top:.5rem' }, `Round ${f.round} · ${mt.fmtDate(f.game_date)}`), mt.fixtureRow(f, mine))) : h('div', { class: 'empty', style: 'margin-top:.8rem' }, 'The season is complete.')),
          h('div', { class: 'card' }, h('h2', {}, 'Recent results'),
            recent.length ? recent.map((f) => h('div', { class: 'row', style: 'margin-top:.4rem' }, mt.resPill(f.result), h('div', { style: 'flex:1;min-width:0' }, mt.fixtureRow(f, mine)))) : h('div', { class: 'empty', style: 'margin-top:.8rem' }, 'No matches played yet. Whoever created the world advances the calendar from Competitions.')))));
    }
    body = h('div', { class: 'grid' }, cards);
  }
  return shell('home', 'Home', body);
}
function stat(label, value, lime, extra) {
  return h('div', { class: 'card stat' }, h('div', { class: 'eyebrow' }, label), h('div', { class: 'v' + (lime ? ' lime' : '') }, value), extra);
}

async function viewWorlds() {
  const { worlds } = await api('GET', '/worlds');
  let createErr = h('div', { class: 'err', role: 'alert' });
  const form = h('form', { class: 'card', onsubmit: async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    try { const r = await api('POST', '/worlds', { name: f.name, clubs: Number(f.clubs) }); location.hash = '#/worlds/' + r.world_id; }
    catch (err) { createErr.textContent = err.message; }
  } },
    h('h2', {}, 'Create a new world'),
    h('label', { for: 'wn' }, 'World name'), h('input', { id: 'wn', name: 'name', required: true, minlength: 3, maxlength: 40, placeholder: 'e.g. Premier Division' }),
    h('label', { for: 'wc' }, 'Number of clubs'), h('select', { id: 'wc', name: 'clubs' }, [8, 12, 16, 20, 24].map((n) => h('option', { value: n, selected: n === 20 }, n))),
    createErr, h('button', { class: 'btn', style: 'margin-top:.6rem' }, 'Create world'));
  const list = worlds.length ? worlds.map((w) => h('a', { class: 'card', href: '#/worlds/' + w.id, style: 'text-decoration:none;color:inherit' },
    h('div', { class: 'row' }, h('span', { class: 'eyebrow' }, w.code), h('div', { class: 'sp' }), w.my_club_id ? h('span', { class: 'pill you' }, 'Your club') : null),
    h('h2', { style: 'margin:.3rem 0' }, w.name),
    h('div', { class: 'mute' }, `Season ${w.season} · ${w.game_date}`),
    h('div', { class: 'bar', style: 'margin:.8rem 0 .4rem' }, h('i', { style: `width:${(w.human_count / w.club_count) * 100}%` })),
    h('div', { class: 'row' }, h('span', { class: 'pill human' }, `${w.human_count} human`), h('span', { class: 'pill ai' }, `${w.club_count - w.human_count} open / AI`)))) : [h('div', { class: 'empty' }, 'No worlds exist yet — create the first one.')];
  return shell('worlds', 'Game Worlds', h('div', { class: 'grid' }, h('div', { class: 'grid g3' }, list), form));
}

async function viewWorld(id) {
  const { world, clubs, my_club_id } = await api('GET', `/worlds/${id}`);
  const claim = async (clubId) => {
    try { await api('POST', `/worlds/${id}/join`, clubId ? { club_id: clubId } : {}); toast('Club claimed', 'You are now a manager.'); }
    catch (err) { toast('Could not claim club', err.message); }
    await rerender();
  };
  const free = clubs.filter((c) => !c.manager_user_id).length;
  const head = h('div', { class: 'hero' },
    h('div', {}, h('div', { class: 'eyebrow' }, world.code), h('h1', {}, world.name), h('div', { class: 'mute' }, `Season ${world.season} · ${world.game_date} · ${clubs.length - free} human managers · ${free} clubs open`)),
    h('div', { class: 'sp' }), h('a', { class: 'btn ghost sm', href: '#/competitions/' + world.id }, 'League table'),
    my_club_id
      ? h('button', { class: 'btn danger sm', onclick: async () => { if (confirm('Resign from your club? It will be handed to an AI manager.')) { await api('POST', `/worlds/${id}/leave`); await rerender(); } } }, 'Resign')
      : h('button', { class: 'btn', disabled: !free, onclick: () => claim() }, 'Assign me a random club'));
  const cards = clubs.map((c) => {
    const mine = c.id === my_club_id;
    return h('div', { class: 'card club' + (mine ? ' mine' : '') }, crest(c),
      h('div', { style: 'min-width:0;flex:1' },
        h('b', {}, c.name),
        h('div', { class: 'mute', style: 'font-size:.82rem' }, `Rep ${c.reputation} · ${c.stadium_capacity.toLocaleString('en-GB')} seats`),
        h('div', { style: 'margin-top:.35rem' }, c.manager_user_id ? h('span', { class: 'pill ' + (mine ? 'you' : 'human') }, mine ? 'You' : c.manager_username) : h('span', { class: 'pill ai' }, 'AI · ' + c.ai_manager_name))),
      h('div', { class: 'grid', style: 'gap:.4rem' },
        !c.manager_user_id && !my_club_id ? h('button', { class: 'btn sm', onclick: () => claim(c.id) }, 'Manage') : null,
        h('a', { class: 'btn ghost sm', href: mine ? '#/squad' : '#/squad/' + c.id }, 'Squad')));
  });
  return shell('worlds', 'Game World', h('div', {}, h('a', { href: '#/worlds', class: 'mute' }, '← All worlds'), h('div', { style: 'height:.8rem' }), head, h('div', { class: 'grid g3' }, cards)));
}

async function viewProfile() {
  const me = await api('GET', '/me'); state.clubs = me.clubs;
  const blocks = [
    h('div', { class: 'hero' }, h('div', {}, h('div', { class: 'eyebrow' }, me.user.role), h('h1', {}, me.user.username), h('div', { class: 'mute' }, me.user.email)),
      h('div', { class: 'sp' }), h('button', { class: 'btn ghost', onclick: async () => { await api('POST', '/auth/logout'); state.user = null; if (state.es) state.es.close(); renderAuth(); } }, 'Sign out')),
    h('div', { class: 'card' }, h('h2', {}, 'Clubs managed'),
      me.clubs.length ? h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Club', 'World'].map((t) => h('th', {}, t)))), h('tbody', {}, me.clubs.map((c) => h('tr', {}, h('td', {}, c.club_name), h('td', {}, h('a', { href: '#/worlds/' + c.world_id }, `${c.world_code} ${c.world_name}`))))))) : h('div', { class: 'empty', style: 'margin-top:.8rem' }, 'No clubs yet.')),
  ];
  if (['admin', 'moderator'].includes(me.user.role)) blocks.push(await adminPanel(me.user.role === 'admin'));
  return shell('profile', 'Manager Profile', h('div', { class: 'grid' }, blocks));
}
async function adminPanel(isAdmin) {
  const { users } = await api('GET', '/admin/users');
  const rows = users.map((u) => h('tr', {}, h('td', {}, u.username), h('td', {}, u.role), h('td', {}, u.status + (u.suspended_reason ? ` (${u.suspended_reason})` : '')),
    h('td', {}, u.role === 'admin' ? '' : u.status === 'active'
      ? h('button', { class: 'btn danger sm', onclick: async () => { const reason = prompt('Reason for suspension?'); if (!reason) return; try { await api('POST', `/admin/users/${u.id}/suspend`, { reason }); await rerender(); } catch (e) { toast('Failed', e.message); } } }, 'Suspend')
      : (isAdmin ? h('button', { class: 'btn ghost sm', onclick: async () => { await api('POST', `/admin/users/${u.id}/restore`); await rerender(); } }, 'Restore') : ''))));
  const out = [h('div', { class: 'card' }, h('h2', {}, 'Administration · users'), h('div', { class: 'tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['User', 'Role', 'Status', ''].map((t) => h('th', {}, t)))), h('tbody', {}, rows))))];
  if (isAdmin) {
    const { entries } = await api('GET', '/admin/audit');
    const head = h('thead', {}, h('tr', {}, ['When', 'Actor', 'Action', 'Target', 'Detail'].map((t) => h('th', {}, t))));
    const auditRows = entries.slice(0, 30).map((e) => h('tr', {},
      h('td', {}, e.created_at), h('td', {}, e.actor_id ?? '—'), h('td', {}, e.action),
      h('td', {}, e.target || ''), h('td', {}, e.detail || '')));
    out.push(h('div', { class: 'card' }, h('h2', {}, 'Audit log'),
      h('div', { class: 'tablewrap' }, h('table', {}, head, h('tbody', {}, auditRows)))));
  }
  return h('div', { class: 'grid' }, out);
}

// ---------- routing / boot ----------
async function rerender() {
  if (!state.user) return;
  const { name, id } = routeInfo();
  currentDraw = rerender;
  if (state.cleanup) { state.cleanup(); state.cleanup = null; }
  try {
    const me = await api('GET', '/me');
    state.clubs = me.clubs; state.unread = me.unread;
    let view;
    if (name === 'club') view = await fb.club(activeClubId());
    else if (name === 'squad') view = await fb.squad(activeClubId(), id);
    else if (name === 'tactics') view = await fb.tactics(activeClubId());
    else if (name === 'fixtures') view = await mt.fixtures(activeClubId());
    else if (name === 'competitions') view = await mt.competitions(id, activeClubId());
    else if (name === 'match' && id) view = await mt.match(id);
    else if (name === 'worlds' && id) view = await viewWorld(id);
    else if (name === 'worlds') view = await viewWorlds();
    else if (name === 'profile') view = await viewProfile();
    else view = await viewHome();
    $app.replaceChildren(view);
  } catch (err) {
    if (err.status === 401) { state.user = null; return renderAuth(); }
    $app.replaceChildren(shell('home', 'Something went wrong', h('div', { class: 'card' }, err.message)));
  }
}
const fb = mount({ h, api, money, crest, toast, shell, state, rerender: () => rerender() });
const mt = mountMatches({ h, api, money, crest, toast, shell, state, rerender: () => rerender() });
function connectEvents() {
  if (state.es) state.es.close();
  const es = (state.es = new EventSource('/api/events'));
  es.addEventListener('notification', (e) => { const n = JSON.parse(e.data); state.unread++; toast(n.title, n.body); if (routeInfo().name !== 'match') rerender(); });
  es.addEventListener('competition_changed', () => { if (['competitions', 'fixtures', 'home'].includes(routeInfo().name) && !state.popOpen) rerender(); });
  for (const ev of ['worlds_changed', 'world_changed']) es.addEventListener(ev, () => { if (!state.popOpen && ['worlds'].includes(routeInfo().name)) rerender(); });
}
async function boot() {
  try {
    const me = await api('GET', '/me');
    state.user = me.user; state.clubs = me.clubs; state.unread = me.unread;
  } catch { state.user = null; return renderAuth(); }
  connectEvents();
  if (!location.hash) location.hash = '#/home';
  await rerender();
}
addEventListener('hashchange', () => { state.popOpen = false; rerender(); });
boot();
