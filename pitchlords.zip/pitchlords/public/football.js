// Phase 2 views: My Club, Squad, Tactics. Helpers are injected by app.js (mount).
export function mount(ctx) {
  const { h, api, money, crest, toast, shell, state } = ctx;
  const GROUPS = { ALL: null, GK: ['GK'], DEF: ['CB', 'LB', 'RB'], MID: ['DM', 'CM', 'AM', 'LM', 'RM'], FWD: ['LW', 'RW', 'ST'] };
  const ATTR_LABEL = (k) => k.replace(/^gk_/, '').replace(/_/g, ' ');
  const ATTR_GROUPS = {
    Technical: ['passing', 'shooting', 'finishing', 'dribbling', 'ball_control', 'crossing', 'tackling', 'marking', 'heading', 'long_shots', 'set_pieces'],
    Physical: ['pace', 'acceleration', 'strength', 'stamina', 'agility', 'jumping'],
    Mental: ['positioning', 'vision', 'decisions', 'anticipation', 'composure', 'concentration', 'work_rate', 'leadership'],
    Goalkeeping: ['gk_reflexes', 'gk_handling', 'gk_positioning', 'gk_diving', 'gk_aerial', 'gk_distribution'],
  };
  const tone = (v) => (v >= 75 ? 'hi' : v >= 60 ? 'good' : v >= 45 ? 'mid' : 'lo');
  const label = (s) => s.replace(/_/g, ' ').replace(/^./, (c) => c.toUpperCase());
  const badge = (v) => h('span', { class: 'ovr ' + tone(v) }, v);
  const fullName = (p) => `${p.first_name[0]}. ${p.last_name}`;

  function noClub() {
    return shell('club', 'No club', h('div', { class: 'card' }, h('h2', {}, 'You are between jobs'), h('p', { class: 'mute' }, 'Take over a club in a Game World first.'),
      h('a', { class: 'btn', href: '#/worlds' }, 'Browse Game Worlds')));
  }
  function clubSwitcher(current) {
    if (state.clubs.length < 2) return null;
    const sel = h('select', { 'aria-label': 'Switch club', style: 'width:auto', onchange: (e) => { localStorage.setItem('pl_club', e.target.value); location.hash = location.hash.replace(/\/\d+$/, ''); ctx.rerender(); } },
      state.clubs.map((c) => h('option', { value: c.club_id, selected: c.club_id === current }, `${c.club_name} (${c.world_code})`)));
    return sel;
  }

  // ---------------- My Club ----------------
  async function club(clubId) {
    if (!clubId) return noClub();
    const sq = await api('GET', `/clubs/${clubId}/squad`);
    const c = sq.club, s = sq.summary;
    const youth = sq.players.filter((p) => p.is_youth);
    const promote = async (p) => { try { await api('POST', `/clubs/${clubId}/players/${p.id}/promote`); toast('Promoted', `${p.last_name} joins the first team.`); } catch (e) { toast('Cannot promote', e.message); } ctx.rerender(); };
    const best = sq.players.filter((p) => !p.is_youth).slice(0, 5);
    const led = (await api('GET', `/clubs/${clubId}/ledger`)).entries.slice(0, 8);
    return shell('club', 'My Club', h('div', { class: 'grid' },
      h('div', { class: 'hero' }, crest(c), h('div', {}, h('div', { class: 'eyebrow' }, 'Club overview'), h('h1', {}, c.name), h('div', { class: 'mute' }, `${c.stadium_name} · ${c.stadium_capacity.toLocaleString('en-GB')} seats`)), h('div', { class: 'sp' }), clubSwitcher(clubId)),
      h('div', { class: 'grid g4' },
        stat('Bank balance', money(c.balance), true), stat('Squad rating', s.avg_overall, false, 'average OVR'), stat('Average age', s.avg_age),
        stat('Fitness', s.avg_fitness + '%'), stat('Morale', s.avg_morale + '%'), stat('Weekly wage bill', money(s.weekly_wage_bill)), stat('Squad value', money(s.squad_value)), stat('Unavailable', s.injured, false, 'injured / suspended')),
      h('div', { class: 'grid g2' },
        h('div', { class: 'card' }, h('h2', {}, 'Key players'), h('div', { class: 'tablewrap' }, h('table', {}, h('tbody', {}, best.map((p) => h('tr', {}, h('td', {}, p.position), h('td', {}, `${p.first_name} ${p.last_name}`), h('td', {}, badge(p.overall)), h('td', { class: 'mute' }, 'POT ' + p.potential))))))),
        h('div', { class: 'card' }, h('h2', {}, 'Youth academy'), h('p', { class: 'mute', style: 'margin:.3rem 0 .8rem' }, 'Academy players cannot be picked until promoted to the first team.'),
          youth.length ? youth.map((p) => h('div', { class: 'row', style: 'padding:.45rem 0;border-top:1px solid var(--line)' },
            h('span', { class: 'pill' }, p.position), h('div', {}, h('b', {}, `${p.first_name} ${p.last_name}`), h('div', { class: 'mute', style: 'font-size:.8rem' }, `Age ${p.age} · ${p.nationality}`)),
            h('div', { class: 'sp' }), h('span', { class: 'mute' }, `${p.overall} → `), h('b', {}, p.potential), h('button', { class: 'btn sm', onclick: () => promote(p) }, 'Promote')))
            : h('div', { class: 'empty' }, 'No academy players.'))),
      h('div', { class: 'card' }, h('h2', {}, 'Recent transactions'),
        led.length ? h('div', { class: 'tablewrap' }, h('table', {}, h('tbody', {}, led.map((e) => h('tr', {}, h('td', { class: 'mute' }, e.created_at), h('td', {}, e.description), h('td', { style: 'color:' + (e.amount < 0 ? 'var(--red)' : 'var(--lime)') }, (e.amount < 0 ? '−' : '+') + money(Math.abs(e.amount))), h('td', { class: 'mute' }, money(e.balance_after)))))))
          : h('div', { class: 'empty', style: 'margin-top:.8rem' }, 'No transactions yet. Contract renewals and releases appear here.')),
      h('div', { class: 'row' }, h('a', { class: 'btn', href: '#/squad' }, 'Open squad'), h('a', { class: 'btn ghost', href: '#/tactics' }, 'Set tactics'))));
  }
  function stat(lbl, value, lime, sub) {
    return h('div', { class: 'card stat' }, h('div', { class: 'eyebrow' }, lbl), h('div', { class: 'v' + (lime ? ' lime' : '') }, value), sub ? h('div', { class: 'mute', style: 'font-size:.75rem' }, sub) : null);
  }

  // ---------------- Squad ----------------
  async function squad(clubId, viewingId) {
    const id = viewingId || clubId;
    if (!id) return noClub();
    const sq = await api('GET', `/clubs/${id}/squad`);
    const mine = sq.mine;
    let group = 'ALL', sortKey = 'overall', sortDir = -1, selected = null;
    const root = h('div');
    const cols = mine
      ? [['shirt_number', '#'], ['position', 'Pos'], ['last_name', 'Name'], ['age', 'Age'], ['nationality', 'Nat'], ['overall', 'OVR'], ['potential', 'POT'], ['fitness', 'Fit'], ['morale', 'Mor'], ['wage', 'Wage/wk'], ['value', 'Value'], ['contract_expires', 'Contract']]
      : [['shirt_number', '#'], ['position', 'Pos'], ['last_name', 'Name'], ['age', 'Age'], ['nationality', 'Nat'], ['overall', 'OVR'], ['value', 'Value'], ['contract_expires', 'Contract']];
    const status = (p) => (p.is_youth ? 'Youth' : !p.available ? 'Unavailable' : p.transfer_listed ? 'Listed' : '');
    function draw() {
      let list = sq.players.filter((p) => group === 'YOUTH' ? p.is_youth : !p.is_youth && (!GROUPS[group] || GROUPS[group].includes(p.position)));
      list = [...list].sort((a, b) => (a[sortKey] > b[sortKey] ? 1 : a[sortKey] < b[sortKey] ? -1 : 0) * sortDir);
      const filters = h('div', { class: 'row' }, [...Object.keys(GROUPS), 'YOUTH'].map((g) => h('button', { class: 'chip' + (g === group ? ' on' : ''), onclick: () => { group = g; draw(); } }, g === 'ALL' ? 'All' : g === 'YOUTH' ? 'Youth' : g)));
      const head = h('thead', {}, h('tr', {}, cols.map(([k, t]) => h('th', { class: 'sortable', onclick: () => { sortDir = sortKey === k ? -sortDir : -1; sortKey = k; draw(); } }, t + (sortKey === k ? (sortDir < 0 ? ' ↓' : ' ↑') : ''))), h('th', {}, '')));
      const rows = list.map((p) => h('tr', { class: 'clickable' + (selected === p.id ? ' sel' : ''), tabindex: 0, onclick: () => { selected = p.id; draw(); }, onkeydown: (e) => { if (e.key === 'Enter') { selected = p.id; draw(); } } },
        cols.map(([k]) => {
          if (k === 'last_name') return h('td', {}, `${p.first_name} ${p.last_name}`);
          if (k === 'overall' || k === 'potential') return h('td', {}, badge(p[k]));
          if (k === 'wage' || k === 'value') return h('td', {}, money(p[k]));
          if (k === 'fitness' || k === 'morale') return h('td', {}, p[k] + '%');
          return h('td', {}, p[k]);
        }), h('td', {}, status(p) ? h('span', { class: 'pill' + (status(p) === 'Unavailable' ? ' bad' : '') }, status(p)) : '')));
      const sel = sq.players.find((p) => p.id === selected);
      root.replaceChildren(
        h('div', { class: 'hero' }, crest(sq.club), h('div', {}, h('div', { class: 'eyebrow' }, mine ? 'Your squad' : 'Scouting view — public information only'), h('h1', {}, sq.club.name)), h('div', { class: 'sp' }), mine ? clubSwitcher(id) : h('a', { class: 'btn ghost sm', href: `#/worlds/${sq.club.world_id}` }, '← World')),
        filters, h('div', { class: 'split' },
          h('div', { class: 'card tablewrap' }, h('table', {}, head, h('tbody', {}, rows)), list.length ? null : h('div', { class: 'empty' }, 'No players in this group.')),
          sel ? detail(sel) : h('div', { class: 'card empty' }, 'Select a player to see his attributes.')));
    }
    // Contract dialog: every number comes from the server quote; the server re-validates on submit.
    async function contractDialog(p, act) {
      let years = 3, q;
      const body = h('div');
      const overlay = h('div', { class: 'overlay', onclick: (e) => { if (e.target === overlay) overlay.remove(); } }, h('div', { class: 'modal card', role: 'dialog', 'aria-label': 'Contract' }, body));
      document.body.append(overlay);
      async function load() {
        q = await api('GET', `/clubs/${id}/players/${p.id}/contract-quote?years=${years}`);
        const wageIn = h('input', { type: 'number', min: 1, value: q.demand_wage, id: 'wage-in' });
        body.replaceChildren(
          h('h2', {}, `${p.first_name} ${p.last_name}`),
          h('p', { class: 'mute' }, `Currently ${money(q.current_wage)}/wk until ${p.contract_expires}. Club balance ${money(q.balance)}.`),
          h('h3', { style: 'margin-top:1rem' }, 'Renew contract'),
          q.can_renew ? h('div', {},
            h('label', {}, 'Length'), h('select', { onchange: (e) => { years = Number(e.target.value); load(); } }, [1, 2, 3, 4, 5].map((y) => h('option', { value: y, selected: y === years }, `${y} year${y > 1 ? 's' : ''}`))),
            h('label', { for: 'wage-in' }, `Weekly wage (he asks for ${money(q.demand_wage)})`), wageIn,
            h('div', { class: 'mute', style: 'font-size:.8rem;margin-top:.4rem' }, 'Loyalty bonus payable now: four weeks of the new wage.'),
            h('button', { class: 'btn', style: 'margin-top:.7rem', onclick: async () => { try { const r = await api('POST', `/clubs/${id}/players/${p.id}/renew`, { years, wage: Number(wageIn.value) }); overlay.remove(); act(async () => r, `Renewed until ${r.contract_expires}`); } catch (e) { toast('Renewal refused', e.message); } } }, 'Offer contract'))
            : h('div', { class: 'empty' }, q.renew_block),
          h('h3', { style: 'margin-top:1.2rem' }, 'Release player'),
          q.can_release ? h('div', {}, h('p', { class: 'mute', style: 'font-size:.85rem' }, `Contract settlement: ${money(q.release_cost)}. He leaves immediately and becomes a free agent.`),
            h('button', { class: 'btn danger sm', onclick: async () => { if (!confirm(`Release ${p.last_name} for ${money(q.release_cost)}?`)) return; try { const r = await api('POST', `/clubs/${id}/players/${p.id}/release`); overlay.remove(); selected = null; act(async () => r, 'Player released'); } catch (e) { toast('Cannot release', e.message); } } }, 'Release'))
            : h('div', { class: 'empty' }, q.release_block),
          h('div', { style: 'margin-top:1rem' }, h('button', { class: 'btn ghost sm', onclick: () => overlay.remove() }, 'Close')));
      }
      try { await load(); } catch (e) { overlay.remove(); toast('Unavailable', e.message); }
    }
    function detail(p) {
      const act = async (fn, okMsg) => { try { await fn(); toast(okMsg); } catch (e) { toast('Failed', e.message); } sq.players = (await api('GET', `/clubs/${id}/squad`)).players; draw(); };
      const attrBlock = (name, keys) => h('div', { style: 'margin-top:.8rem' }, h('div', { class: 'eyebrow' }, name),
        keys.map((k) => h('div', { class: 'attr' }, h('span', {}, label(ATTR_LABEL(k))), h('div', { class: 'bar' }, h('i', { class: tone(p.attrs[k]), style: `width:${p.attrs[k]}%` })), h('b', {}, p.attrs[k]))));
      return h('div', { class: 'card detail' },
        h('div', { class: 'row' }, h('span', { class: 'pill' }, p.position), h('h2', {}, `${p.first_name} ${p.last_name}`), h('div', { class: 'sp' }), badge(p.overall)),
        h('div', { class: 'mute', style: 'font-size:.85rem;margin:.3rem 0' }, `Age ${p.age} · ${p.nationality} · ${p.height_cm} cm · ${label(p.foot)} foot · #${p.shirt_number}`),
        h('div', { class: 'mute', style: 'font-size:.85rem' }, `Value ${money(p.value)} · contract to ${p.contract_expires}`),
        mine ? h('div', {},
          h('div', { class: 'row', style: 'margin:.6rem 0' }, h('span', { class: 'pill' }, `Potential ${p.potential}`), h('span', { class: 'pill' }, `Fitness ${p.fitness}%`), h('span', { class: 'pill' }, `Morale ${p.morale}%`), h('span', { class: 'pill' }, `${money(p.wage)}/wk`)),
          p.is_youth ? h('button', { class: 'btn sm', onclick: () => act(() => api('POST', `/clubs/${id}/players/${p.id}/promote`), 'Promoted to first team') }, 'Promote to first team')
            : h('button', { class: 'btn ghost sm', onclick: () => act(() => api('POST', `/clubs/${id}/players/${p.id}/transfer-list`, { listed: !p.transfer_listed }), p.transfer_listed ? 'Removed from transfer list' : 'Placed on transfer list') }, p.transfer_listed ? 'Remove from transfer list' : 'Transfer-list player'),
          p.position === 'GK' ? attrBlock('Goalkeeping', ATTR_GROUPS.Goalkeeping) : null,
          attrBlock('Technical', ATTR_GROUPS.Technical), attrBlock('Physical', ATTR_GROUPS.Physical), attrBlock('Mental', ATTR_GROUPS.Mental),
          p.is_youth ? null : h('button', { class: 'btn ghost sm', style: 'margin:.5rem 0 0 .4rem', onclick: () => contractDialog(p, act) }, 'Contract'))
          : h('p', { class: 'mute', style: 'margin-top:1rem' }, 'Detailed attributes, potential and condition are only visible for your own players. Scouting (Phase 4) will reveal them for others.'));
    }
    draw();
    return shell('squad', 'Squad', root);
  }

  // ---------------- Tactics ----------------
  async function tactics(clubId) {
    if (!clubId) return noClub();
    const [L, sq] = await Promise.all([api('GET', `/clubs/${clubId}/lineup`), api('GET', `/clubs/${clubId}/squad`)]);
    const players = new Map(sq.players.map((p) => [p.id, p]));
    const meta = L.meta;
    const ed = { formation: L.lineup.formation, slots: L.lineup.slots.map((s) => ({ ...s })), bench: [...L.lineup.bench], captain_id: L.lineup.captain_id, penalty_taker_id: L.lineup.penalty_taker_id, freekick_taker_id: L.lineup.freekick_taker_id, corner_taker_id: L.lineup.corner_taker_id, tactics: { ...L.tactics } };
    let defs = L.slots, sel = 0, dirty = false;
    const root = h('div');
    const senior = sq.players.filter((p) => !p.is_youth);
    const starterIds = () => ed.slots.map((s) => s.player_id);
    const mark = () => { dirty = true; };
    function fixRoles() { // set-piece takers / captain must stay in the XI
      const ids = starterIds(); const pl = ids.map((i) => players.get(i));
      const best = (f) => pl.reduce((a, b) => (f(b) > f(a) ? b : a)).id;
      const A = (p) => p.attrs;
      if (!ids.includes(ed.captain_id)) ed.captain_id = best((p) => A(p).leadership);
      if (!ids.includes(ed.penalty_taker_id)) ed.penalty_taker_id = best((p) => A(p).finishing + A(p).composure);
      if (!ids.includes(ed.freekick_taker_id)) ed.freekick_taker_id = best((p) => A(p).set_pieces);
      if (!ids.includes(ed.corner_taker_id)) ed.corner_taker_id = best((p) => A(p).crossing);
    }
    function assign(slotIdx, pid) {
      const cur = ed.slots[slotIdx];
      const other = ed.slots.findIndex((s) => s.player_id === pid);
      const prev = cur.player_id;
      if (other >= 0) { ed.slots[other] = { ...ed.slots[other], player_id: prev, role: null, instruction: null }; }
      else { const bi = ed.bench.indexOf(pid); if (bi >= 0) ed.bench.splice(bi, 1); if (ed.bench.length < 7) ed.bench.push(prev); }
      ed.slots[slotIdx] = { slot: cur.slot, player_id: pid, role: null, instruction: null };
      fixRoles(); mark(); draw();
    }
    async function changeFormation(f) {
      try {
        const r = await api('GET', `/clubs/${clubId}/lineup/suggest?formation=${encodeURIComponent(f)}`);
        Object.assign(ed, { formation: f, slots: r.lineup.slots, bench: r.lineup.bench, captain_id: r.lineup.captain_id, penalty_taker_id: r.lineup.penalty_taker_id, freekick_taker_id: r.lineup.freekick_taker_id, corner_taker_id: r.lineup.corner_taker_id });
        defs = r.slots; sel = 0; mark(); draw();
      } catch (e) { toast('Cannot change formation', e.message); }
    }
    async function save() {
      try {
        await api('PUT', `/clubs/${clubId}/lineup`, { formation: ed.formation, slots: ed.slots, bench: ed.bench, captain_id: ed.captain_id, penalty_taker_id: ed.penalty_taker_id, freekick_taker_id: ed.freekick_taker_id, corner_taker_id: ed.corner_taker_id });
        await api('PUT', `/clubs/${clubId}/tactics`, ed.tactics);
        dirty = false; toast('Tactics saved', 'Your lineup and instructions are locked in for the next match.'); draw();
      } catch (e) { toast('Not saved', e.message); }
    }
    const playerSelect = (labelTxt, key) => h('div', {}, h('label', {}, labelTxt), h('select', { onchange: (e) => { ed[key] = Number(e.target.value); mark(); draw(); } },
      starterIds().map((i) => h('option', { value: i, selected: ed[key] === i }, players.get(i).last_name))));
    const enumSelect = (key) => h('div', {}, h('label', {}, label(key)), h('select', { onchange: (e) => { ed.tactics[key] = e.target.value; mark(); draw(); } },
      meta.enums[key].map((v) => h('option', { value: v, selected: ed.tactics[key] === v }, label(v)))));
    const slider = (key) => h('div', {}, h('label', {}, `${label(key)}: ${ed.tactics[key]}`), h('input', { type: 'range', min: 1, max: 5, step: 1, value: ed.tactics[key], class: 'range', oninput: (e) => { ed.tactics[key] = Number(e.target.value); mark(); e.target.previousSibling.textContent = `${label(key)}: ${e.target.value}`; } }));
    const flag = (key) => h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: ed.tactics[key] ? true : null, onchange: (e) => { ed.tactics[key] = e.target.checked; mark(); } }), label(key));

    function draw() {
      const def = defs[sel], slot = ed.slots[sel], cur = players.get(slot.player_id);
      const isGK = def.pos === 'GK';
      const pitch = h('div', { class: 'pitch' }, h('div', { class: 'box top' }), h('div', { class: 'box bot' }), h('div', { class: 'mid' }),
        defs.map((d, i) => {
          const p = players.get(ed.slots[i].player_id);
          return h('button', { class: 'slot' + (i === sel ? ' on' : ''), style: `left:${d.x}%;top:${100 - d.y}%`, onclick: () => { sel = i; draw(); }, 'aria-label': `${d.pos} ${p.last_name}` },
            h('span', { class: 'dot ' + tone(p.ratings[d.pos]) }, p.ratings[d.pos]), h('span', { class: 'nm' }, p.last_name), h('span', { class: 'ps' }, d.pos + (ed.captain_id === p.id ? ' ©' : '')));
        }));
      const candidates = senior.filter((p) => p.available && (isGK ? p.position === 'GK' : p.position !== 'GK')).sort((a, b) => b.ratings[def.pos] - a.ratings[def.pos]);
      const where = (p) => { const i = ed.slots.findIndex((s) => s.player_id === p.id); return i >= 0 ? `XI · ${defs[i].pos}` : ed.bench.includes(p.id) ? 'Bench' : ''; };
      const roles = meta.roles[def.pos];
      const panel = h('div', { class: 'card' },
        h('div', { class: 'row' }, h('h2', {}, `${def.pos} · ${cur.first_name} ${cur.last_name}`), h('div', { class: 'sp' }), badge(cur.ratings[def.pos])),
        h('label', {}, 'Role'), h('select', { onchange: (e) => { slot.role = e.target.value || null; mark(); draw(); } }, h('option', { value: '' }, 'Default'), roles.map((r) => h('option', { value: r, selected: slot.role === r }, `${r} (fit ${cur.role_fit[r]})`))),
        h('label', {}, 'Player instruction'), h('select', { onchange: (e) => { slot.instruction = e.target.value || null; mark(); draw(); } }, h('option', { value: '' }, 'None'), meta.instructions.map((r) => h('option', { value: r, selected: slot.instruction === r }, label(r)))),
        h('label', {}, `Pick a ${isGK ? 'goalkeeper' : 'player'} for this slot`),
        h('div', { class: 'picklist' }, candidates.map((p) => h('button', { class: 'pick' + (p.id === slot.player_id ? ' on' : ''), onclick: () => assign(sel, p.id) },
          h('span', { class: 'pill' }, p.position), h('span', { style: 'flex:1;text-align:left' }, `${p.first_name} ${p.last_name}`), h('span', { class: 'mute' }, where(p)), h('span', { class: 'mute' }, p.fitness + '%'), badge(p.ratings[def.pos])))));
      const benchBox = h('div', { class: 'card' }, h('h2', {}, `Substitutes (${ed.bench.length}/7)`),
        ed.bench.length ? ed.bench.map((id) => { const p = players.get(id); return h('div', { class: 'row', style: 'padding:.3rem 0' }, h('span', { class: 'pill' }, p.position), h('span', {}, `${p.first_name} ${p.last_name}`), h('div', { class: 'sp' }), badge(p.overall), h('button', { class: 'btn ghost sm', 'aria-label': `Remove ${p.last_name} from bench`, onclick: () => { ed.bench = ed.bench.filter((x) => x !== id); mark(); draw(); } }, '✕')); }) : h('div', { class: 'empty' }, 'Empty bench'),
        ed.bench.length < 7 ? h('select', { style: 'margin-top:.6rem', onchange: (e) => { if (e.target.value) { ed.bench.push(Number(e.target.value)); mark(); draw(); } } }, h('option', { value: '' }, '+ Add substitute'),
          senior.filter((p) => p.available && !starterIds().includes(p.id) && !ed.bench.includes(p.id)).map((p) => h('option', { value: p.id }, `${p.position} · ${p.last_name} (${p.overall})`))) : null);
      const t = ed.tactics;
      const tacticsBox = h('div', { class: 'card' }, h('h2', {}, 'Team instructions'),
        h('div', { class: 'grid g2', style: 'gap:.2rem 1rem' }, ['mentality', 'passing', 'pressing', 'marking', 'approach', 'time_wasting'].map(enumSelect), meta.sliders.map(slider)),
        h('div', { class: 'row', style: 'margin-top:.8rem' }, meta.flags.map(flag)),
        h('p', { class: 'mute', style: 'font-size:.78rem;margin-top:.8rem' }, 'Instructions are saved with your lineup. They begin to shape results when the match engine arrives in Phase 3.'));
      const setPieces = h('div', { class: 'card' }, h('h2', {}, 'Captain & set pieces'), h('div', { class: 'grid g2', style: 'gap:0 1rem' },
        playerSelect('Captain', 'captain_id'), playerSelect('Penalties', 'penalty_taker_id'), playerSelect('Free kicks', 'freekick_taker_id'), playerSelect('Corners', 'corner_taker_id')));
      root.replaceChildren(
        h('div', { class: 'row', style: 'margin-bottom:1rem' }, h('div', {}, h('label', { style: 'margin:0 0 .3rem' }, 'Formation'),
          h('select', { style: 'width:auto', onchange: (e) => changeFormation(e.target.value) }, meta.formations.map((f) => h('option', { value: f, selected: f === ed.formation }, f)))),
          clubSwitcher(clubId), h('div', { class: 'sp' }), dirty ? h('span', { class: 'pill bad' }, 'Unsaved changes') : h('span', { class: 'pill' }, 'Saved'),
          h('button', { class: 'btn', disabled: !dirty, onclick: save }, 'Save tactics')),
        h('div', { class: 'tac' }, pitch, h('div', { class: 'grid' }, panel, benchBox)),
        h('div', { class: 'grid g2', style: 'margin-top:1rem' }, tacticsBox, setPieces));
    }
    draw();
    return shell('tactics', 'Tactics', root);
  }

  return { club, squad, tactics };
}
