// Phase 3 views: Fixtures, Competitions (league table, results, leaders), Match centre.
export function mount(ctx) {
  const { h, api, crest, toast, shell, state } = ctx;
  const NS = 'http://www.w3.org/2000/svg';
  const svg = (tag, attrs, ...kids) => {
    const e = document.createElementNS(NS, tag);
    for (const k in attrs || {}) e.setAttribute(k, attrs[k]);
    for (const kid of kids) if (kid) e.append(kid);
    return e;
  };
  const sideClub = (f, side) => ({ name: f[side + '_name'], short_name: f[side + '_short'], color1: f[side + '_color1'], color2: f[side + '_color2'] });
  const resPill = (r) => h('span', { class: 'res res-' + r }, r);
  const fmtDate = (d) => new Date(d + 'T00:00:00Z').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
  const myClubIds = () => new Set(state.clubs.map((c) => c.club_id));

  function fixtureRow(f, mine) {
    const played = f.status === 'played';
    const mineH = mine && mine.has(f.home_club_id), mineA = mine && mine.has(f.away_club_id);
    const inner = [
      h('span', { class: 'fx-team home' + (mineH ? ' me' : '') }, f.home_name, crest(sideClub(f, 'home'), 'crest')),
      h('span', { class: 'fx-score' }, played ? `${f.home_goals} - ${f.away_goals}` : 'v'),
      h('span', { class: 'fx-team away' + (mineA ? ' me' : '') }, crest(sideClub(f, 'away'), 'crest'), f.away_name),
    ];
    return played ? h('a', { class: 'fx', href: '#/match/' + f.match_id }, inner) : h('div', { class: 'fx' }, inner);
  }

  function noWorld() {
    return shell('competitions', 'Competitions', h('div', { class: 'card' }, h('h2', {}, 'No competition to show'),
      h('p', { class: 'mute' }, 'Join a Game World to follow its league.'), h('a', { class: 'btn', href: '#/worlds' }, 'Browse Game Worlds')));
  }

  // ---------------- Competitions ----------------
  async function competitions(worldId, activeClubId) {
    if (!worldId) { const c = state.clubs.find((x) => x.club_id === activeClubId); worldId = c && c.world_id; }
    if (!worldId) return noWorld();
    const [comp, lead] = await Promise.all([api('GET', `/worlds/${worldId}/competition`), api('GET', `/worlds/${worldId}/leaders`)]);
    const w = comp.world, mine = myClubIds();
    let tab = 'table', browse = w.rounds_played || 1, browsed = null;
    const root = h('div');
    async function play(count) {
      const next = w.rounds_played + 1;
      if (count === 99) count = w.total_rounds - w.rounds_played;
      if (count > 1 && !confirm(`Simulate ${count === w.total_rounds - w.rounds_played ? 'the rest of the season' : count + ' rounds'}? Results cannot be undone.`)) return;
      try {
        const r = await api('POST', `/worlds/${worldId}/play-round`, { round: next, count });
        toast(r.played_rounds === 1 ? `Round ${r.last_round} played` : `${r.played_rounds} rounds played`, 'Results, tables and player conditions are updated.');
      } catch (e) { toast('Could not advance', e.message); }
      ctx.rerender();
    }
    async function loadRound(n) { browse = n; browsed = (await api('GET', `/worlds/${worldId}/rounds/${n}`)).fixtures; draw(); }
    function table() {
      const head = h('thead', {}, h('tr', {}, ['#', 'Club', 'P', 'W', 'D', 'L', 'GF', 'GA', 'GD', 'Pts', 'Form'].map((t, i) => h('th', { class: i > 1 && i < 10 ? 'num' : '' }, t))));
      const rows = comp.table.map((t) => h('tr', { class: mine.has(t.club_id) ? 'me' : '' },
        h('td', { class: 'pos' }, t.position),
        h('td', {}, h('a', { class: 'clubcell', href: '#/squad/' + t.club_id }, crest(t, 'crest'), h('b', {}, t.name), t.manager_username ? h('span', { class: 'pill human' }, t.manager_username) : null)),
        [t.played, t.won, t.drawn, t.lost, t.gf, t.ga, (t.gd > 0 ? '+' : '') + t.gd].map((v) => h('td', { class: 'num' }, v)),
        h('td', { class: 'num' }, h('b', {}, t.points)),
        h('td', {}, h('span', { class: 'form' }, t.form.map((f) => h('i', { class: 'res-' + f, title: f }))))));
      return h('div', { class: 'card tablewrap' }, h('table', { class: 'league' }, head, h('tbody', {}, rows)));
    }
    function leaders(kind, label, field) {
      const list = lead[kind];
      return h('div', { class: 'card tablewrap' }, list.length ? h('table', {}, h('thead', {}, h('tr', {}, ['#', 'Player', 'Club', label, 'Apps'].map((t) => h('th', {}, t)))),
        h('tbody', {}, list.map((p, i) => h('tr', {}, h('td', {}, i + 1), h('td', {}, p.name), h('td', { class: 'mute' }, p.club_name), h('td', {}, h('b', {}, p[field])), h('td', { class: 'mute' }, p.apps)))))
        : h('div', { class: 'empty' }, 'Nothing to show yet. Play some rounds first.'));
    }
    function draw() {
      const nextN = w.rounds_played + 1, done = w.rounds_played >= w.total_rounds;
      const manage = comp.can_manage ? h('div', { class: 'card' },
        h('div', { class: 'row' }, h('div', {}, h('div', { class: 'eyebrow' }, 'World controls'), h('b', {}, done ? 'Season complete' : `Next: round ${nextN} of ${w.total_rounds}`),
          h('div', { class: 'mute', style: 'font-size:.8rem' }, 'You created this world, so you control its calendar until the automatic world clock arrives in Phase 5.')),
          h('div', { class: 'sp' }),
          h('button', { class: 'btn', disabled: done, onclick: () => play(1) }, `Play round ${done ? '–' : nextN}`),
          h('button', { class: 'btn ghost', disabled: done || w.total_rounds - w.rounds_played < 2, onclick: () => play(Math.min(5, w.total_rounds - w.rounds_played)) }, 'Play 5 rounds'),
          h('button', { class: 'btn ghost', disabled: done, onclick: () => play(99) }, 'Play to season end'))) : null;
      const tabs = h('div', { class: 'row' }, [['table', 'League table'], ['scorers', 'Top scorers'], ['assists', 'Assists'], ['ratings', 'Best ratings']].map(([k, t]) => h('button', { class: 'chip' + (tab === k ? ' on' : ''), onclick: () => { tab = k; draw(); } }, t)));
      const body = tab === 'table' ? table() : tab === 'scorers' ? leaders('scorers', 'Goals', 'goals') : tab === 'assists' ? leaders('assists', 'Assists', 'assists') : leaders('ratings', 'Avg rating', 'avg_rating');
      const fx = browsed || (browse === w.rounds_played ? comp.last_round : browse === nextN ? comp.next_round : null);
      const rounds = h('div', { class: 'card' }, h('div', { class: 'row' }, h('h2', {}, `Round ${browse}`),
        h('div', { class: 'sp' }),
        h('button', { class: 'btn ghost sm', disabled: browse <= 1, 'aria-label': 'Previous round', onclick: () => loadRound(browse - 1) }, '‹'),
        h('button', { class: 'btn ghost sm', disabled: browse >= w.total_rounds, 'aria-label': 'Next round', onclick: () => loadRound(browse + 1) }, '›')),
        fx && fx.length ? h('div', {}, fx.map((f) => fixtureRow(f, mine)), h('div', { class: 'mute', style: 'font-size:.78rem;margin-top:.4rem' }, fmtDate(fx[0].game_date)))
          : h('div', { class: 'empty', style: 'margin-top:.8rem' }, w.rounds_played === 0 ? 'No rounds have been played yet.' : 'Loading…'));
      root.replaceChildren(
        h('div', { class: 'hero' }, h('div', {}, h('div', { class: 'eyebrow' }, `${w.code} · Season ${w.season} · ${fmtDate(w.game_date)}`), h('h1', {}, w.name),
          h('div', { class: 'mute' }, `${w.rounds_played} of ${w.total_rounds} rounds played`)), h('div', { class: 'sp' }), h('a', { class: 'btn ghost sm', href: '#/worlds/' + worldId }, 'World & clubs')),
        manage, tabs, h('div', { class: 'split2' }, body, rounds));
    }
    draw();
    if (browse && !(browse === w.rounds_played || browse === w.rounds_played + 1)) loadRound(browse);
    return shell('competitions', 'Competitions', root);
  }

  // ---------------- Fixtures (club schedule) ----------------
  async function fixtures(clubId) {
    if (!clubId) return noWorld();
    const s = await api('GET', `/clubs/${clubId}/schedule`);
    const me = state.clubs.find((c) => c.club_id === clubId);
    const next = s.fixtures.find((f) => f.status === 'scheduled');
    const rec = { W: 0, D: 0, L: 0 };
    for (const f of s.fixtures) if (f.result) rec[f.result]++;
    const row = (f) => {
      const opp = f.home ? { name: f.away_name, c: sideClub(f, 'away') } : { name: f.home_name, c: sideClub(f, 'home') };
      const cells = [
        h('td', { class: 'mute' }, 'R' + f.round), h('td', { class: 'mute' }, fmtDate(f.game_date)), h('td', {}, h('span', { class: 'pill' }, f.home ? 'H' : 'A')),
        h('td', {}, h('span', { class: 'clubcell' }, crest(opp.c, 'crest'), opp.name)),
        h('td', {}, f.status === 'played' ? h('b', {}, `${f.home_goals} - ${f.away_goals}`) : h('span', { class: 'mute' }, '–')),
        h('td', {}, f.result ? resPill(f.result) : f === next ? h('span', { class: 'pill you' }, 'Next') : ''),
      ];
      return f.match_id ? h('tr', { class: 'clickable', tabindex: 0, onclick: () => { location.hash = '#/match/' + f.match_id; }, onkeydown: (e) => { if (e.key === 'Enter') location.hash = '#/match/' + f.match_id; } }, cells) : h('tr', { class: f === next ? 'sel' : '' }, cells);
    };
    return shell('fixtures', 'Fixtures', h('div', { class: 'grid' },
      h('div', { class: 'hero' }, h('div', {}, h('div', { class: 'eyebrow' }, `${me ? me.world_name : ''} · Season ${s.season}`), h('h1', {}, me ? me.club_name : 'Fixtures'),
        h('div', { class: 'mute' }, s.rounds_played ? `League position ${s.position} · W${rec.W} D${rec.D} L${rec.L}` : 'The season has not started')), h('div', { class: 'sp' }), h('a', { class: 'btn ghost sm', href: '#/competitions/' + s.world_id }, 'League table')),
      next ? h('div', { class: 'card' }, h('div', { class: 'eyebrow' }, `Next match · round ${next.round} · ${fmtDate(next.game_date)}`), fixtureRow(next, myClubIds())) : h('div', { class: 'card' }, h('b', {}, 'The season is complete.')),
      h('div', { class: 'card tablewrap' }, h('table', {}, h('thead', {}, h('tr', {}, ['Rd', 'Date', '', 'Opponent', 'Score', ''].map((t) => h('th', {}, t)))), h('tbody', {}, s.fixtures.map(row))))));
  }

  // ---------------- Match centre ----------------
  const ICON = { goal: '⚽', save: '🧤', miss: '↗', block: '🛡', corner: '⚑', yellow: '🟨', red: '🟥', injury: '🩹', sub: '🔁', offside: '🚩', penalty: '❗', freekick: '🎯', tackle: '🦵', inter: '✋', foul: '⚠', kickoff: '⏱', halftime: '⏸', secondhalf: '⏱', fulltime: '🏁', chance: '' };
  const STAT_ROWS = [['possession', 'Possession', '%'], ['shots', 'Shots'], ['shots_on_target', 'On target'], ['xg', 'Expected goals (xG)'], ['corners', 'Corners'], ['fouls', 'Fouls'], ['yellow_cards', 'Yellow cards'], ['red_cards', 'Red cards'],
    ['offsides', 'Offsides'], ['passes', 'Passes'], ['pass_accuracy', 'Pass accuracy', '%'], ['tackles', 'Tackles'], ['interceptions', 'Interceptions'], ['saves', 'Saves'], ['chemistry', 'Team chemistry', '%']];

  async function match(id) {
    const m = await api('GET', `/matches/${id}`);
    const mine = new Set(m.my_club_ids);
    let shown = 0, playing = false, timer = null, speed = 1, tab = 'live';
    const root = h('div'), board = h('div'), feed = h('div', { class: 'feed' }), controls = h('div', { class: 'row' }), body = h('div');
    state.cleanup = () => { if (timer) clearInterval(timer); };
    const done = () => shown >= m.events.length;
    const lastScore = () => { for (let i = shown - 1; i >= 0; i--) if (m.events[i].type === 'goal' || m.events[i].type === 'fulltime') return m.events[i].score; return [0, 0]; };
    const clockLabel = () => (shown === 0 ? 'Kick-off' : done() ? 'FT' : m.events[shown - 1].label + "'");
    const nameOf = (pid) => { const p = m.players.find((x) => x.player_id === pid); return p ? p.name : ''; };

    function drawBoard() {
      const [hs, as] = lastScore();
      board.replaceChildren(h('div', { class: 'hero scoreboard' },
        h('div', { class: 'sb-team' }, crest(m.home, 'crest'), h('b', {}, m.home.name), mine.has(m.home.id) ? h('span', { class: 'pill you' }, 'Your club') : null),
        h('div', { class: 'sb-mid' }, h('div', { class: 'sb-score' }, `${hs} - ${as}`), h('div', { class: 'eyebrow' }, clockLabel()), h('div', { class: 'mute', style: 'font-size:.75rem' }, `Round ${m.round} · ${m.home.stadium_name}`)),
        h('div', { class: 'sb-team' }, crest(m.away, 'crest'), h('b', {}, m.away.name), mine.has(m.away.id) ? h('span', { class: 'pill you' }, 'Your club') : null)));
    }
    function drawFeed() {
      const items = m.events.slice(0, shown).filter((e) => e.type !== 'secondhalf').reverse();
      feed.replaceChildren(...(items.length ? items.map((e) => h('div', { class: 'ev ev-' + e.type + (e.team ? ' ' + e.team : '') },
        h('span', { class: 'ev-min' }, e.type === 'kickoff' ? '' : e.label + "'"), h('span', { class: 'ev-ic' }, ICON[e.type] ?? ''),
        h('span', { class: 'ev-tx' }, e.text, e.type === 'goal' && e.assist_id ? h('span', { class: 'mute' }, ` Assist: ${nameOf(e.assist_id)}.`) : null, e.type === 'goal' ? h('span', { class: 'mute' }, ` (${e.score[0]}-${e.score[1]})`) : null))) : [h('div', { class: 'empty' }, 'Press play to watch the match unfold, or skip to full-time.')]));
    }
    function drawControls() {
      controls.replaceChildren(
        h('button', { class: 'btn', disabled: done(), onclick: toggle }, playing ? '⏸ Pause' : shown === 0 ? '▶ Watch match' : '▶ Resume'),
        h('button', { class: 'btn ghost', disabled: done(), onclick: skip }, 'Skip to full-time'),
        ...[1, 4].map((s) => h('button', { class: 'chip' + (speed === s ? ' on' : ''), onclick: () => { speed = s; if (playing) { stop(); start(); } else drawControls(); } }, s + '×')),
        h('div', { class: 'sp' }), shown > 0 ? h('button', { class: 'btn ghost sm', onclick: () => { stop(); shown = 0; refresh(); } }, 'Restart') : null);
    }
    function refresh() { drawBoard(); drawFeed(); drawControls(); }
    function step() { if (done()) { stop(); refresh(); return; } shown++; const e = m.events[shown - 1]; drawBoard(); drawFeed(); if (done()) stop(); else if (e.type === 'goal') { /* linger on goals */ } }
    function start() { playing = true; timer = setInterval(step, Math.round(650 / speed)); drawControls(); }
    function stop() { playing = false; if (timer) clearInterval(timer); timer = null; drawControls(); }
    function toggle() { playing ? stop() : start(); }
    function skip() { stop(); shown = m.events.length; refresh(); }

    function statsPanel() {
      const bar = (key, label, suf = '') => {
        const a = m.stats.home[key], b = m.stats.away[key], tot = a + b || 1;
        return h('div', { class: 'stat-row' }, h('b', {}, a + suf), h('div', {}, h('div', { class: 'mute', style: 'text-align:center;font-size:.78rem' }, label),
          h('div', { class: 'dual' }, h('i', { style: `width:${(a / tot) * 100}%;background:${m.home.color1}` }), h('i', { style: `width:${(b / tot) * 100}%;background:${m.away.color1}` }))), h('b', {}, b + suf));
      };
      const ch = (s) => h('div', { class: 'row', style: 'gap:.4rem' }, ['left', 'central', 'right'].map((k) => h('span', { class: 'pill' }, `${k[0].toUpperCase() + k.slice(1)} ${m.stats[s].attack_channels[k]}%`)));
      return h('div', { class: 'card' }, STAT_ROWS.map(([k, l, suf]) => bar(k, l, suf || '')),
        h('div', { class: 'grid g2', style: 'margin-top:1rem' }, h('div', {}, h('div', { class: 'eyebrow' }, `${m.home.name} attacks`), ch('home')), h('div', {}, h('div', { class: 'eyebrow' }, `${m.away.name} attacks`), ch('away'))));
    }
    function lineupsPanel() {
      const side = (s, club) => {
        const ps = m.players.filter((p) => p.team === s);
        const row = (p) => h('tr', { class: p.player_id === m.motm.player_id ? 'sel' : '' }, h('td', {}, h('span', { class: 'pill' }, p.pos)), h('td', {}, p.name,
          p.goals ? ' ' + '⚽'.repeat(p.goals) : '', p.assists ? ' 🅰'.repeat(p.assists) : '', p.yc ? ' 🟨' : '', p.rc ? ' 🟥' : '', p.injury_days ? ' 🩹' : '', p.player_id === m.motm.player_id ? ' ⭐' : ''),
          h('td', { class: 'mute' }, p.minutes + "'"), h('td', {}, h('span', { class: 'ovr ' + (p.rating >= 7.5 ? 'hi' : p.rating >= 6.5 ? 'good' : p.rating >= 5.5 ? 'mid' : 'lo') }, p.rating.toFixed(1))));
        return h('div', { class: 'card tablewrap' }, h('div', { class: 'row' }, crest(club, 'crest'), h('h2', {}, club.name), h('span', { class: 'mute' }, m.lineups[s].formation)),
          h('table', {}, h('tbody', {}, ps.filter((p) => p.started).map(row), ps.some((p) => !p.started) ? h('tr', {}, h('td', { colspan: 4, class: 'eyebrow' }, 'Substitutes used')) : null, ps.filter((p) => !p.started).map(row))));
      };
      return h('div', {}, h('div', { class: 'card', style: 'margin-bottom:1rem' }, h('div', { class: 'eyebrow' }, 'Man of the match'), h('b', {}, `⭐ ${m.motm.name}`), h('span', { class: 'mute' }, ` · rated ${m.motm.rating.toFixed(1)}`)),
        h('div', { class: 'grid g2' }, side('home', m.home), side('away', m.away)));
    }
    function shotMap() {
      const half = (s, club) => {
        const shots = m.shots.filter((x) => x.team === s);
        const colour = { goal: '#c6ff3d', saved: '#4da3ff', blocked: '#9aa6bf', off: '#ff7b6b' };
        const el = svg('svg', { viewBox: '0 0 100 46', class: 'shotmap', role: 'img', 'aria-label': `${club.name} shot map` },
          svg('rect', { x: 0, y: 0, width: 100, height: 46, fill: '#17612f' }),
          svg('rect', { x: 21.5, y: 0, width: 57, height: 19, fill: 'none', stroke: '#e8eefc66', 'stroke-width': 0.4 }),
          svg('rect', { x: 36.5, y: 0, width: 27, height: 6.3, fill: 'none', stroke: '#e8eefc66', 'stroke-width': 0.4 }),
          svg('path', { d: 'M40 19 A10 10 0 0 0 60 19', fill: 'none', stroke: '#e8eefc66', 'stroke-width': 0.4 }),
          svg('rect', { x: 44, y: -1, width: 12, height: 1.4, fill: '#fff' }));
        for (const x of shots) {
          const c = svg('circle', { cx: x.x, cy: (100 - x.y) * 1.2, r: (0.9 + x.xg * 9).toFixed(2), fill: colour[x.result], 'fill-opacity': x.result === 'goal' ? 1 : 0.75, stroke: '#07101f', 'stroke-width': 0.3 });
          c.append(svg('title', {}));
          c.firstChild.textContent = `${x.min}' ${nameOf(x.player_id)} · ${x.kind} · xG ${x.xg} · ${x.result}`;
          el.append(c);
        }
        return h('div', { class: 'card' }, h('div', { class: 'row' }, crest(club, 'crest'), h('b', {}, club.name), h('span', { class: 'mute' }, `${shots.length} shots · xG ${m.stats[s].xg}`)), el);
      };
      return h('div', {}, h('div', { class: 'row', style: 'margin-bottom:.8rem' }, [['goal', 'Goal'], ['saved', 'Saved'], ['blocked', 'Blocked'], ['off', 'Off target']].map(([k, t]) => h('span', { class: 'legend' }, h('i', { class: 'dotl d-' + k }), t)), h('span', { class: 'mute', style: 'font-size:.78rem' }, 'Bigger dot = bigger chance')),
        h('div', { class: 'grid g2' }, half('home', m.home), half('away', m.away)));
    }
    function drawBody() {
      const panels = { live: () => h('div', { class: 'card' }, controls, h('div', { style: 'height:.8rem' }), feed), stats: statsPanel, lineups: lineupsPanel, shots: shotMap };
      body.replaceChildren(panels[tab]());
      if (tab === 'live') refresh();
    }
    const tabs = h('div', { class: 'row' }, [['live', 'Live commentary'], ['stats', 'Match stats'], ['lineups', 'Lineups & ratings'], ['shots', 'Shot map']].map(([k, t]) => h('button', { class: 'chip', 'data-tab': k, onclick: (e) => { tab = k; for (const b of tabs.children) b.classList.toggle('on', b === e.currentTarget); drawBody(); } }, t)));
    tabs.firstChild.classList.add('on');
    root.append(h('a', { href: '#/competitions/' + m.world_id, class: 'mute' }, '← League'), h('div', { style: 'height:.8rem' }), board, tabs, h('div', { style: 'height:.8rem' }), body);
    drawBoard(); drawBody();
    return shell('competitions', 'Match centre', root);
  }

  return { competitions, fixtures, match, fixtureRow, resPill, fmtDate };
}
