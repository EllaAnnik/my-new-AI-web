'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../server/index');

let app, base;
test.before(async () => {
  app = createApp({ dbFile: ':memory:', registerLimitPerHour: 1000 });
  base = `http://127.0.0.1:${await app.listen(0, '127.0.0.1')}`;
});
test.after(() => app.close());

class Client {
  constructor() { this.cookie = ''; }
  async req(method, path, body, headers = {}) {
    const res = await fetch(base + path, {
      method,
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(this.cookie ? { Cookie: this.cookie } : {}), ...headers },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const sc = res.headers.get('set-cookie');
    if (sc) this.cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    let json = null;
    try { json = await res.json(); } catch { /* none */ }
    return { status: res.status, json, headers: res.headers };
  }
  get(p) { return this.req('GET', p); }
  post(p, b = {}) { return this.req('POST', p, b); }
}
let n = 0;
async function newUser(name) {
  const c = new Client();
  const u = name || `user${++n}`;
  const r = await c.post('/api/auth/register', { email: `${u}@test.dev`, username: u, password: 'correct-horse-9' });
  assert.equal(r.status, 201, JSON.stringify(r.json));
  return c;
}

let admin, alice, bob;
test('first registered account becomes admin, later ones are players', async () => {
  admin = await newUser('boss');
  alice = await newUser('alice');
  bob = await newUser('bob');
  assert.equal((await admin.get('/api/me')).json.user.role, 'admin');
  assert.equal((await alice.get('/api/me')).json.user.role, 'player');
});

test('auth validation, duplicates, cookie flags, and no password leakage', async () => {
  const c = new Client();
  assert.equal((await c.post('/api/auth/register', { email: 'x', username: 'ok_name', password: 'longenough1' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { email: 'a@b.co', username: 'x', password: 'longenough1' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { email: 'a@b.co', username: 'ok_name', password: 'short' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { email: 'ALICE@test.dev', username: 'other', password: 'longenough1' })).status, 409);
  assert.equal((await c.post('/api/auth/register', { email: 'z@test.dev', username: 'ALICE', password: 'longenough1' })).status, 409);
  const r = await alice.post('/api/auth/login', { identifier: 'alice', password: 'correct-horse-9' });
  const sc = r.headers.get('set-cookie');
  assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Lax/);
  assert.ok(!JSON.stringify(r.json).includes('pass_hash'));
});

test('login failures are generic and sessions can be ended', async () => {
  const c = new Client();
  const a = await c.post('/api/auth/login', { identifier: 'alice', password: 'wrong-password' });
  const b = await c.post('/api/auth/login', { identifier: 'nobody', password: 'wrong-password' });
  assert.equal(a.status, 401); assert.equal(b.status, 401);
  assert.equal(a.json.error, b.json.error);
  const s = await newUser('temp_user');
  assert.equal((await s.get('/api/me')).status, 200);
  const old = s.cookie;
  await s.post('/api/auth/logout');
  const stale = new Client(); stale.cookie = old;
  assert.equal((await stale.get('/api/me')).status, 401);
});

test('unauthenticated users cannot use the API', async () => {
  const c = new Client();
  for (const p of ['/api/worlds', '/api/me', '/api/notifications', '/api/admin/users']) assert.equal((await c.get(p)).status, 401, p);
});

test('login is rate limited per identifier', async () => {
  const c = new Client();
  let last;
  for (let i = 0; i < 12; i++) last = await c.post('/api/auth/login', { identifier: 'ratelimit_target', password: 'x'.repeat(10) });
  assert.equal(last.status, 429);
});

test('cross-origin state-changing requests are rejected', async () => {
  const r = await alice.req('POST', '/api/worlds', { name: 'Evil World' }, { Origin: 'http://evil.example' });
  assert.equal(r.status, 403);
});

let w1, w2;
test('worlds: create, list, validation and per-user creation cap', async () => {
  assert.equal((await alice.post('/api/worlds', { name: 'ab' })).status, 400);
  assert.equal((await alice.post('/api/worlds', { name: 'Valid Name', clubs: 7 })).status, 400);
  w1 = (await alice.post('/api/worlds', { name: 'Alpha League', clubs: 20 })).json.world_id;
  w2 = (await alice.post('/api/worlds', { name: 'Beta League', clubs: 20 })).json.world_id;
  const list = (await bob.get('/api/worlds')).json.worlds;
  assert.equal(list.length, 2);
  assert.ok(list.every((w) => w.club_count === 20 && w.human_count === 0 && w.my_club_id === null));
  assert.deepEqual(list.map((w) => w.code), ['W001', 'W002']);
});

test('each world has unique club names and independent club ids', async () => {
  const a = (await alice.get(`/api/worlds/${w1}`)).json.clubs;
  const b = (await alice.get(`/api/worlds/${w2}`)).json.clubs;
  assert.equal(new Set(a.map((c) => c.name)).size, 20);
  const idsA = new Set(a.map((c) => c.id));
  assert.ok(b.every((c) => !idsA.has(c.id)));
  assert.ok(a.every((c) => !('email' in c)));
});

test('claiming a club: success, one-club-per-world, other world still allowed', async () => {
  const clubs = (await alice.get(`/api/worlds/${w1}`)).json.clubs;
  const target = clubs[0];
  const r = await alice.post(`/api/worlds/${w1}/join`, { club_id: target.id });
  assert.equal(r.status, 200);
  assert.equal((await alice.post(`/api/worlds/${w1}/join`, { club_id: clubs[1].id })).json.code, 'already_joined');
  assert.equal((await bob.post(`/api/worlds/${w1}/join`, { club_id: target.id })).json.code, 'club_taken');
  const detail = (await bob.get(`/api/worlds/${w1}`)).json;
  assert.equal(detail.clubs.find((c) => c.id === target.id).manager_username, 'alice');
  // alice can manage a different club in a different world
  assert.equal((await alice.post(`/api/worlds/${w2}/join`, {})).status, 200);
  const me = (await alice.get('/api/me')).json;
  assert.equal(me.clubs.length, 2);
  assert.ok(me.unread >= 2);
});

test('worlds cannot leak: a club from world A cannot be claimed via world B', async () => {
  const a = (await bob.get(`/api/worlds/${w1}`)).json.clubs.find((c) => !c.manager_user_id);
  const r = await bob.post(`/api/worlds/${w2}/join`, { club_id: a.id });
  assert.equal(r.status, 404);
  const m = (await bob.get('/api/me')).json;
  assert.equal(m.clubs.length, 0);
});

test('race: 15 users claim the same club at once, exactly one wins', async () => {
  const w = (await admin.post('/api/worlds', { name: 'Race World', clubs: 10 })).json.world_id;
  const club = (await admin.get(`/api/worlds/${w}`)).json.clubs[0];
  const users = [];
  for (let i = 0; i < 15; i++) users.push(await newUser(`racer${i}`));
  const results = await Promise.all(users.map((u) => u.post(`/api/worlds/${w}/join`, { club_id: club.id })));
  assert.equal(results.filter((r) => r.status === 200).length, 1);
  assert.equal(results.filter((r) => r.status === 409).length, 14);
  const humans = (await admin.get(`/api/worlds/${w}`)).json.clubs.filter((c) => c.manager_user_id);
  assert.equal(humans.length, 1);
});

test('race: world fills up exactly; random assignment never double-books', async () => {
  const w = (await admin.post('/api/worlds', { name: 'Small World', clubs: 4 })).json.world_id;
  const users = [];
  for (let i = 0; i < 9; i++) users.push(await newUser(`fill${i}`));
  const results = await Promise.all(users.map((u) => u.post(`/api/worlds/${w}/join`, {})));
  assert.equal(results.filter((r) => r.status === 200).length, 4);
  assert.ok(results.filter((r) => r.status !== 200).every((r) => r.json.code === 'world_full'));
  const ids = results.filter((r) => r.status === 200).map((r) => r.json.club_id);
  assert.equal(new Set(ids).size, 4);
});

test('leaving a club frees it again', async () => {
  const w = (await admin.post('/api/worlds', { name: 'Leave World', clubs: 4 })).json.world_id;
  const u = await newUser('leaver');
  const j = await u.post(`/api/worlds/${w}/join`, {});
  assert.equal((await u.post(`/api/worlds/${w}/leave`)).status, 200);
  const club = (await u.get(`/api/worlds/${w}`)).json.clubs.find((c) => c.id === j.json.club_id);
  assert.equal(club.manager_user_id, null);
  assert.equal((await u.post(`/api/worlds/${w}/leave`)).status, 404);
});

test('admin: players are forbidden, suspension kills sessions and blocks login, all audited', async () => {
  const victim = await newUser('victim');
  const vid = (await victim.get('/api/me')).json.user.id;
  assert.equal((await alice.get('/api/admin/users')).status, 403);
  assert.equal((await alice.post(`/api/admin/users/${vid}/suspend`, { reason: 'x' })).status, 403);
  assert.equal((await admin.post(`/api/admin/users/${vid}/suspend`, {})).status, 400); // reason required
  assert.equal((await admin.post(`/api/admin/users/${vid}/suspend`, { reason: 'abuse in chat' })).status, 200);
  assert.equal((await victim.get('/api/me')).status, 401);
  const l = await new Client().post('/api/auth/login', { identifier: 'victim', password: 'correct-horse-9' });
  assert.equal(l.status, 403);
  const adminId = (await admin.get('/api/me')).json.user.id;
  assert.equal((await admin.post(`/api/admin/users/${adminId}/suspend`, { reason: 'x' })).status, 403);
  const audit = (await admin.get('/api/admin/audit')).json.entries;
  assert.ok(audit.some((e) => e.action === 'user_suspended' && e.target === `user:${vid}`));
  assert.ok(audit.some((e) => e.action === 'bootstrap_admin'));
});

test('notifications: list, mark read', async () => {
  const list = (await alice.get('/api/notifications')).json.notifications;
  assert.ok(list.length >= 2);
  await alice.post('/api/notifications/read');
  assert.equal((await alice.get('/api/me')).json.unread, 0);
});

test('SSE pushes world updates to connected managers', async () => {
  const w = (await admin.post('/api/worlds', { name: 'Live World', clubs: 4 })).json.world_id;
  const watcher = await newUser('watcher');
  await watcher.post(`/api/worlds/${w}/join`, {});
  const ctrl = new AbortController();
  const res = await fetch(`${base}/api/events`, { headers: { Cookie: watcher.cookie }, signal: ctrl.signal });
  assert.equal(res.headers.get('content-type'), 'text/event-stream');
  const reader = res.body.getReader();
  const joiner = await newUser('joiner');
  const got = (async () => {
    let buf = '';
    const dec = new TextDecoder();
    for (;;) {
      const { value } = await reader.read();
      buf += dec.decode(value);
      if (buf.includes('event: world_changed')) return buf;
    }
  })();
  await joiner.post(`/api/worlds/${w}/join`, {});
  const text = await Promise.race([got, new Promise((_, rej) => setTimeout(() => rej(new Error('no SSE event')), 3000))]);
  assert.match(text, /"manager":"joiner"/);
  ctrl.abort();
});

test('registration is rate limited per IP by default', async () => {
  const limited = createApp({ dbFile: ':memory:' });
  const b = `http://127.0.0.1:${await limited.listen(0, '127.0.0.1')}`;
  let last;
  for (let i = 0; i < 11; i++) {
    last = await fetch(`${b}/api/auth/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: `r${i}@t.dev`, username: `rl_user${i}`, password: 'longenough1' }) });
  }
  assert.equal(last.status, 429);
  await limited.close();
});

test('static: path traversal is blocked, unknown API is 404, bad JSON is 400', async () => {
  const t = await fetch(`${base}/..%2f..%2fserver/db.js`);
  assert.notEqual(t.status, 200);
  assert.equal((await alice.get('/api/nope')).status, 404);
  const raw = await fetch(`${base}/api/worlds`, { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: alice.cookie }, body: '{bad' });
  assert.equal(raw.status, 400);
  const form = await fetch(`${base}/api/worlds`, { method: 'POST', headers: { 'Content-Type': 'text/plain', Cookie: alice.cookie }, body: 'name=x' });
  assert.equal(form.status, 415);
});
