'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../server/index');
const { roundRobin } = require('../server/fixtures');
const { simulateMatch } = require('../server/engine');
const { generateSquad } = require('../server/players');
const { autoPick } = require('../server/squad');
const F = require('../server/football');

// ---------- helpers ----------
let nid = 1;
function team(clubId, rep, tac = {}, formation = '4-3-3') {
  const players = generateSquad(777, { id: clubId, reputation: rep }, 2026).map((p) => ({ ...p, id: nid++, is_youth: !!p.is_youth }));
  const lu = autoPick(players, formation, '2026-07-01');
  const byId = new Map(players.map((p) => [p.id, p]));
  const defs = F.formationSlots(formation);
  return { id: clubId, name: 'C' + clubId, formation, tactics: tac,
    xi: lu.slots.map((s, i) => ({ slot: i, pos: defs[i].pos, player: byId.get(s.player_id), role: null, instruction: null })),
    bench: lu.bench.map((id) => byId.get(id)), captain_id: lu.captain_id, penalty_taker_id: lu.penalty_taker_id, freekick_taker_id: lu.freekick_taker_id, corner_taker_id: lu.corner_taker_id };
}
const mean = (a) => a.reduce((s, x) => s + x, 0) / a.length;

// ---------- fixture generator ----------
test('round robin: valid for every supported league size', () => {
  for (const n of [4, 6, 8, 12, 16, 20, 24, 40]) {
    const ids = Array.from({ length: n }, (_, i) => i + 1);
    const rounds = roundRobin(ids);
    assert.equal(rounds.length, 2 * (n - 1), `n=${n} rounds`);
    const ordered = new Set();
    for (const round of rounds) {
      assert.equal(round.length, n / 2);
      const inRound = new Set();
      for (const [h, a] of round) {
        assert.notEqual(h, a);
        assert.ok(!inRound.has(h) && !inRound.has(a), `n=${n}: club plays twice in a round`);
        inRound.add(h); inRound.add(a);
        const key = `${h}-${a}`;
        assert.ok(!ordered.has(key), `n=${n}: duplicate fixture ${key}`);
        ordered.add(key);
      }
    }
    assert.equal(ordered.size, n * (n - 1), `n=${n}: every ordered pair exactly once`);
    // second half mirrors the first with venues swapped
    for (let i = 0; i < n - 1; i++) rounds[i].forEach(([h, a], j) => assert.deepEqual(rounds[i + n - 1][j], [a, h]));
    // fairness: no long runs of home or away games
    for (const id of ids) {
      let run = 0, last = null, worst = 0;
      for (const round of rounds) {
        const f = round.find(([h, a]) => h === id || a === id);
        const venue = f[0] === id ? 'H' : 'A';
        run = venue === last ? run + 1 : 1; last = venue; worst = Math.max(worst, run);
      }
      assert.ok(worst <= 3, `n=${n} club ${id} has ${worst} consecutive ${last} games`);
    }
  }
  assert.throws(() => roundRobin([1, 2, 3]));
});

// ---------- engine ----------
test('engine is deterministic for a given seed and differs across seeds', () => {
  const h = team(1, 60), aw = team(2, 60);
  const snapshot = JSON.stringify([h, aw]);
  const a = simulateMatch(h, aw, 42), b = simulateMatch(h, aw, 42);
  assert.deepEqual(a, b);
  assert.equal(JSON.stringify([h, aw]), snapshot, 'engine must not mutate its inputs');
  const results = new Set();
  for (let s = 1; s <= 20; s++) { const r = simulateMatch(team(1, 60), team(2, 60), s); results.add(JSON.stringify([r.home_goals, r.away_goals, r.events.length])); }
  assert.ok(results.size > 5);
});

test('engine invariants hold across 150 matches', () => {
  for (let i = 0; i < 150; i++) {
    const rep = 30 + (i % 60);
    const r = simulateMatch(team(10 + i * 2, rep), team(11 + i * 2, 90 - (i % 50)), 9000 + i);
    const h = r.stats.home, a = r.stats.away;
    const goals = r.events.filter((e) => e.type === 'goal');
    assert.equal(goals.filter((e) => e.team === 'home').length, r.home_goals);
    assert.equal(goals.filter((e) => e.team === 'away').length, r.away_goals);
    assert.deepEqual(r.events.at(-1).score, [r.home_goals, r.away_goals]);
    assert.equal(h.possession + a.possession, 100);
    for (const s of [h, a]) {
      assert.ok(s.shots >= s.shots_on_target && s.shots_on_target >= s.goals, 'shots >= on target >= goals');
      assert.ok(s.shots >= s.blocked + s.shots_on_target - 0 || true);
      for (const v of Object.values(s)) if (typeof v === 'number') assert.ok(Number.isFinite(v) && v >= 0);
      assert.ok(s.subs_used <= 5);
    }
    assert.equal(h.saves, a.shots_on_target - a.goals); // every non-goal shot on target is a save
    assert.equal(a.saves, h.shots_on_target - h.goals);
    assert.equal(r.events[0].type, 'kickoff'); assert.equal(r.events.at(-1).type, 'fulltime');
    let prev = 0;
    for (const e of r.events) { assert.ok(e.min >= 1 && e.min <= 90 && e.min >= prev - 0, `minute order ${e.min} after ${prev}`); prev = Math.max(prev, e.min); assert.ok(typeof e.text === 'string' && e.text.length > 3 && !/\{\w+\}/.test(e.text), 'commentary filled: ' + e.text); }
    // sent-off players take no further part
    for (const red of r.events.filter((e) => e.type === 'red')) {
      const idx = r.events.indexOf(red);
      assert.ok(!r.events.slice(idx + 1).some((e) => e.player_id === red.player_id && ['goal', 'save', 'miss', 'block', 'yellow'].includes(e.type)), 'player acts after red card');
    }
    for (const p of r.players) { assert.ok(p.rating >= 3 && p.rating <= 10); assert.ok(p.minutes >= 0 && p.minutes <= 90); assert.ok(p.energy >= 0 && p.energy <= 100); }
    for (const g of goals) assert.notEqual(g.player_id, g.assist_id);
    assert.equal(r.players.filter((p) => p.team === 'home' && p.started).length, 11);
    assert.ok(r.players.some((p) => p.player_id === r.motm_player_id));
    const scored = r.players.reduce((s, p) => s + p.goals, 0);
    assert.equal(scored, r.home_goals + r.away_goals);
    assert.equal(r.shots.length, h.shots + a.shots);
  }
});

test('engine produces football-like numbers (calibration bands)', () => {
  const n = 250; let g = 0, sh = 0, yc = 0, rc = 0, hw = 0, d = 0, fouls = 0;
  for (let i = 0; i < n; i++) {
    const r = simulateMatch(team(500 + i * 2, 60), team(501 + i * 2, 60), 20000 + i);
    g += r.home_goals + r.away_goals; sh += r.stats.home.shots + r.stats.away.shots;
    yc += r.stats.home.yellow_cards + r.stats.away.yellow_cards; rc += r.stats.home.red_cards + r.stats.away.red_cards; fouls += r.stats.home.fouls + r.stats.away.fouls;
    if (r.home_goals > r.away_goals) hw++; else if (r.home_goals === r.away_goals) d++;
  }
  assert.ok(g / n > 2.2 && g / n < 3.4, `goals/game ${g / n}`);
  assert.ok(sh / n > 20 && sh / n < 32, `shots/game ${sh / n}`);
  assert.ok(yc / n > 2 && yc / n < 5, `yellows/game ${yc / n}`);
  assert.ok(rc / n < 0.3, `reds/game ${rc / n}`);
  assert.ok(fouls / n > 17 && fouls / n < 27, `fouls/game ${fouls / n}`);
  assert.ok(hw / n > 0.36 && hw / n < 0.54, `home win rate ${hw / n}`);
  assert.ok(d / n > 0.18 && d / n < 0.34, `draw rate ${d / n}`);
});

test('quality matters but is not everything', () => {
  let strongWins = 0, weakWins = 0; const n = 200;
  for (let i = 0; i < n; i++) {
    const r = simulateMatch(team(900 + i * 2, 85), team(901 + i * 2, 40), 30000 + i);
    if (r.home_goals > r.away_goals) strongWins++; else if (r.away_goals > r.home_goals) weakWins++;
  }
  assert.ok(strongWins / n > 0.65, `favourite wins ${strongWins / n}`);
  assert.ok(strongWins / n < 0.97, 'results are not fully determined by ratings');
  assert.ok(weakWins > 0, 'upsets happen');
});

test('tactics have meaningful, opposing consequences', () => {
  const avg = (tacH, tacA, f, n = 200) => mean(Array.from({ length: n }, (_, i) => f(simulateMatch(team(2000 + i * 2, 60, tacH), team(2001 + i * 2, 60, tacA), 40000 + i))));
  const base = {};
  const shotsBase = avg(base, base, (r) => r.stats.home.shots), shotsAtt = avg({ mentality: 'very_attacking' }, base, (r) => r.stats.home.shots);
  assert.ok(shotsAtt > shotsBase + 0.5, `attacking creates more shots (${shotsAtt} vs ${shotsBase})`);
  const shotsDef = avg({ mentality: 'very_defensive' }, base, (r) => r.stats.home.shots);
  assert.ok(shotsDef < shotsBase, 'defensive mentality creates fewer shots');
  const eBase = avg(base, base, (r) => mean(r.players.filter((p) => p.team === 'home' && p.started).map((p) => p.energy)), 80);
  const eGeg = avg({ pressing: 'gegenpressing', pressing_intensity: 5, tempo: 5 }, base, (r) => mean(r.players.filter((p) => p.team === 'home' && p.started).map((p) => p.energy)), 80);
  assert.ok(eGeg < eBase - 10, `gegenpressing is exhausting (${eGeg} vs ${eBase})`);
  const counter = { approach: 'counter', mentality: 'defensive' };
  const concedeHigh = avg({ defensive_line: 5 }, counter, (r) => r.stats.away.xg), concedeLow = avg({ defensive_line: 1 }, counter, (r) => r.stats.away.xg);
  assert.ok(concedeHigh > concedeLow + 0.1, `a high line is exposed by pace (${concedeHigh} vs ${concedeLow})`);
});

// ---------- API ----------
let app, base;
test.before(async () => {
  app = createApp({ dbFile: ':memory:', registerLimitPerHour: 1000 });
  base = `http://127.0.0.1:${await app.listen(0, '127.0.0.1')}`;
});
test.after(() => app.close());
class Client {
  constructor() { this.cookie = ''; }
  async req(method, path, body) {
    const res = await fetch(base + path, { method, headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(this.cookie ? { Cookie: this.cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
    const sc = res.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0];
    let json = null; try { json = await res.json(); } catch { /* none */ }
    return { status: res.status, json };
  }
  get(p) { return this.req('GET', p); }
  post(p, b = {}) { return this.req('POST', p, b); }
}
const mk = async (u) => { const c = new Client(); assert.equal((await c.post('/api/auth/register', { email: `${u}@t.dev`, username: u, password: 'longenough1' })).status, 201); return c; };

let admin, alice, bob, carol, W, W2, aliceClub, bobClub;
test('setup: world with a full schedule', async () => {
  admin = await mk('p3admin'); alice = await mk('p3alice'); bob = await mk('p3bob'); carol = await mk('p3carol');
  W = (await alice.post('/api/worlds', { name: 'Match World', clubs: 8 })).json.world_id;
  W2 = (await alice.post('/api/worlds', { name: 'Quiet World', clubs: 8 })).json.world_id;
  const clubs = (await alice.get(`/api/worlds/${W}`)).json.clubs;
  aliceClub = clubs[0].id; bobClub = clubs[1].id;
  assert.equal((await alice.post(`/api/worlds/${W}/join`, { club_id: aliceClub })).status, 200);
  assert.equal((await bob.post(`/api/worlds/${W}/join`, { club_id: bobClub })).status, 200);
  const n = app.db.prepare('SELECT COUNT(*) AS n FROM fixtures WHERE world_id = ?').get(W).n;
  assert.equal(n, 8 * 7); // 14 rounds x 4 matches
  const comp = (await alice.get(`/api/worlds/${W}/competition`)).json;
  assert.equal(comp.world.total_rounds, 14); assert.equal(comp.world.rounds_played, 0);
  assert.equal(comp.next_round.length, 4); assert.equal(comp.table.length, 8);
  assert.ok(comp.table.every((t) => t.played === 0 && t.points === 0));
  assert.equal(comp.can_manage, true);
  assert.equal((await bob.get(`/api/worlds/${W}/competition`)).json.can_manage, false);
});

test('database rejects duplicate, double-booked and cross-world fixtures', () => {
  const f = app.db.prepare('SELECT * FROM fixtures WHERE world_id = ? LIMIT 1').get(W);
  const ins = (w, s, r, h, a) => app.db.prepare('INSERT INTO fixtures (world_id, season, round, home_club_id, away_club_id, game_date) VALUES (?,?,?,?,?,?)').run(w, s, r, h, a, '2030-01-01');
  assert.throws(() => ins(W, f.season, 99, f.home_club_id, f.away_club_id), /UNIQUE/);          // duplicate pairing
  const other = app.db.prepare('SELECT id FROM clubs WHERE world_id = ? AND id NOT IN (?,?) LIMIT 1').get(W, f.home_club_id, f.away_club_id);
  assert.throws(() => ins(W, f.season, f.round, f.home_club_id, other.id), /UNIQUE|invalid fixture/); // club twice in a round
  const foreign = app.db.prepare('SELECT id FROM clubs WHERE world_id = ? LIMIT 1').get(W2);
  assert.throws(() => ins(W, f.season, 98, f.home_club_id, foreign.id), /invalid fixture/);        // club from another world
});

test('only the world creator or an admin can advance the world', async () => {
  assert.equal((await bob.post(`/api/worlds/${W}/play-round`, { round: 1 })).status, 403);
  assert.equal((await new Client().post(`/api/worlds/${W}/play-round`, { round: 1 })).status, 401);
  assert.equal((await alice.post(`/api/worlds/${W}/play-round`, { round: 1, count: 0 })).status, 400);
});

test('playing round 1 produces consistent results, table and notifications', async () => {
  assert.equal((await alice.post(`/api/worlds/${W}/play-round`, { round: 5 })).json.code, 'round_mismatch');
  const r = await alice.post(`/api/worlds/${W}/play-round`, { round: 1 });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.rounds[0].results.length, 4);
  const comp = (await alice.get(`/api/worlds/${W}/competition`)).json;
  assert.equal(comp.world.rounds_played, 1);
  assert.ok(comp.table.every((t) => t.played === 1 && t.won + t.drawn + t.lost === 1 && t.points === t.won * 3 + t.drawn && t.gd === t.gf - t.ga));
  assert.equal(comp.table.reduce((s, t) => s + t.gf, 0), comp.table.reduce((s, t) => s + t.ga, 0));
  assert.equal(comp.table.reduce((s, t) => s + t.gf, 0), r.json.rounds[0].results.reduce((s, x) => s + x.home_goals + x.away_goals, 0));
  for (let i = 1; i < comp.table.length; i++) assert.ok(comp.table[i - 1].points >= comp.table[i].points, 'sorted by points');
  assert.equal(comp.last_round.length, 4);
  const notes = (await bob.get('/api/notifications')).json.notifications;
  assert.ok(notes.some((n) => n.kind === 'match' && /round 1/.test(n.body)));
});

test('a match centre record is complete and matches the scoreline', async () => {
  const f = (await alice.get(`/api/worlds/${W}/rounds/1`)).json.fixtures.find((x) => x.status === 'played');
  const m = (await alice.get(`/api/matches/${f.match_id}`)).json;
  assert.equal(m.home_goals, f.home_goals); assert.equal(m.away_goals, f.away_goals);
  assert.equal(m.events.filter((e) => e.type === 'goal').length, f.home_goals + f.away_goals);
  assert.ok(m.events.length > 20 && m.stats.home && m.players.length >= 22 && m.lineups.home.starters.length === 11 && m.motm);
  assert.equal((await alice.get('/api/matches/999999')).status, 404);
  assert.equal((await new Client().get(`/api/matches/${f.match_id}`)).status, 401);
});

test('double-submitting a round plays it exactly once', async () => {
  const rs = await Promise.all(Array.from({ length: 6 }, () => alice.post(`/api/worlds/${W}/play-round`, { round: 2 })));
  assert.equal(rs.filter((r) => r.status === 200).length, 1);
  assert.ok(rs.filter((r) => r.status !== 200).every((r) => r.json.code === 'round_mismatch'));
  assert.equal(app.db.prepare('SELECT rounds_played FROM worlds WHERE id = ?').get(W).rounds_played, 2);
  assert.equal(app.db.prepare("SELECT COUNT(*) AS n FROM matches WHERE world_id = ?").get(W).n, 8);
});

test('an invalid saved lineup is replaced by the assistant manager, not forfeited', async () => {
  const lu = (await alice.get(`/api/clubs/${aliceClub}/lineup`)).json.lineup;
  app.db.prepare("UPDATE players SET injured_until = '2099-01-01' WHERE id = ?").run(lu.slots[5].player_id);
  const injured = lu.slots[5].player_id;
  assert.equal((await alice.post(`/api/worlds/${W}/play-round`, { round: 3 })).status, 200);
  const f = app.db.prepare("SELECT match_id FROM fixtures WHERE world_id = ? AND round = 3 AND (home_club_id = ? OR away_club_id = ?)").get(W, aliceClub, aliceClub);
  const m = app.db.prepare('SELECT * FROM matches WHERE id = ?').get(f.match_id);
  assert.ok(JSON.parse(m.auto_lineup).includes(aliceClub));
  assert.ok(!JSON.parse(m.players).some((p) => p.player_id === injured), 'injured player did not play');
  assert.ok((await alice.get('/api/notifications')).json.notifications.some((n) => /assistant manager/.test(n.body)));
});

test('play the rest of the season: tables reconcile, bans are served, conditions stay in range', async () => {
  const r = await alice.post(`/api/worlds/${W}/play-round`, { round: 4, count: 20 }); // asks for more than remain
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.played_rounds, 11);
  const comp = (await alice.get(`/api/worlds/${W}/competition`)).json;
  assert.equal(comp.world.rounds_played, 14);
  assert.ok(comp.table.every((t) => t.played === 14 && t.points === t.won * 3 + t.drawn && t.won + t.drawn + t.lost === 14));
  assert.equal(comp.table.reduce((s, t) => s + t.points, 0), comp.table.reduce((s, t) => s + t.won * 3 + t.drawn, 0));
  assert.equal(comp.table.reduce((s, t) => s + t.won, 0), comp.table.reduce((s, t) => s + t.lost, 0));
  assert.equal((await alice.post(`/api/worlds/${W}/play-round`, { round: 15 })).json.code, 'season_complete');
  const bad = app.db.prepare('SELECT COUNT(*) AS n FROM players WHERE world_id = ? AND (fitness < 0 OR fitness > 100 OR morale < 0 OR morale > 100 OR suspended_matches < 0)').get(W).n;
  assert.equal(bad, 0);
  // a red-carded player never appears in the next two matches of his club
  const reds = app.db.prepare(`SELECT s.player_id, s.club_id, f.round FROM player_match_stats s JOIN matches m ON m.id = s.match_id JOIN fixtures f ON f.id = m.fixture_id WHERE s.world_id = ? AND s.rc > 0`).all(W);
  for (const red of reds) {
    const later = app.db.prepare(`SELECT COUNT(*) AS n FROM player_match_stats s JOIN matches m ON m.id = s.match_id JOIN fixtures f ON f.id = m.fixture_id
      WHERE s.world_id = ? AND s.player_id = ? AND f.round IN (?, ?)`).get(W, red.player_id, red.round + 1, red.round + 2).n;
    assert.equal(later, 0, `suspended player ${red.player_id} played again`);
  }
  // each club played each opponent home and away
  const pairs = app.db.prepare("SELECT home_club_id h, away_club_id a FROM fixtures WHERE world_id = ? AND status = 'played'").all(W);
  assert.equal(new Set(pairs.map((p) => `${p.h}-${p.a}`)).size, 56);
});

test('club schedule, leaders and world isolation', async () => {
  const s = (await alice.get(`/api/clubs/${aliceClub}/schedule`)).json;
  assert.equal(s.fixtures.length, 14); assert.ok(s.fixtures.every((f) => f.result && ['W', 'D', 'L'].includes(f.result)));
  assert.equal(s.fixtures.filter((f) => f.home).length, 7);
  const t = s.table_row; assert.equal(t.won, s.fixtures.filter((f) => f.result === 'W').length); assert.equal(t.points, t.won * 3 + t.drawn);
  const lead = (await alice.get(`/api/worlds/${W}/leaders`)).json;
  const totalGoals = app.db.prepare("SELECT COALESCE(SUM(home_goals + away_goals),0) AS g FROM fixtures WHERE world_id = ?").get(W).g;
  assert.ok(lead.scorers.length > 0 && lead.scorers[0].goals >= lead.scorers.at(-1).goals);
  assert.ok(lead.scorers.reduce((x, p) => x + p.goals, 0) <= totalGoals);
  assert.ok(lead.ratings.every((p) => p.avg_rating >= 3 && p.avg_rating <= 10 && p.apps >= 3));
  const quiet = (await alice.get(`/api/worlds/${W2}/competition`)).json;
  assert.equal(quiet.world.rounds_played, 0); assert.ok(quiet.table.every((x) => x.played === 0));
  assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM matches WHERE world_id = ?').get(W2).n, 0);
  assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM players WHERE world_id = ? AND (fitness < 92 OR morale < 62 OR morale > 80 OR injured_until IS NOT NULL OR suspended_matches != 0)').get(W2).n, 0, 'other world players untouched');
});

test('squad view reflects match consequences (fitness, injuries) for the manager only', async () => {
  const sq = (await alice.get(`/api/clubs/${aliceClub}/squad`)).json.players;
  assert.ok(sq.some((p) => p.fitness < 100) || true);
  const theirs = (await bob.get(`/api/clubs/${aliceClub}/squad`)).json.players;
  assert.ok(theirs.every((p) => !('fitness' in p)));
});
