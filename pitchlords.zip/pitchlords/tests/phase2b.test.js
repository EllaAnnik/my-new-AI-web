'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../server/index');

let app, base;
test.before(async () => {
  app = createApp({ dbFile: ':memory:', registerLimitPerHour: 1000 });
  base = `http://127.0.0.1:${await app.listen(0, '127.0.0.1')}`;
});
test.after(() => app.close());

class Client {
  constructor() { this.cookie = ''; }
  async req(method, path, body) {
    const res = await fetch(base + path, { method, headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(this.cookie ? { Cookie: this.cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
    const sc = res.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0];
    let json = null; try { json = await res.json(); } catch { /* none */ }
    return { status: res.status, json };
  }
  get(p) { return this.req('GET', p); }
  post(p, b = {}) { return this.req('POST', p, b); }
}
const mk = async (u) => { const c = new Client(); assert.equal((await c.post('/api/auth/register', { email: `${u}@t.dev`, username: u, password: 'longenough1' })).status, 201); return c; };

const { tx } = require('../server/db');
const money = require('../server/money');
// Test helper: move a balance the legitimate way (through the ledger).
const setBalance = (id, target) => tx(app.db, () => money.post(app.db, id, target - app.db.prepare('SELECT balance FROM clubs WHERE id = ?').get(id).balance, 'admin_adjustment', 'test setup'));
let m1, m2, club, club2;
const balance = (id) => app.db.prepare('SELECT balance FROM clubs WHERE id = ?').get(id).balance;
const squadOf = async (c, id) => (await c.get(`/api/clubs/${id}/squad`)).json.players;

test('setup: two managers in one world', async () => {
  m1 = await mk('money1'); m2 = await mk('money2');
  const w = (await m1.post('/api/worlds', { name: 'Money World', clubs: 8 })).json.world_id;
  const clubs = (await m1.get(`/api/worlds/${w}`)).json.clubs;
  club = clubs[0].id; club2 = clubs[1].id;
  await m1.post(`/api/worlds/${w}/join`, { club_id: club });
  await m2.post(`/api/worlds/${w}/join`, { club_id: club2 });
});

test('renewal: quote, refusal below demand, then success with ledger entry', async () => {
  const sq = await squadOf(m1, club);
  let target;
  for (const p of sq.filter((x) => !x.is_youth)) {
    const q = (await m1.get(`/api/clubs/${club}/players/${p.id}/contract-quote?years=3`)).json;
    if (q.can_renew) { target = { p, q }; break; }
  }
  assert.ok(target, 'at least one player is renewable');
  const { p, q } = target;
  assert.ok(q.demand_wage >= 500 && q.renewal_fee === q.demand_wage * 4);
  const bal = balance(club);
  const low = await m1.post(`/api/clubs/${club}/players/${p.id}/renew`, { years: 3, wage: q.demand_wage - 10 });
  assert.equal(low.status, 409); assert.equal(low.json.code, 'wage_too_low');
  assert.equal(balance(club), bal);
  assert.equal((await m1.post(`/api/clubs/${club}/players/${p.id}/renew`, { years: 9, wage: q.demand_wage })).status, 400);
  assert.equal((await m1.post(`/api/clubs/${club}/players/${p.id}/renew`, { years: 3, wage: 'lots' })).status, 400);
  const ok = await m1.post(`/api/clubs/${club}/players/${p.id}/renew`, { years: 3, wage: q.demand_wage });
  assert.equal(ok.status, 200, JSON.stringify(ok.json));
  assert.equal(balance(club), bal - q.demand_wage * 4);
  const after = (await squadOf(m1, club)).find((x) => x.id === p.id);
  assert.equal(after.wage, q.demand_wage); assert.equal(after.contract_expires, 2029);
  const led = (await m1.get(`/api/clubs/${club}/ledger`)).json.entries;
  assert.equal(led[0].kind, 'contract_renewal'); assert.equal(led[0].amount, -q.demand_wage * 4); assert.equal(led[0].balance_after, balance(club));
  // contract is now 3 years long: the same deal cannot be bought twice
  const again = await m1.post(`/api/clubs/${club}/players/${p.id}/renew`, { years: 3, wage: q.demand_wage });
  assert.equal(again.status, 409);
  assert.equal(balance(club), bal - q.demand_wage * 4);
});

test('a failed payment is atomic: insufficient funds changes nothing', async () => {
  const sq = await squadOf(m1, club);
  let target;
  for (const p of sq.filter((x) => !x.is_youth)) {
    const q = (await m1.get(`/api/clubs/${club}/players/${p.id}/contract-quote?years=2`)).json;
    if (q.can_renew) { target = { p, q }; break; }
  }
  assert.ok(target);
  setBalance(club, 100);
  const ledgerBefore = app.db.prepare('SELECT COUNT(*) AS n FROM finance_ledger WHERE club_id = ?').get(club).n;
  const r = await m1.post(`/api/clubs/${club}/players/${target.p.id}/renew`, { years: 2, wage: target.q.demand_wage });
  assert.equal(r.status, 409); assert.equal(r.json.code, 'insufficient_funds');
  assert.equal(balance(club), 100);
  assert.equal(app.db.prepare('SELECT COUNT(*) AS n FROM finance_ledger WHERE club_id = ?').get(club).n, ledgerBefore);
  const same = (await squadOf(m1, club)).find((x) => x.id === target.p.id);
  assert.equal(same.wage, target.p.wage); assert.equal(same.contract_expires, target.p.contract_expires);
  setBalance(club, 50000000);
});

test('double-submitted renewal pays once', async () => {
  const sq = await squadOf(m1, club);
  let target;
  for (const p of sq.filter((x) => !x.is_youth)) {
    const q = (await m1.get(`/api/clubs/${club}/players/${p.id}/contract-quote?years=4`)).json;
    if (q.can_renew) { target = { p, q }; break; }
  }
  assert.ok(target);
  const bal = balance(club);
  const rs = await Promise.all(Array.from({ length: 6 }, () => m1.post(`/api/clubs/${club}/players/${target.p.id}/renew`, { years: 4, wage: target.q.demand_wage })));
  assert.equal(rs.filter((r) => r.status === 200).length, 1);
  assert.equal(balance(club), bal - target.q.demand_wage * 4);
});

test('release: settlement paid, player becomes a free agent, lineup reset if he was picked', async () => {
  const lineup = (await m1.get(`/api/clubs/${club}/lineup`)).json.lineup;
  const starter = (await squadOf(m1, club)).find((p) => p.id === lineup.slots[3].player_id);
  const q = (await m1.get(`/api/clubs/${club}/players/${starter.id}/contract-quote`)).json;
  assert.ok(q.can_release && q.release_cost > 0);
  const bal = balance(club);
  const r = await m1.post(`/api/clubs/${club}/players/${starter.id}/release`);
  assert.equal(r.status, 200); assert.equal(r.json.lineup_reset, true); assert.equal(r.json.cost, q.release_cost);
  assert.equal(balance(club), bal - q.release_cost);
  const row = app.db.prepare('SELECT club_id, shirt_number, transfer_listed FROM players WHERE id = ?').get(starter.id);
  assert.equal(row.club_id, null); assert.equal(row.shirt_number, null);
  assert.ok(!(await squadOf(m1, club)).some((p) => p.id === starter.id));
  const fresh = (await m1.get(`/api/clubs/${club}/lineup`)).json.lineup; // default rebuilt
  assert.ok(!fresh.slots.some((s) => s.player_id === starter.id));
  assert.equal(fresh.slots.length, 11);
});

test('release rules: squad minimum, two keepers, nobody else\'s player, academy is free', async () => {
  const sq = await squadOf(m1, club);
  const keepers = sq.filter((p) => p.position === 'GK' && !p.is_youth);
  assert.equal(keepers.length, 3);
  assert.equal((await m1.post(`/api/clubs/${club}/players/${keepers[0].id}/release`)).status, 200);
  const blocked = await m1.post(`/api/clubs/${club}/players/${keepers[1].id}/release`);
  assert.equal(blocked.status, 409); assert.match(blocked.json.error, /two senior goalkeepers/);
  // run the squad down to the minimum
  let released = 0;
  for (;;) {
    const cur = (await squadOf(m1, club)).filter((p) => !p.is_youth && p.position !== 'GK');
    const r = await m1.post(`/api/clubs/${club}/players/${cur[cur.length - 1].id}/release`);
    if (r.status !== 200) { assert.match(r.json.error, /at least 18/); break; }
    released++; assert.ok(released < 20);
  }
  assert.equal((await squadOf(m1, club)).filter((p) => !p.is_youth).length, 18);
  const youth = (await squadOf(m1, club)).find((p) => p.is_youth);
  const bal = balance(club);
  assert.equal((await m1.post(`/api/clubs/${club}/players/${youth.id}/release`)).status, 200);
  assert.equal(balance(club), bal);
  // other manager's powers
  const theirs = (await squadOf(m2, club2))[0];
  assert.equal((await m1.post(`/api/clubs/${club}/players/${theirs.id}/release`)).status, 404);
  assert.equal((await m1.post(`/api/clubs/${club2}/players/${theirs.id}/release`)).status, 403);
  assert.equal((await m1.post(`/api/clubs/${club2}/players/${theirs.id}/renew`, { years: 2, wage: 9999 })).status, 403);
  assert.equal((await m1.get(`/api/clubs/${club2}/ledger`)).status, 403);
});

test('ledger is append-only and always reconciles with the balance', async () => {
  const rows = app.db.prepare('SELECT * FROM finance_ledger WHERE club_id = ? ORDER BY id').all(club);
  assert.ok(rows.length >= 3);
  assert.throws(() => app.db.prepare('UPDATE finance_ledger SET amount = 0 WHERE id = ?').run(rows[0].id), /append-only/);
  for (let i = 1; i < rows.length; i++) assert.equal(rows[i].balance_after, rows[i - 1].balance_after + rows[i].amount, `row ${i}`);
  assert.equal(rows[rows.length - 1].balance_after, balance(club));
});
