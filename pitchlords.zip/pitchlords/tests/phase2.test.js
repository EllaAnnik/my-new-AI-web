'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../server/index');
const F = require('../server/football');
const { generateSquad } = require('../server/players');

let app, base;
test.before(async () => {
  app = createApp({ dbFile: ':memory:', registerLimitPerHour: 1000 });
  base = `http://127.0.0.1:${await app.listen(0, '127.0.0.1')}`;
});
test.after(() => app.close());

class Client {
  constructor() { this.cookie = ''; }
  async req(method, path, body) {
    const res = await fetch(base + path, { method, headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(this.cookie ? { Cookie: this.cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
    const sc = res.headers.get('set-cookie');
    if (sc) this.cookie = sc.split(';')[0];
    let json = null; try { json = await res.json(); } catch { /* none */ }
    return { status: res.status, json };
  }
  get(p) { return this.req('GET', p); }
  post(p, b = {}) { return this.req('POST', p, b); }
  put(p, b) { return this.req('PUT', p, b); }
}
let n = 0;
async function user(name) {
  const c = new Client(); const u = name || `p2u${++n}`;
  assert.equal((await c.post('/api/auth/register', { email: `${u}@t.dev`, username: u, password: 'longenough1' })).status, 201);
  return c;
}

// ---- pure domain ----
test('overall formula and position familiarity', () => {
  const attrs = Object.fromEntries(F.ALL_ATTRS.map((k) => [k, 60]));
  assert.equal(F.computeOverall(attrs, 'ST'), 60);
  assert.equal(F.posFit('ST', 'ST'), 1);
  assert.ok(F.posFit('LW', 'RW') < 1 && F.posFit('LW', 'RW') > F.posFit('LW', 'CB'));
  assert.equal(F.posFit('CB', 'GK'), 0.2);
  assert.equal(F.ALL_ATTRS.length, 31);
});
test('every formation has 11 slots, exactly one GK, valid positions and on-pitch coordinates', () => {
  for (const [name, slots] of Object.entries(F.FORMATIONS)) {
    assert.equal(slots.length, 11, name);
    assert.equal(slots.filter((s) => s[0] === 'GK').length, 1, name);
    for (const [pos, x, y] of slots) { assert.ok(F.POSITIONS.includes(pos), name); assert.ok(x >= 0 && x <= 100 && y >= 0 && y <= 100); assert.ok(F.rolesFor(pos).length > 0); }
    const outfield = name.split('-').map(Number).reduce((a, b) => a + b, 0);
    assert.equal(outfield, 10, name + ' outfield count');
  }
});
test('squad generation is deterministic and well-formed', () => {
  const club = { id: 7, reputation: 80 };
  const a = generateSquad(12345, club, 2026), b = generateSquad(12345, club, 2026);
  assert.deepEqual(a, b);
  assert.notDeepEqual(a, generateSquad(54321, club, 2026));
  assert.equal(a.length, 29);
  assert.equal(a.filter((p) => p.position === 'GK' && !p.is_youth).length, 3);
  assert.equal(new Set(a.map((p) => p.shirt_number)).size, a.length);
  for (const p of a) {
    assert.equal(Object.keys(p.attrs).length, 31);
    assert.ok(Object.values(p.attrs).every((v) => v >= 1 && v <= 99));
    assert.equal(p.overall, F.computeOverall(p.attrs, p.position));
    assert.ok(p.potential >= p.overall && p.potential <= 99);
    if (p.is_youth) assert.ok(p.age <= 18 && p.potential - p.overall >= 10);
  }
});

// ---- API ----
let alice, bob, worldId, clubA, clubB, otherWorld;
test('worlds get full squads, stronger clubs have stronger squads', async () => {
  alice = await user('p2alice'); bob = await user('p2bob');
  worldId = (await alice.post('/api/worlds', { name: 'Squad World', clubs: 20 })).json.world_id;
  otherWorld = (await alice.post('/api/worlds', { name: 'Other World', clubs: 8 })).json.world_id;
  const clubs = (await alice.get(`/api/worlds/${worldId}`)).json.clubs; // sorted by reputation desc
  clubA = clubs[5]; clubB = clubs[6];
  assert.equal((await alice.post(`/api/worlds/${worldId}/join`, { club_id: clubA.id })).status, 200);
  assert.equal((await bob.post(`/api/worlds/${worldId}/join`, { club_id: clubB.id })).status, 200);
  const top = (await alice.get(`/api/clubs/${clubs[0].id}/squad`)).json.players.filter((p) => !p.is_youth);
  const bottom = (await alice.get(`/api/clubs/${clubs[19].id}/squad`)).json.players.filter((p) => !p.is_youth);
  const avg = (a) => a.reduce((s, p) => s + p.overall, 0) / a.length;
  assert.ok(avg(top) > avg(bottom) + 10, `top ${avg(top)} vs bottom ${avg(bottom)}`);
  const sq = (await alice.get(`/api/clubs/${clubA.id}/squad`)).json;
  assert.equal(sq.players.length, 29);
  assert.equal(sq.summary.senior_count, 25); assert.equal(sq.summary.youth_count, 4);
});
test('other managers only see public player information', async () => {
  const own = (await alice.get(`/api/clubs/${clubA.id}/squad`)).json;
  const theirs = (await bob.get(`/api/clubs/${clubA.id}/squad`)).json;
  assert.ok(own.players[0].attrs && own.players[0].potential !== undefined && own.summary);
  assert.equal(theirs.mine, false);
  assert.ok(!('attrs' in theirs.players[0]) && !('potential' in theirs.players[0]) && !('morale' in theirs.players[0]) && !('wage' in theirs.players[0]));
  assert.equal(theirs.summary, undefined); assert.equal(theirs.club.balance, undefined);
});

let lu;
test('default lineup is valid: 11 senior players, one keeper, no duplicates', async () => {
  const r = (await alice.get(`/api/clubs/${clubA.id}/lineup`)).json;
  lu = r.lineup;
  assert.equal(lu.formation, '4-3-3');
  assert.equal(lu.slots.length, 11);
  assert.equal(new Set(lu.slots.map((s) => s.player_id)).size, 11);
  const squad = (await alice.get(`/api/clubs/${clubA.id}/squad`)).json.players;
  const byId = new Map(squad.map((p) => [p.id, p]));
  assert.ok(lu.slots.every((s) => !byId.get(s.player_id).is_youth));
  assert.equal(byId.get(lu.slots[0].player_id).position, 'GK');
  assert.ok(lu.slots.slice(1).every((s) => byId.get(s.player_id).position !== 'GK'));
  assert.ok(lu.bench.length <= 7 && lu.bench.every((id) => !lu.slots.some((s) => s.player_id === id)));
  assert.ok(lu.slots.some((s) => s.player_id === lu.captain_id));
  assert.equal(r.meta.formations.length, Object.keys(F.FORMATIONS).length);
});
test('only the club manager can read or change lineup and tactics', async () => {
  assert.equal((await bob.get(`/api/clubs/${clubA.id}/lineup`)).status, 403);
  assert.equal((await bob.put(`/api/clubs/${clubA.id}/lineup`, lu)).status, 403);
  assert.equal((await bob.put(`/api/clubs/${clubA.id}/tactics`, F.DEFAULT_TACTICS)).status, 403);
  assert.equal((await new Client().get(`/api/clubs/${clubA.id}/squad`)).status, 401);
});

test('lineup validation rejects every kind of illegal selection', async () => {
  const put = (body) => alice.put(`/api/clubs/${clubA.id}/lineup`, { ...lu, ...body });
  const squad = (await alice.get(`/api/clubs/${clubA.id}/squad`)).json.players;
  const youth = squad.find((p) => p.is_youth);
  const outfielder = squad.find((p) => p.position !== 'GK' && !lu.slots.some((s) => s.player_id === p.id));
  const keeper2 = squad.find((p) => p.position === 'GK' && p.id !== lu.slots[0].player_id && !p.is_youth);
  const swap = (idx, pid) => lu.slots.map((s, i) => (i === idx ? { ...s, player_id: pid } : s));

  assert.equal((await put({ slots: swap(3, lu.slots[4].player_id) })).status, 400);           // duplicate
  assert.equal((await put({ slots: swap(3, youth.id) })).status, 400);                         // youth
  assert.equal((await put({ slots: swap(0, outfielder.id) })).status, 400);                    // outfielder in goal
  assert.equal((await put({ slots: swap(3, keeper2.id) })).status, 400);                       // keeper outfield
  assert.equal((await put({ slots: lu.slots.slice(0, 10) })).status, 400);                     // 10 players
  assert.equal((await put({ formation: '9-9-9' })).status, 400);
  assert.equal((await put({ slots: lu.slots.map((s, i) => (i === 3 ? { ...s, role: 'Target man' } : s)) })).status, 400); // wrong role for position
  assert.equal((await put({ slots: lu.slots.map((s, i) => (i === 3 ? { ...s, instruction: 'win_game' } : s)) })).status, 400);
  assert.equal((await put({ bench: [...lu.bench, 1, 2, 3, 4, 5] })).status, 400);              // oversized bench
  assert.equal((await put({ bench: [lu.slots[1].player_id] })).status, 400);                   // starter on bench
  assert.equal((await put({ captain_id: lu.bench[0] })).status, 400);                          // captain not starting
  assert.equal((await put({ penalty_taker_id: null })).status, 400);

  // a player from a different club (same world) and from a different world
  const bsquad = (await bob.get(`/api/clubs/${clubB.id}/squad`)).json.players;
  assert.equal((await put({ slots: swap(3, bsquad.find((p) => p.position === 'CB' && !p.is_youth).id) })).status, 400);
  const foreign = (await alice.get(`/api/worlds/${otherWorld}`)).json.clubs[0];
  const fsquad = (await alice.get(`/api/clubs/${foreign.id}/squad`)).json.players;
  assert.equal((await put({ slots: swap(3, fsquad.find((p) => p.position === 'CB' && !p.is_youth).id) })).status, 400);

  const after = (await alice.get(`/api/clubs/${clubA.id}/lineup`)).json.lineup;
  assert.deepEqual(after.slots, lu.slots); // nothing was half-saved
});

test('formation change via suggest, roles and instructions persist', async () => {
  const sug = (await alice.get(`/api/clubs/${clubA.id}/lineup/suggest?formation=3-5-2`)).json;
  assert.equal(sug.lineup.slots.length, 11); assert.equal(sug.slots.filter((s) => s.pos === 'CB').length, 3);
  assert.equal((await alice.get(`/api/clubs/${clubA.id}/lineup/suggest?formation=bogus`)).status, 400);
  const slots = sug.lineup.slots.map((s, i) => (sug.slots[i].pos === 'ST' && !s.role ? { ...s, role: 'Target man', instruction: 'hold_position' } : s));
  const r = await alice.put(`/api/clubs/${clubA.id}/lineup`, { ...sug.lineup, slots });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  const back = (await alice.get(`/api/clubs/${clubA.id}/lineup`)).json;
  assert.equal(back.lineup.formation, '3-5-2');
  assert.ok(back.lineup.slots.some((s) => s.role === 'Target man' && s.instruction === 'hold_position'));
  assert.equal(back.slots.length, 11);
});

test('tactics validation and persistence', async () => {
  const good = { ...F.DEFAULT_TACTICS, mentality: 'attacking', pressing: 'gegenpressing', tempo: 5, offside_trap: true };
  assert.equal((await alice.put(`/api/clubs/${clubA.id}/tactics`, good)).status, 200);
  assert.equal((await alice.get(`/api/clubs/${clubA.id}/lineup`)).json.tactics.pressing, 'gegenpressing');
  for (const bad of [{ mentality: 'yolo' }, { tempo: 6 }, { width: 0 }, { width: 2.5 }, { offside_trap: 'yes' }, { pressing: undefined }]) {
    assert.equal((await alice.put(`/api/clubs/${clubA.id}/tactics`, { ...good, ...bad })).status, 400, JSON.stringify(bad));
  }
  assert.equal((await alice.get(`/api/clubs/${clubA.id}/lineup`)).json.tactics.mentality, 'attacking');
});

test('transfer-list toggle and youth promotion', async () => {
  const squad = (await alice.get(`/api/clubs/${clubA.id}/squad`)).json.players;
  const p = squad.find((x) => !x.is_youth);
  assert.equal((await alice.post(`/api/clubs/${clubA.id}/players/${p.id}/transfer-list`, { listed: true })).status, 200);
  assert.equal((await alice.get(`/api/clubs/${clubA.id}/squad`)).json.players.find((x) => x.id === p.id).transfer_listed, true);
  assert.equal((await alice.post(`/api/clubs/${clubA.id}/players/${p.id}/transfer-list`, { listed: 'yes' })).status, 400);
  assert.equal((await bob.post(`/api/clubs/${clubA.id}/players/${p.id}/transfer-list`, { listed: false })).status, 403);
  // a manager cannot act on another club's player by using his own club id
  assert.equal((await bob.post(`/api/clubs/${clubB.id}/players/${p.id}/transfer-list`, { listed: true })).status, 404);

  const y = squad.find((x) => x.is_youth);
  const r = await alice.post(`/api/clubs/${clubA.id}/players/${y.id}/promote`);
  assert.equal(r.status, 200);
  const after = (await alice.get(`/api/clubs/${clubA.id}/squad`)).json;
  assert.equal(after.players.find((x) => x.id === y.id).is_youth, false);
  assert.equal(after.summary.senior_count, 26);
  assert.equal((await alice.post(`/api/clubs/${clubA.id}/players/${y.id}/promote`)).json.code, 'not_youth');
  // promoted player may now be selected
  const sug = (await alice.get(`/api/clubs/${clubA.id}/lineup/suggest?formation=4-4-2`)).json;
  assert.equal(sug.lineup.slots.length, 11);
});

test('database refuses to move a player into a club of another world', async () => {
  const p = app.db.prepare('SELECT id FROM players WHERE world_id = ? LIMIT 1').get(worldId);
  const foreignClub = app.db.prepare('SELECT id FROM clubs WHERE world_id = ? LIMIT 1').get(otherWorld);
  assert.throws(() => app.db.prepare('UPDATE players SET club_id = ? WHERE id = ?').run(foreignClub.id, p.id), /world mismatch/);
});
