# PITCHLORDS — Architecture

Original multiplayer football-management game. All clubs, players and leagues are fictional and procedurally generated (no licensed data).

## 1. Stack and why

| Layer | Choice | Reason |
|---|---|---|
| Runtime | Node.js 22 | Single language server/client, strong async I/O for many idle sockets |
| HTTP | Built-in `node:http` + small router | Zero dependencies (this environment has package installs disabled) |
| Database | SQLite via built-in `node:sqlite` (WAL mode) | Real transactions, runs here with no install. **All SQL lives in `server/repo/*`**, written in portable SQL, so the move to PostgreSQL is a driver swap |
| Auth | scrypt password hashes, random 256-bit session tokens (stored hashed), HttpOnly SameSite=Lax cookies | No external deps, standard practice |
| Realtime | Server-Sent Events | One-way push (notifications, chat, match ticks) is all the game needs; works through proxies; WebSockets can replace it later |
| Frontend | Vanilla ES modules SPA, no build step | React/Next/Tailwind cannot be installed here. Modules are split per screen so a React port is mechanical |
| Jobs | In-process world clock (tick loop) with DB-persisted `next_tick_at` | Worlds progress offline; later moves to a separate worker process |

**Honest deviation from the brief:** the brief suggests React/Next/Tailwind/PostgreSQL. Those need `npm install`/a server, which this environment blocks. The architecture keeps the seams (repository layer, JSON API, module-per-screen) so those swaps are contained. Production target remains PostgreSQL + a worker process + a reverse proxy.

## 2. Modules

```
server/
  index.js        bootstrap, static files, routing, SSE
  db.js           connection, migrations, transaction helper
  http.js         router, JSON body parsing, cookies, rate limiter
  auth.js         register/login/logout, sessions, roles
  worlds.js       world create/browse/join, club claim
  generate.js     seeded procedural club/name generation
  realtime.js     SSE hub, per-world and per-user channels
  clock.js        world clock (Phase 5 expands)
  (later) players, tactics, match, competitions, transfers, finance, training, scouting, messages, admin
public/           SPA
tests/            node:test suites
```

## 3. Schema (Phase 1 live; later tables planned)

Phase 1: `users`, `sessions`, `worlds`, `clubs`, `world_members`, `audit_log`, `notifications`.
Planned: `players`, `player_attributes`, `contracts`, `lineups`, `tactics`, `competitions`, `fixtures`, `matches`, `match_events`, `transfers`, `transfer_offers`, `finance_ledger`, `scouts`, `reports`, `messages`, `friends`.

Key rules:
- Every game row carries `world_id`; every query filters by it. Foreign keys + composite checks prevent cross-world references.
- Money is stored as whole integer currency units (never floats). From Phase 4 it changes only through an append-only `finance_ledger` inside a transaction.
- A club has at most one human manager: `clubs.manager_user_id` with a partial unique index; a user has one club per world (`UNIQUE(world_id,user_id)`).

## 4. How persistent multiplayer worlds work

A world is a row plus its own clubs, players, competitions. Its clock stores `game_date`, `speed`, `next_tick_at`. A scheduler loop wakes, finds worlds with `next_tick_at <= now`, runs the day's work in one transaction (train, play fixtures, age, contracts, AI decisions), and advances the date. Nothing depends on anyone being online. Humans act asynchronously (set tactics, answer offers); AI managers fill unclaimed clubs and play by the same rules through the same service functions, so there is no separate "AI cheat path".

## 5. Match simulation (Phase 3)

Deterministic from a stored seed (so results are reproducible and auditable, never client-supplied). Minute-by-minute possession chains:
1. Each phase, team strengths per zone (defence/midfield/attack) are computed from the XI's role-weighted attributes, then modified by fitness, morale, chemistry, home advantage, mentality, press and line height vs the opponent's counter-profile (e.g. high line vs pace, wing play vs narrow block).
2. A weighted state machine picks an outcome: retain, turnover, chance created, foul, etc. Chance quality (xG-like) is drawn from attacker vs defender attributes, then shot, on-target, keeper save/goal.
3. Fatigue accumulates by stamina/work rate/pressing; substitutions (manager rules or AI) and injuries/cards modify the XI.
4. Events are stored and rendered as commentary from templates; stats and ratings derive from events.

## 6. Hardest parts

1. Match engine balance (tactical rock-paper-scissors without a dominant strategy).
2. Transfer negotiation state machine plus AI valuation, with concurrency safety and anti-collusion.
3. Offline world clock: idempotent ticks, crash-safe recovery, fairness around deadlines.
4. Economy balance across seasons (inflation, wage spiral).
5. Scale: moving to PostgreSQL, a separate worker, and sharding worlds across workers.

## 7. Security model

Server is the only authority for results, ownership, balances. Passwords: scrypt + per-user salt. Sessions: opaque random token, SHA-256 stored, rotating on login, expiry. Rate limits per IP and per account on auth routes. Input validated server-side. Role checks (`player`, `moderator`, `admin`); admin actions written to `audit_log`. Same-site cookies plus `Content-Type: application/json` requirement and Origin check for state-changing requests.

## 8. Roadmap

| Phase | Scope | Status |
|---|---|---|
| 1 | Foundation: auth, DB, worlds, clubs, claim, SPA shell | done |
| 2 | Players, squad, formations, tactics, club dashboard, contracts | done |
| 3 | Match engine, commentary, stats, league tables, fixtures | done |
| 4 | Transfers, negotiations, contracts, finances, scouting | next |
| 5 | Fixtures, cups, promotion/relegation, training, seasons | |
| 6 | Messaging, notifications, rankings, admin | |
| 7 | Load/security tests, Postgres port, deployment | |
