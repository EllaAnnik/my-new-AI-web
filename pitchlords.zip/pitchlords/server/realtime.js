'use strict';
// Server-Sent Events hub. Clients subscribe once; server pushes JSON events.

class Hub {
  constructor() {
    this.byUser = new Map(); // userId -> Set<res>
    this.timer = setInterval(() => this.ping(), 25_000);
    this.timer.unref();
  }
  subscribe(userId, res) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.write('retry: 3000\n\n');
    let set = this.byUser.get(userId);
    if (!set) this.byUser.set(userId, (set = new Set()));
    set.add(res);
    res.on('close', () => {
      set.delete(res);
      if (!set.size) this.byUser.delete(userId);
    });
  }
  sendTo(userId, event, data) {
    const set = this.byUser.get(userId);
    if (!set) return;
    const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const res of set) res.write(msg);
  }
  broadcast(event, data, userIds) {
    for (const id of userIds) this.sendTo(id, event, data);
  }
  broadcastAll(event, data) {
    for (const id of this.byUser.keys()) this.sendTo(id, event, data);
  }
  ping() {
    for (const set of this.byUser.values()) for (const res of set) res.write(': ping\n\n');
  }
  close() {
    clearInterval(this.timer);
    for (const set of this.byUser.values()) for (const res of set) res.end();
    this.byUser.clear();
  }
}
module.exports = { Hub };
