'use strict';
const crypto = require('node:crypto');
const { bad, unauthorized, forbidden, conflict, HttpError, randomToken, sha256 } = require('./http');
const { tx } = require('./db');

const SESSION_DAYS = 30;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const USER_RE = /^[A-Za-z0-9_]{3,20}$/;

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}
function verifyPassword(pw, stored) {
  const [alg, s, k] = String(stored).split('$');
  if (alg !== 'scrypt') return false;
  const expected = Buffer.from(k, 'base64');
  const key = crypto.scryptSync(pw, Buffer.from(s, 'base64'), expected.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(key, expected);
}
// Burn comparable time for unknown accounts so login timing doesn't reveal which exist.
const DUMMY_HASH = hashPassword('dummy-password-for-timing');

function publicUser(u) {
  return { id: u.id, username: u.username, email: u.email, role: u.role, created_at: u.created_at };
}

function createSession(db, userId) {
  const token = randomToken();
  const expires = new Date(Date.now() + SESSION_DAYS * 86400_000).toISOString();
  db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?,?,?)').run(sha256(token), userId, expires);
  return { token, maxAge: SESSION_DAYS * 86400 };
}

function userFromToken(db, token) {
  if (!token) return null;
  const row = db.prepare(
    `SELECT u.*, s.id AS session_id FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = ? AND s.expires_at > ?`
  ).get(sha256(token), new Date().toISOString());
  return row || null;
}

function register(db, { email, username, password }, ip) {
  email = String(email || '').trim();
  username = String(username || '').trim();
  password = String(password || '');
  if (!EMAIL_RE.test(email) || email.length > 120) throw bad('Enter a valid email address');
  if (!USER_RE.test(username)) throw bad('Username must be 3-20 letters, numbers or underscores');
  if (password.length < 8 || password.length > 200) throw bad('Password must be at least 8 characters');
  const hash = hashPassword(password);
  return tx(db, () => {
    const exists = db.prepare('SELECT 1 FROM users WHERE email = ? OR username = ?').get(email, username);
    if (exists) throw conflict('That email or username is already registered', 'duplicate');
    // Bootstrap: the very first account becomes the administrator.
    const first = db.prepare('SELECT COUNT(*) AS n FROM users').get().n === 0;
    const role = first ? 'admin' : 'player';
    const info = db.prepare('INSERT INTO users (email, username, pass_hash, role) VALUES (?,?,?,?)').run(email, username, hash, role);
    const id = Number(info.lastInsertRowid);
    if (first) db.prepare('INSERT INTO audit_log (actor_id, action, target, detail, ip) VALUES (?,?,?,?,?)').run(id, 'bootstrap_admin', `user:${id}`, 'First registered account promoted to admin', ip);
    return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  });
}

function login(db, { identifier, password }) {
  identifier = String(identifier || '').trim();
  password = String(password || '');
  const u = db.prepare('SELECT * FROM users WHERE email = ? OR username = ?').get(identifier, identifier);
  const ok = verifyPassword(password, u ? u.pass_hash : DUMMY_HASH);
  if (!u || !ok) throw new HttpError(401, 'Incorrect credentials', 'bad_credentials');
  if (u.status === 'suspended') throw forbidden(`Account suspended${u.suspended_reason ? ': ' + u.suspended_reason : ''}`);
  return u;
}

function requireUser(req) {
  if (!req.user) throw unauthorized();
  if (req.user.status === 'suspended') throw forbidden('Account suspended');
  return req.user;
}
function requireRole(req, ...roles) {
  const u = requireUser(req);
  if (!roles.includes(u.role)) throw forbidden('Insufficient permissions');
  return u;
}

module.exports = { register, login, createSession, userFromToken, publicUser, requireUser, requireRole, hashPassword };
