'use strict';
// The ONLY place club balances change. Callers must already be inside tx() so the balance
// change, the ledger row and whatever caused them commit (or roll back) together.
const { conflict } = require('./http');

const fmt = (n) => '£' + Number(n).toLocaleString('en-GB');

function post(db, clubId, amount, kind, description) {
  if (!Number.isSafeInteger(amount)) throw new Error('Ledger amount must be a safe integer');
  const club = db.prepare('SELECT balance, world_id FROM clubs WHERE id = ?').get(clubId);
  if (!club) throw new Error('Unknown club');
  const after = club.balance + amount;
  if (amount < 0 && after < 0) {
    throw conflict(`Insufficient funds: this costs ${fmt(-amount)} but the club only has ${fmt(club.balance)}`, 'insufficient_funds');
  }
  db.prepare('UPDATE clubs SET balance = ? WHERE id = ?').run(after, clubId);
  db.prepare('INSERT INTO finance_ledger (club_id, world_id, amount, balance_after, kind, description) VALUES (?,?,?,?,?,?)')
    .run(clubId, club.world_id, amount, after, kind, description);
  return after;
}

function recent(db, clubId, limit = 50) {
  return db.prepare('SELECT id, amount, balance_after, kind, description, created_at FROM finance_ledger WHERE club_id = ? ORDER BY id DESC LIMIT ?').all(clubId, limit);
}

module.exports = { post, recent, fmt };
