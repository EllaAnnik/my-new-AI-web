'use strict';
// Squad, lineup and tactics logic. Every mutation is validated here; the client is never trusted.
const F = require('./football');
const { bad, forbidden, notFound, conflict } = require('./http');
const { tx } = require('./db');
const money = require('./money');

const MAX_SENIOR = 30;
const BENCH_MAX = 7;

function rowToPlayer(r) {
  return { ...r, attrs: JSON.parse(r.attrs), is_youth: !!r.is_youth, transfer_listed: !!r.transfer_listed };
}
const isAvailable = (p, gameDate) => !(p.injured_until && p.injured_until > gameDate) && !(p.suspended_matches > 0);

function getClub(db, clubId) {
  const c = db.prepare(
    `SELECT c.*, w.game_date, w.season, w.name AS world_name FROM clubs c JOIN worlds w ON w.id = c.world_id WHERE c.id = ?`
  ).get(clubId);
  if (!c) throw notFound('Club not found');
  return c;
}
function ownClub(db, user, clubId) {
  const c = getClub(db, clubId);
  if (c.manager_user_id !== user.id) throw forbidden('You do not manage this club');
  return c;
}
const clubPlayers = (db, clubId) => db.prepare('SELECT * FROM players WHERE club_id = ? ORDER BY is_youth, overall DESC').all(clubId).map(rowToPlayer);

function summary(players, club) {
  const senior = players.filter((p) => !p.is_youth);
  const avg = (a, f) => (a.length ? Math.round((a.reduce((s, p) => s + f(p), 0) / a.length) * 10) / 10 : 0);
  return {
    senior_count: senior.length, youth_count: players.length - senior.length,
    avg_overall: avg(senior, (p) => p.overall), avg_age: avg(senior, (p) => p.age),
    avg_fitness: avg(senior, (p) => p.fitness), avg_morale: avg(senior, (p) => p.morale),
    weekly_wage_bill: players.reduce((s, p) => s + p.wage, 0), squad_value: players.reduce((s, p) => s + p.value, 0),
    injured: senior.filter((p) => !isAvailable(p, club.game_date)).length,
    top_overall: senior.length ? Math.max(...senior.map((p) => p.overall)) : 0,
  };
}

/** Own club: full detail. Other clubs: public information only (no attributes, potential, fitness or morale). */
function getSquad(db, user, clubId) {
  const club = getClub(db, clubId);
  const mine = club.manager_user_id === user.id;
  const all = clubPlayers(db, clubId);
  const players = all.map((p) => {
    const base = {
      id: p.id, first_name: p.first_name, last_name: p.last_name, age: p.age, nationality: p.nationality, position: p.position,
      height_cm: p.height_cm, foot: p.foot, shirt_number: p.shirt_number, value: p.value, overall: p.overall, is_youth: p.is_youth,
      contract_expires: p.contract_expires, transfer_listed: p.transfer_listed,
      available: isAvailable(p, club.game_date),
    };
    if (!mine) return base;
    // Server-computed so the client never re-implements (and drifts from) the rating formulas.
    const ratings = Object.fromEntries(F.POSITIONS.map((pos) => [pos, F.ratingAt(p, pos)]));
    const role_fit = Object.fromEntries(Object.keys(F.ROLE_ATTRS).map((r) => [r, F.roleFit(p.attrs, r)]));
    return { ...base, wage: p.wage, potential: p.potential, attrs: p.attrs, fitness: p.fitness, morale: p.morale, injured_until: p.injured_until, suspended_matches: p.suspended_matches, ratings, role_fit };
  });
  return {
    club: { id: club.id, name: club.name, short_name: club.short_name, color1: club.color1, color2: club.color2, world_id: club.world_id, reputation: club.reputation, stadium_name: club.stadium_name, stadium_capacity: club.stadium_capacity, balance: mine ? club.balance : undefined, manager_user_id: club.manager_user_id },
    mine, players, summary: mine ? summary(all, club) : undefined,
  };
}

// ---------- lineup ----------
function autoPick(players, formation, gameDate) {
  const slots = F.formationSlots(formation);
  const pool = players.filter((p) => !p.is_youth && isAvailable(p, gameDate));
  const used = new Set();
  const out = new Array(slots.length).fill(null);
  const order = [...slots].sort((a, b) => (a.pos === 'GK' ? -1 : b.pos === 'GK' ? 1 : 0));
  for (const s of order) {
    let best = null, bestR = -1;
    for (const p of pool) {
      if (used.has(p.id)) continue;
      if (s.pos === 'GK' !== (p.position === 'GK')) continue; // keepers only in goal, never outfield
      const r = F.ratingAt(p, s.pos);
      if (r > bestR) { best = p; bestR = r; }
    }
    if (!best) throw conflict('Not enough available players for this formation', 'squad_too_thin');
    used.add(best.id);
    out[s.slot] = { slot: s.slot, player_id: best.id, role: null, instruction: null };
  }
  const rest = pool.filter((p) => !used.has(p.id)).sort((a, b) => b.overall - a.overall);
  const bench = [];
  const gk = rest.find((p) => p.position === 'GK');
  if (gk) bench.push(gk.id);
  for (const p of rest) if (bench.length < BENCH_MAX && !bench.includes(p.id)) bench.push(p.id);
  const starters = out.map((o) => pool.find((p) => p.id === o.player_id));
  const best = (key) => starters.reduce((a, b) => (key(b) > key(a) ? b : a), starters[0]).id;
  return {
    formation, slots: out, bench,
    captain_id: best((p) => p.attrs.leadership + p.attrs.composure * 0.3),
    penalty_taker_id: best((p) => p.attrs.finishing + p.attrs.composure),
    freekick_taker_id: best((p) => p.attrs.set_pieces + p.attrs.long_shots * 0.5),
    corner_taker_id: best((p) => p.attrs.crossing + p.attrs.set_pieces),
  };
}

function loadLineupRow(db, club) {
  const row = db.prepare('SELECT * FROM lineups WHERE club_id = ?').get(club.id);
  if (!row) return null;
  return {
    formation: row.formation, slots: JSON.parse(row.slots), bench: JSON.parse(row.bench), captain_id: row.captain_id,
    penalty_taker_id: row.penalty_taker_id, freekick_taker_id: row.freekick_taker_id, corner_taker_id: row.corner_taker_id, updated_at: row.updated_at,
  };
}
function saveLineup(db, clubId, l) {
  db.prepare(
    `INSERT INTO lineups (club_id, formation, slots, bench, captain_id, penalty_taker_id, freekick_taker_id, corner_taker_id, updated_at)
     VALUES (?,?,?,?,?,?,?,?,datetime('now'))
     ON CONFLICT(club_id) DO UPDATE SET formation=excluded.formation, slots=excluded.slots, bench=excluded.bench, captain_id=excluded.captain_id,
       penalty_taker_id=excluded.penalty_taker_id, freekick_taker_id=excluded.freekick_taker_id, corner_taker_id=excluded.corner_taker_id, updated_at=datetime('now')`
  ).run(clubId, l.formation, JSON.stringify(l.slots), JSON.stringify(l.bench), l.captain_id, l.penalty_taker_id, l.freekick_taker_id, l.corner_taker_id);
}

/** Current lineup + tactics for the manager's club. Creates a sensible default the first time. */
function getLineup(db, user, clubId) {
  const club = ownClub(db, user, clubId);
  return tx(db, () => {
    let lineup = loadLineupRow(db, club);
    const players = clubPlayers(db, clubId);
    if (!lineup) { lineup = autoPick(players, '4-3-3', club.game_date); saveLineup(db, clubId, lineup); }
    const t = db.prepare('SELECT data FROM tactics WHERE club_id = ?').get(clubId);
    const tactics = t ? { ...F.DEFAULT_TACTICS, ...JSON.parse(t.data) } : { ...F.DEFAULT_TACTICS };
    return { lineup, tactics, slots: F.formationSlots(lineup.formation), meta: tacticMeta() };
  });
}
const tacticMeta = () => ({ formations: Object.keys(F.FORMATIONS), roles: Object.fromEntries(F.POSITIONS.map((p) => [p, F.rolesFor(p)])), enums: F.TACTIC_ENUMS, sliders: F.TACTIC_SLIDERS, flags: F.TACTIC_FLAGS, instructions: F.INSTRUCTIONS });

function suggestLineup(db, user, clubId, formation) {
  const club = ownClub(db, user, clubId);
  if (!F.FORMATIONS[formation]) throw bad('Unknown formation');
  const lineup = autoPick(clubPlayers(db, clubId), formation, club.game_date);
  return { lineup, slots: F.formationSlots(formation) };
}

function setLineup(db, user, clubId, body) {
  const club = ownClub(db, user, clubId);
  const { formation } = body;
  if (!F.FORMATIONS[formation]) throw bad('Unknown formation');
  const slotDefs = F.formationSlots(formation);
  if (!Array.isArray(body.slots) || body.slots.length !== slotDefs.length) throw bad(`Formation ${formation} needs exactly ${slotDefs.length} players`);
  if (!Array.isArray(body.bench) || body.bench.length > BENCH_MAX) throw bad(`Bench holds at most ${BENCH_MAX} players`);
  return tx(db, () => {
    const players = new Map(clubPlayers(db, clubId).map((p) => [p.id, p]));
    const seen = new Set();
    const slots = [];
    for (const def of slotDefs) {
      const s = body.slots.find((x) => x && Number(x.slot) === def.slot);
      if (!s) throw bad(`Slot ${def.slot} is missing`);
      const pid = Number(s.player_id);
      const p = players.get(pid);
      if (!p) throw bad('Lineup contains a player who is not in your squad');
      if (p.is_youth) throw bad(`${p.last_name} is in the youth academy; promote him first`);
      if (!isAvailable(p, club.game_date)) throw bad(`${p.last_name} is injured or suspended`);
      if (seen.has(pid)) throw bad(`${p.last_name} is selected twice`);
      if ((def.pos === 'GK') !== (p.position === 'GK')) throw bad(def.pos === 'GK' ? 'Only a goalkeeper can play in goal' : 'A goalkeeper cannot play outfield');
      seen.add(pid);
      let role = s.role ?? null;
      if (role !== null && !F.rolesFor(def.pos).includes(role)) throw bad(`Role "${role}" is not available at ${def.pos}`);
      const instruction = s.instruction ?? null;
      if (instruction !== null && !F.INSTRUCTIONS.includes(instruction)) throw bad('Unknown player instruction');
      slots.push({ slot: def.slot, player_id: pid, role, instruction });
    }
    const bench = [];
    for (const raw of body.bench) {
      const pid = Number(raw);
      const p = players.get(pid);
      if (!p) throw bad('Bench contains a player who is not in your squad');
      if (p.is_youth) throw bad(`${p.last_name} is in the youth academy; promote him first`);
      if (seen.has(pid)) throw bad(`${p.last_name} is already in the lineup`);
      seen.add(pid); bench.push(pid);
    }
    const starterIds = new Set(slots.map((s) => s.player_id));
    const starterOnly = (id, label) => {
      if (id === null || id === undefined) throw bad(`Choose a ${label}`);
      if (!starterIds.has(Number(id))) throw bad(`The ${label} must be in the starting XI`);
      return Number(id);
    };
    const lineup = {
      formation, slots, bench,
      captain_id: starterOnly(body.captain_id, 'captain'),
      penalty_taker_id: starterOnly(body.penalty_taker_id, 'penalty taker'),
      freekick_taker_id: starterOnly(body.freekick_taker_id, 'free-kick taker'),
      corner_taker_id: starterOnly(body.corner_taker_id, 'corner taker'),
    };
    saveLineup(db, clubId, lineup);
    return { lineup };
  });
}

function setTactics(db, user, clubId, body) {
  ownClub(db, user, clubId);
  const t = {};
  for (const [k, allowed] of Object.entries(F.TACTIC_ENUMS)) {
    if (!allowed.includes(body[k])) throw bad(`Invalid ${k.replace('_', ' ')}`);
    t[k] = body[k];
  }
  for (const k of F.TACTIC_SLIDERS) {
    const v = Number(body[k]);
    if (!Number.isInteger(v) || v < 1 || v > 5) throw bad(`${k.replace(/_/g, ' ')} must be a whole number from 1 to 5`);
    t[k] = v;
  }
  for (const k of F.TACTIC_FLAGS) {
    if (typeof body[k] !== 'boolean') throw bad(`${k.replace(/_/g, ' ')} must be on or off`);
    t[k] = body[k];
  }
  db.prepare(`INSERT INTO tactics (club_id, data, updated_at) VALUES (?,?,datetime('now'))
    ON CONFLICT(club_id) DO UPDATE SET data = excluded.data, updated_at = datetime('now')`).run(clubId, JSON.stringify(t));
  return { tactics: t };
}

// ---------- player actions ----------
function ownPlayer(db, user, clubId, playerId) {
  const club = ownClub(db, user, clubId);
  const p = db.prepare('SELECT * FROM players WHERE id = ? AND club_id = ?').get(playerId, clubId);
  if (!p) throw notFound('Player not found at your club');
  return { club, player: rowToPlayer(p) };
}

function setTransferListed(db, user, clubId, playerId, listed) {
  if (typeof listed !== 'boolean') throw bad('listed must be true or false');
  ownPlayer(db, user, clubId, playerId);
  db.prepare('UPDATE players SET transfer_listed = ? WHERE id = ?').run(listed ? 1 : 0, playerId);
  return { player_id: playerId, transfer_listed: listed };
}

function promoteYouth(db, user, clubId, playerId) {
  return tx(db, () => {
    const { player } = ownPlayer(db, user, clubId, playerId);
    if (!player.is_youth) throw conflict('Player is already in the first-team squad', 'not_youth');
    const n = db.prepare('SELECT COUNT(*) AS n FROM players WHERE club_id = ? AND is_youth = 0').get(clubId).n;
    if (n >= MAX_SENIOR) throw conflict(`First-team squad is full (${MAX_SENIOR})`, 'squad_full');
    const used = new Set(db.prepare('SELECT shirt_number FROM players WHERE club_id = ?').all(clubId).map((r) => r.shirt_number));
    let num = 32; while (used.has(num)) num++;
    // Players are promoted onto a senior-minimum contract; wage scales with ability.
    const wage = Math.max(500, Math.round(player.value / 1600 / 10) * 10);
    db.prepare('UPDATE players SET is_youth = 0, shirt_number = ?, wage = ? WHERE id = ?').run(num, wage, playerId);
    return { player_id: playerId, shirt_number: num, wage };
  });
}

// ---------- contracts ----------
const MIN_SENIOR = 18;
const gameYear = (club) => Number(String(club.game_date).slice(0, 4));
const yearsLeft = (p, club) => Math.max(1, p.contract_expires - gameYear(club));
const baseWage = (p) => Math.max(500, Math.round(p.value / 1600 / 10) * 10);

/** What a player will accept to re-sign. Deterministic: unhappy players cost more, veterans less. */
function demandWage(p, years) {
  const moraleF = 1.25 - p.morale / 400; // morale 100 -> 1.00, 60 -> 1.10
  const ageF = p.age >= 32 ? 0.9 : p.age <= 21 && p.potential - p.overall >= 8 ? 1.1 : 1;
  const yearF = years >= 4 ? 1.05 : 1;
  return Math.max(500, Math.round((baseWage(p) * moraleF * ageF * yearF) / 10) * 10);
}

function contractQuote(db, user, clubId, playerId, yearsRaw) {
  const { club, player: p } = ownPlayer(db, user, clubId, playerId);
  const years = yearsRaw === undefined ? 3 : Number(yearsRaw);
  if (!Number.isInteger(years) || years < 1 || years > 5) throw bad('Contract length must be 1 to 5 years');
  const demand = demandWage(p, years);
  let renewBlock = null;
  if (p.is_youth) renewBlock = 'Academy players sign senior terms when promoted';
  else if (p.morale < 40) renewBlock = `${p.last_name} is unhappy and refuses to negotiate`;
  else if (yearsLeft(p, club) > 3) renewBlock = 'Contract still has more than 3 years to run';
  else if (gameYear(club) + years <= p.contract_expires) renewBlock = 'The new deal would not extend his current contract';
  const seniors = db.prepare('SELECT position FROM players WHERE club_id = ? AND is_youth = 0').all(clubId);
  let releaseBlock = null;
  if (!p.is_youth && seniors.length <= MIN_SENIOR) releaseBlock = `You need at least ${MIN_SENIOR} first-team players`;
  else if (!p.is_youth && p.position === 'GK' && seniors.filter((s) => s.position === 'GK').length <= 2) releaseBlock = 'You must keep at least two senior goalkeepers';
  return {
    player_id: p.id, years, current_wage: p.wage, demand_wage: demand, renewal_fee: demand * 4,
    can_renew: !renewBlock, renew_block: renewBlock,
    release_cost: p.is_youth ? 0 : Math.round(p.wage * 52 * yearsLeft(p, club) * 0.5),
    can_release: !releaseBlock, release_block: releaseBlock, balance: club.balance,
  };
}

function renewContract(db, user, clubId, playerId, body) {
  return tx(db, () => {
    const years = Number(body.years), wage = Number(body.wage);
    const q = contractQuote(db, user, clubId, playerId, years);
    if (!q.can_renew) throw conflict(q.renew_block, 'cannot_renew');
    if (!Number.isInteger(wage) || wage < 1 || wage > 1_000_000) throw bad('Enter a valid weekly wage');
    const p = db.prepare('SELECT * FROM players WHERE id = ?').get(playerId);
    if (wage < q.demand_wage) throw conflict(`${p.last_name} wants at least ${money.fmt(q.demand_wage)} a week for a ${years}-year deal`, 'wage_too_low');
    const club = getClub(db, clubId);
    const fee = wage * 4; // loyalty bonus: four weeks of the new wage
    money.post(db, clubId, -fee, 'contract_renewal', `Renewed ${p.first_name} ${p.last_name} to ${gameYear(club) + years} at ${money.fmt(wage)}/wk`);
    db.prepare('UPDATE players SET wage = ?, contract_expires = ?, morale = MIN(100, morale + 5) WHERE id = ?').run(wage, gameYear(club) + years, playerId);
    return { player_id: playerId, wage, contract_expires: gameYear(club) + years, fee };
  });
}

function releasePlayer(db, user, clubId, playerId) {
  return tx(db, () => {
    const q = contractQuote(db, user, clubId, playerId);
    if (!q.can_release) throw conflict(q.release_block, 'cannot_release');
    const p = db.prepare('SELECT * FROM players WHERE id = ?').get(playerId);
    if (q.release_cost > 0) money.post(db, clubId, -q.release_cost, 'player_release', `Contract settlement for ${p.first_name} ${p.last_name}`);
    db.prepare('UPDATE players SET club_id = NULL, shirt_number = NULL, transfer_listed = 0 WHERE id = ?').run(playerId);
    // A saved lineup that still names him is no longer legal; drop it and let the default rebuild.
    const l = db.prepare('SELECT * FROM lineups WHERE club_id = ?').get(clubId);
    let reset = false;
    if (l) {
      const named = JSON.parse(l.slots).some((s) => s.player_id === playerId) || JSON.parse(l.bench).includes(playerId)
        || [l.captain_id, l.penalty_taker_id, l.freekick_taker_id, l.corner_taker_id].includes(playerId);
      if (named) { db.prepare('DELETE FROM lineups WHERE club_id = ?').run(clubId); reset = true; }
    }
    return { player_id: playerId, cost: q.release_cost, lineup_reset: reset };
  });
}

function ledger(db, user, clubId) {
  ownClub(db, user, clubId);
  return { entries: money.recent(db, clubId) };
}

module.exports = { isAvailable, contractQuote, renewContract, releasePlayer, ledger, getSquad, getLineup, suggestLineup, setLineup, setTactics, setTransferListed, promoteYouth, ownClub, autoPick, getClub, clubPlayers, summary };
