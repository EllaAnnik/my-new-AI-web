'use strict';
// Plays a round of fixtures: builds teams server-side, runs the engine, persists everything in ONE transaction.
// The client never supplies a result, a lineup snapshot or a seed.
const F = require('./football');
const E = require('./engine');
const S = require('./squad');
const FX = require('./fixtures');
const { rng } = require('./generate');
const { tx } = require('./db');
const { bad, forbidden, notFound, conflict } = require('./http');

const RECOVERY = 32;
const FORMATIONS = Object.keys(F.FORMATIONS);

function loadPlayers(db, clubId) {
  return S.clubPlayers(db, clubId);
}

function lineupIsValid(l, players, gameDate) {
  if (!l || !F.FORMATIONS[l.formation]) return false;
  const byId = new Map(players.map((p) => [p.id, p]));
  const defs = F.formationSlots(l.formation);
  if (!Array.isArray(l.slots) || l.slots.length !== defs.length) return false;
  const seen = new Set();
  for (const def of defs) {
    const s = l.slots.find((x) => x.slot === def.slot);
    const p = s && byId.get(s.player_id);
    if (!p || p.is_youth || seen.has(p.id) || !S.isAvailable(p, gameDate)) return false;
    if ((def.pos === 'GK') !== (p.position === 'GK')) return false;
    seen.add(p.id);
  }
  return true;
}

/** Never fail to field a team: normal pick, then include academy players, then ignore injuries. */
function pickEleven(players, formation, gameDate) {
  const attempts = [
    () => S.autoPick(players, formation, gameDate),
    () => S.autoPick(players.map((p) => ({ ...p, is_youth: false })), formation, gameDate),
    () => S.autoPick(players.map((p) => ({ ...p, is_youth: false, injured_until: null, suspended_matches: 0 })), formation, gameDate),
  ];
  let last;
  for (const a of attempts) { try { return a(); } catch (e) { last = e; } }
  throw last;
}

function buildTeam(db, club, world, gameDate, strengthOf, seasonSeed) {
  const players = loadPlayers(db, club.id);
  const byId = new Map(players.map((p) => [p.id, p]));
  const row = db.prepare('SELECT * FROM lineups WHERE club_id = ?').get(club.id);
  const saved = row ? { formation: row.formation, slots: JSON.parse(row.slots), bench: JSON.parse(row.bench), captain_id: row.captain_id, penalty_taker_id: row.penalty_taker_id, freekick_taker_id: row.freekick_taker_id, corner_taker_id: row.corner_taker_id } : null;
  const human = !!club.manager_user_id;
  let lineup, tactics, auto = false;
  const tRow = db.prepare('SELECT data FROM tactics WHERE club_id = ?').get(club.id);
  if (human) {
    tactics = { ...F.DEFAULT_TACTICS, ...(tRow ? JSON.parse(tRow.data) : {}) };
    if (lineupIsValid(saved, players, gameDate)) lineup = saved;
    else { lineup = pickEleven(players, saved && F.FORMATIONS[saved.formation] ? saved.formation : '4-3-3', gameDate); auto = true; }
  } else {
    const r = rng((seasonSeed ^ Math.imul(club.id, 2654435761)) >>> 0);
    const formation = FORMATIONS[Math.floor(r() * FORMATIONS.length)];
    lineup = pickEleven(players, formation, gameDate);
    tactics = E.aiTactics(club, seasonSeed, strengthOf(club.id));
  }
  const defs = F.formationSlots(lineup.formation);
  const xi = defs.map((d) => {
    const s = lineup.slots.find((x) => x.slot === d.slot);
    return { slot: d.slot, pos: d.pos, player: byId.get(s.player_id), role: s.role || null, instruction: s.instruction || null };
  });
  const xiIds = new Set(xi.map((x) => x.player.id));
  let bench = (lineup.bench || []).map((id) => byId.get(id)).filter((p) => p && !xiIds.has(p.id) && !p.is_youth && S.isAvailable(p, gameDate));
  if (bench.length < 5) { // top up so substitutions and injuries can be covered
    const extra = players.filter((p) => !p.is_youth && !xiIds.has(p.id) && !bench.includes(p) && S.isAvailable(p, gameDate)).sort((a, b) => b.overall - a.overall);
    for (const p of extra) { if (bench.length >= 7) break; if (human && saved && !auto) continue; bench.push(p); }
    if (!bench.some((p) => p.position === 'GK')) { const gk = extra.find((p) => p.position === 'GK'); if (gk && !bench.includes(gk)) bench.push(gk); }
  }
  const inXi = (id) => xiIds.has(id);
  return {
    auto,
    input: {
      id: club.id, name: club.name, formation: lineup.formation, tactics, xi, bench,
      captain_id: inXi(lineup.captain_id) ? lineup.captain_id : xi[1].player.id,
      penalty_taker_id: inXi(lineup.penalty_taker_id) ? lineup.penalty_taker_id : xi[xi.length - 1].player.id,
      freekick_taker_id: inXi(lineup.freekick_taker_id) ? lineup.freekick_taker_id : xi[xi.length - 1].player.id,
      corner_taker_id: inXi(lineup.corner_taker_id) ? lineup.corner_taker_id : xi[xi.length - 2].player.id,
    },
  };
}

const canManage = (user, world) => !!user && (user.role === 'admin' || world.created_by === user.id);

/** Play exactly the next round. `expectedRound` makes double-clicks and stale tabs harmless. */
function playRound(db, user, worldId, expectedRound) {
  return tx(db, () => {
    const world = db.prepare('SELECT * FROM worlds WHERE id = ?').get(worldId);
    if (!world) throw notFound('World not found');
    if (!canManage(user, world)) throw forbidden('Only the world creator or an administrator can advance the world');
    const total = FX.totalRounds(db, worldId, world.season);
    const next = world.rounds_played + 1;
    if (world.rounds_played >= total) throw conflict('The season is complete. Season rollover arrives with the world clock in Phase 5.', 'season_complete');
    if (expectedRound !== undefined && Number(expectedRound) !== next) throw conflict(`Round ${next} is the next round to play; reload to see the latest state`, 'round_mismatch');

    // weekly recovery before selection
    db.prepare('UPDATE players SET fitness = MIN(100, fitness + ?) WHERE world_id = ? AND club_id IS NOT NULL').run(RECOVERY, worldId);

    const fixtures = db.prepare("SELECT * FROM fixtures WHERE world_id = ? AND season = ? AND round = ? AND status = 'scheduled' ORDER BY id").all(worldId, world.season, next);
    if (!fixtures.length) throw conflict('No fixtures to play for this round', 'no_fixtures');
    const date = fixtures[0].game_date;
    const clubs = new Map(db.prepare('SELECT * FROM clubs WHERE world_id = ?').all(worldId).map((c) => [c.id, c]));

    // relative strength (for computer managers' tactical style)
    const rating = new Map();
    for (const c of clubs.values()) {
      const top = db.prepare('SELECT overall FROM players WHERE club_id = ? AND is_youth = 0 ORDER BY overall DESC LIMIT 14').all(c.id);
      rating.set(c.id, top.reduce((s, p) => s + p.overall, 0) / Math.max(1, top.length));
    }
    const mean = [...rating.values()].reduce((a, b) => a + b, 0) / rating.size;
    const strengthOf = (id) => (rating.get(id) - mean) / mean;

    const updP = {
      fit: db.prepare('UPDATE players SET fitness = ?, morale = ? WHERE id = ?'),
      inj: db.prepare('UPDATE players SET injured_until = ? WHERE id = ?'),
    };
    const results = [], newReds = [], notes = [];
    const insMatch = db.prepare(`INSERT INTO matches (world_id, fixture_id, seed, home_club_id, away_club_id, home_goals, away_goals, events, stats, players, shots, lineups, motm_player_id, auto_lineup)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    const insPms = db.prepare('INSERT INTO player_match_stats (match_id, world_id, season, player_id, club_id, name, started, minutes, goals, assists, shots, sot, yc, rc, rating) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');

    for (const f of fixtures) {
      const hc = clubs.get(f.home_club_id), ac = clubs.get(f.away_club_id);
      const H = buildTeam(db, hc, world, date, strengthOf, world.seed ^ world.season);
      const A = buildTeam(db, ac, world, date, strengthOf, world.seed ^ world.season);
      const seed = ((world.seed ^ Math.imul(f.id, 2654435761) ^ Math.imul(next, 40503)) >>> 0) || 1;
      const res = E.simulateMatch(H.input, A.input, seed);
      const autoClubs = [H.auto ? hc.id : null, A.auto ? ac.id : null].filter((x) => x);
      const info = insMatch.run(worldId, f.id, seed, hc.id, ac.id, res.home_goals, res.away_goals, JSON.stringify(res.events), JSON.stringify(res.stats), JSON.stringify(res.players), JSON.stringify(res.shots), JSON.stringify(res.lineups), res.motm_player_id, JSON.stringify(autoClubs));
      const matchId = Number(info.lastInsertRowid);
      db.prepare("UPDATE fixtures SET status = 'played', home_goals = ?, away_goals = ?, match_id = ? WHERE id = ?").run(res.home_goals, res.away_goals, matchId, f.id);
      const clubOf = { home: hc, away: ac };
      const pl = new Map();
      for (const p of res.players) {
        insPms.run(matchId, worldId, world.season, p.player_id, clubOf[p.team].id, p.name, p.started ? 1 : 0, p.minutes, p.goals, p.assists, p.shots, p.sot, p.yc, p.rc, p.rating);
        pl.set(p.player_id, p);
      }
      // condition: fitness, morale, injuries, suspensions
      const dbPlayers = new Map([...loadPlayers(db, hc.id), ...loadPlayers(db, ac.id)].map((p) => [p.id, p]));
      for (const p of res.players) {
        const dbp = dbPlayers.get(p.player_id); if (!dbp) continue;
        const team = p.team, won = team === 'home' ? res.home_goals > res.away_goals : res.away_goals > res.home_goals, lost = team === 'home' ? res.home_goals < res.away_goals : res.away_goals < res.home_goals;
        let morale = dbp.morale + (won ? 4 : lost ? -4 : 0) + (p.rating >= 7.5 ? 2 : p.rating < 5.5 ? -2 : 0);
        morale = Math.max(20, Math.min(100, morale));
        updP.fit.run(Math.max(0, Math.min(100, p.energy)), morale, p.player_id);
        if (p.injury_days > 0) updP.inj.run(FX.addDays(date, p.injury_days), p.player_id);
        if (p.rc > 0) newReds.push(p.player_id);
      }
      results.push({ fixture_id: f.id, match_id: matchId, home: hc.name, away: ac.name, home_club_id: hc.id, away_club_id: ac.id, home_goals: res.home_goals, away_goals: res.away_goals });
      for (const [club, gf, ga] of [[hc, res.home_goals, res.away_goals], [ac, res.away_goals, res.home_goals]]) {
        if (!club.manager_user_id) continue;
        const outcome = gf > ga ? 'won' : gf === ga ? 'drew' : 'lost';
        const auto = autoClubs.includes(club.id) ? ' No valid saved lineup was available (none set, or injuries/suspensions), so the assistant manager picked the team.' : '';
        notes.push({ user_id: club.manager_user_id, kind: 'match', title: `Full-time: ${hc.name} ${res.home_goals}-${res.away_goals} ${ac.name}`, body: `You ${outcome} round ${next}.${auto}`, match_id: matchId });
      }
    }
    // suspensions: serve one match for those already banned, then apply new bans
    db.prepare('UPDATE players SET suspended_matches = suspended_matches - 1 WHERE world_id = ? AND suspended_matches > 0').run(worldId);
    for (const id of newReds) db.prepare('UPDATE players SET suspended_matches = 2 WHERE id = ?').run(id);
    const following = db.prepare('SELECT game_date FROM fixtures WHERE world_id = ? AND season = ? AND round = ? LIMIT 1').get(worldId, world.season, next + 1);
    db.prepare('UPDATE worlds SET rounds_played = ?, game_date = ? WHERE id = ?').run(next, following ? following.game_date : FX.addDays(date, 7), worldId);
    for (const n of notes) db.prepare('INSERT INTO notifications (user_id, world_id, kind, title, body) VALUES (?,?,?,?,?)').run(n.user_id, worldId, n.kind, n.title, n.body);
    return { round: next, total_rounds: total, results, notifications: notes };
  });
}

function getMatch(db, user, matchId) {
  const m = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId);
  if (!m) throw notFound('Match not found');
  const f = db.prepare('SELECT round, season, game_date FROM fixtures WHERE id = ?').get(m.fixture_id);
  const club = (id) => db.prepare('SELECT id, name, short_name, color1, color2, stadium_name FROM clubs WHERE id = ?').get(id);
  const players = JSON.parse(m.players);
  return {
    id: m.id, world_id: m.world_id, round: f.round, season: f.season, date: f.game_date,
    home: club(m.home_club_id), away: club(m.away_club_id), home_goals: m.home_goals, away_goals: m.away_goals,
    events: JSON.parse(m.events), stats: JSON.parse(m.stats), players, shots: JSON.parse(m.shots), lineups: JSON.parse(m.lineups),
    motm: players.find((p) => p.player_id === m.motm_player_id) || null,
    my_club_ids: db.prepare('SELECT id FROM clubs WHERE world_id = ? AND manager_user_id = ?').all(m.world_id, user.id).map((c) => c.id),
  };
}

function worldCompetition(db, user, worldId) {
  const world = db.prepare('SELECT * FROM worlds WHERE id = ?').get(worldId);
  if (!world) throw notFound('World not found');
  const total = FX.totalRounds(db, worldId, world.season);
  const lastRound = world.rounds_played;
  return {
    world: { id: world.id, code: world.code, name: world.name, season: world.season, game_date: world.game_date, rounds_played: world.rounds_played, total_rounds: total },
    table: FX.standings(db, worldId, world.season),
    last_round: lastRound ? FX.roundFixtures(db, worldId, world.season, lastRound) : [],
    next_round: lastRound < total ? FX.roundFixtures(db, worldId, world.season, lastRound + 1) : [],
    can_manage: canManage(user, world),
  };
}

module.exports = { playRound, getMatch, worldCompetition, canManage };
