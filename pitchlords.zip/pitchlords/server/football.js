'use strict';
// Pure football domain model: attributes, position ratings, formations, roles, tactic enums.
// No database access here, so the match engine (Phase 3) can reuse it directly.

const ATTR_GROUPS = {
  technical: ['passing', 'shooting', 'finishing', 'dribbling', 'ball_control', 'crossing', 'tackling', 'marking', 'heading', 'long_shots', 'set_pieces'],
  physical: ['pace', 'acceleration', 'strength', 'stamina', 'agility', 'jumping'],
  mental: ['positioning', 'vision', 'decisions', 'anticipation', 'composure', 'concentration', 'work_rate', 'leadership'],
  goalkeeping: ['gk_reflexes', 'gk_handling', 'gk_positioning', 'gk_diving', 'gk_aerial', 'gk_distribution'],
};
const ALL_ATTRS = Object.values(ATTR_GROUPS).flat();

const POSITIONS = ['GK', 'CB', 'LB', 'RB', 'DM', 'CM', 'AM', 'LM', 'RM', 'LW', 'RW', 'ST'];
const POS_GROUP = { GK: 'GK', CB: 'DEF', LB: 'DEF', RB: 'DEF', DM: 'MID', CM: 'MID', AM: 'MID', LM: 'MID', RM: 'MID', LW: 'FWD', RW: 'FWD', ST: 'FWD' };

// Attribute weights that define "overall" at each position.
const W = {
  GK: { gk_reflexes: 3, gk_handling: 2.5, gk_positioning: 2.5, gk_diving: 2, gk_aerial: 1.5, gk_distribution: 1, composure: 1, concentration: 1 },
  CB: { tackling: 3, marking: 3, heading: 2.5, strength: 2, positioning: 2, anticipation: 1.5, jumping: 1.5, pace: 1, concentration: 1 },
  FB: { tackling: 2, marking: 1.5, pace: 2.5, stamina: 2, crossing: 1.5, positioning: 1.5, work_rate: 1.5, acceleration: 1.5, passing: 1 },
  DM: { tackling: 3, positioning: 2, passing: 2, anticipation: 2, work_rate: 2, stamina: 1.5, strength: 1.5, decisions: 1.5, marking: 1 },
  CM: { passing: 3, vision: 2, ball_control: 2, decisions: 2, stamina: 2, work_rate: 1.5, tackling: 1, positioning: 1 },
  AM: { passing: 2.5, vision: 3, dribbling: 2.5, ball_control: 2.5, long_shots: 1, decisions: 2, finishing: 1, composure: 1.5 },
  WIDE: { pace: 2.5, acceleration: 2.5, dribbling: 3, crossing: 2.5, ball_control: 2, agility: 1.5, finishing: 1, passing: 1 },
  ST: { finishing: 3.5, shooting: 2.5, positioning: 2, composure: 2, heading: 1.5, pace: 1.5, strength: 1.5, ball_control: 1.5, anticipation: 1 },
};
const WEIGHT_KEY = { GK: 'GK', CB: 'CB', LB: 'FB', RB: 'FB', DM: 'DM', CM: 'CM', AM: 'AM', LM: 'WIDE', RM: 'WIDE', LW: 'WIDE', RW: 'WIDE', ST: 'ST' };
const weightsFor = (pos) => W[WEIGHT_KEY[pos]];

function computeOverall(attrs, pos) {
  const w = weightsFor(pos);
  let s = 0, t = 0;
  for (const k in w) { s += (attrs[k] ?? 0) * w[k]; t += w[k]; }
  return Math.round(s / t);
}

// How comfortable a player is in a slot, relative to his natural position.
const NEAR = {
  LB: { RB: .85, CB: .8, LM: .85, DM: .75 }, RB: { LB: .85, CB: .8, RM: .85, DM: .75 },
  CB: { DM: .85, LB: .75, RB: .75 }, DM: { CM: .92, CB: .85 }, CM: { DM: .92, AM: .92, LM: .8, RM: .8 },
  AM: { CM: .92, LW: .85, RW: .85, ST: .85, LM: .85, RM: .85 },
  LM: { LW: .95, AM: .88, CM: .82, LB: .8 }, RM: { RW: .95, AM: .88, CM: .82, RB: .8 },
  LW: { LM: .95, RW: .88, ST: .82, AM: .85 }, RW: { RM: .95, LW: .88, ST: .82, AM: .85 }, ST: { AM: .88, LW: .8, RW: .8 },
};
function posFit(natural, slot) {
  if (natural === slot) return 1;
  if (natural === 'GK' || slot === 'GK') return 0.2;
  const n = NEAR[natural] && NEAR[natural][slot];
  if (n) return n;
  return POS_GROUP[natural] === POS_GROUP[slot] ? 0.7 : 0.55;
}
const ratingAt = (player, slotPos) => Math.round(computeOverall(player.attrs, slotPos) * posFit(player.position, slotPos));

// Formations: slot = [position, x (0-100 left→right), y (0 own goal → 100 opposition goal)]
const GK = ['GK', 50, 6];
const FORMATIONS = {
  '4-3-3': [GK, ['LB', 12, 24], ['CB', 37, 22], ['CB', 63, 22], ['RB', 88, 24], ['CM', 30, 48], ['DM', 50, 38], ['CM', 70, 48], ['LW', 15, 80], ['ST', 50, 86], ['RW', 85, 80]],
  '4-2-3-1': [GK, ['LB', 12, 24], ['CB', 37, 22], ['CB', 63, 22], ['RB', 88, 24], ['DM', 38, 40], ['DM', 62, 40], ['LW', 15, 68], ['AM', 50, 68], ['RW', 85, 68], ['ST', 50, 86]],
  '4-4-2': [GK, ['LB', 12, 24], ['CB', 37, 22], ['CB', 63, 22], ['RB', 88, 24], ['LM', 12, 55], ['CM', 38, 50], ['CM', 62, 50], ['RM', 88, 55], ['ST', 38, 84], ['ST', 62, 84]],
  '3-5-2': [GK, ['CB', 25, 22], ['CB', 50, 20], ['CB', 75, 22], ['LM', 8, 52], ['CM', 32, 48], ['DM', 50, 38], ['CM', 68, 48], ['RM', 92, 52], ['ST', 38, 84], ['ST', 62, 84]],
  '3-4-3': [GK, ['CB', 25, 22], ['CB', 50, 20], ['CB', 75, 22], ['LM', 10, 50], ['CM', 38, 46], ['CM', 62, 46], ['RM', 90, 50], ['LW', 17, 80], ['ST', 50, 86], ['RW', 83, 80]],
  '4-1-4-1': [GK, ['LB', 12, 24], ['CB', 37, 22], ['CB', 63, 22], ['RB', 88, 24], ['DM', 50, 36], ['LM', 12, 58], ['CM', 38, 54], ['CM', 62, 54], ['RM', 88, 58], ['ST', 50, 86]],
  '5-3-2': [GK, ['LB', 8, 34], ['CB', 28, 22], ['CB', 50, 20], ['CB', 72, 22], ['RB', 92, 34], ['CM', 30, 50], ['DM', 50, 42], ['CM', 70, 50], ['ST', 38, 84], ['ST', 62, 84]],
  '4-3-1-2': [GK, ['LB', 12, 24], ['CB', 37, 22], ['CB', 63, 22], ['RB', 88, 24], ['CM', 28, 46], ['DM', 50, 40], ['CM', 72, 46], ['AM', 50, 66], ['ST', 38, 85], ['ST', 62, 85]],
  '4-5-1': [GK, ['LB', 12, 24], ['CB', 37, 22], ['CB', 63, 22], ['RB', 88, 24], ['LM', 10, 56], ['CM', 32, 50], ['DM', 50, 42], ['CM', 68, 50], ['RM', 90, 56], ['ST', 50, 86]],
  '5-4-1': [GK, ['LB', 8, 34], ['CB', 28, 22], ['CB', 50, 20], ['CB', 72, 22], ['RB', 92, 34], ['LM', 18, 54], ['CM', 40, 48], ['CM', 60, 48], ['RM', 82, 54], ['ST', 50, 86]],
};
const formationSlots = (f) => FORMATIONS[f].map(([pos, x, y], i) => ({ slot: i, pos, x, y }));

const ROLES = {
  GK: ['Standard keeper', 'Sweeper keeper'],
  CB: ['Standard defender', 'Ball-playing defender', 'Stopper'],
  FB: ['Fullback', 'Wingback', 'Inverted fullback'],
  DM: ['Anchor', 'Ball-winning midfielder', 'Deep-lying playmaker'],
  CM: ['Box-to-box midfielder', 'Ball-winning midfielder', 'Deep-lying playmaker', 'Advanced playmaker'],
  AM: ['Advanced playmaker', 'Shadow striker', 'Free role'],
  WIDE: ['Traditional winger', 'Inverted winger', 'Wide playmaker'],
  ST: ['Target man', 'Pressing forward', 'Complete forward', 'Poacher'],
};
const rolesFor = (pos) => ROLES[WEIGHT_KEY[pos]];
// Attributes that make a role effective: used for the "role fit" figure.
const ROLE_ATTRS = {
  'Standard keeper': ['gk_reflexes', 'gk_handling', 'gk_positioning'], 'Sweeper keeper': ['gk_distribution', 'gk_reflexes', 'anticipation', 'pace'],
  'Standard defender': ['tackling', 'marking', 'heading', 'positioning'], 'Ball-playing defender': ['passing', 'composure', 'vision', 'marking'], 'Stopper': ['tackling', 'strength', 'heading', 'anticipation'],
  'Fullback': ['tackling', 'positioning', 'stamina', 'marking'], 'Wingback': ['pace', 'crossing', 'stamina', 'work_rate'], 'Inverted fullback': ['passing', 'vision', 'decisions', 'tackling'],
  'Anchor': ['positioning', 'tackling', 'concentration', 'anticipation'], 'Ball-winning midfielder': ['tackling', 'work_rate', 'strength', 'anticipation'],
  'Deep-lying playmaker': ['passing', 'vision', 'composure', 'decisions'], 'Box-to-box midfielder': ['stamina', 'work_rate', 'passing', 'tackling'], 'Advanced playmaker': ['vision', 'passing', 'dribbling', 'decisions'],
  'Shadow striker': ['finishing', 'anticipation', 'dribbling', 'positioning'], 'Free role': ['dribbling', 'vision', 'ball_control', 'decisions'],
  'Traditional winger': ['pace', 'crossing', 'acceleration', 'dribbling'], 'Inverted winger': ['dribbling', 'shooting', 'agility', 'ball_control'], 'Wide playmaker': ['passing', 'vision', 'crossing', 'ball_control'],
  'Target man': ['heading', 'strength', 'jumping', 'finishing'], 'Pressing forward': ['work_rate', 'stamina', 'pace', 'finishing'], 'Complete forward': ['finishing', 'passing', 'dribbling', 'strength'], 'Poacher': ['finishing', 'positioning', 'anticipation', 'composure'],
};
const roleFit = (attrs, role) => {
  const ks = ROLE_ATTRS[role];
  return ks ? Math.round(ks.reduce((s, k) => s + (attrs[k] ?? 0), 0) / ks.length) : 0;
};

const INSTRUCTIONS = ['stay_back', 'get_forward', 'shoot_more', 'cross_more', 'hold_position'];

const TACTIC_ENUMS = {
  mentality: ['very_defensive', 'defensive', 'balanced', 'attacking', 'very_attacking'],
  passing: ['short', 'mixed', 'direct', 'long'],
  pressing: ['low_block', 'mid_block', 'high_press', 'gegenpressing'],
  marking: ['zonal', 'man'],
  approach: ['possession', 'counter', 'wing_play', 'central', 'direct'],
  time_wasting: ['never', 'sometimes', 'often'],
};
const TACTIC_SLIDERS = ['tempo', 'width', 'pressing_intensity', 'defensive_line', 'compactness', 'tackling_intensity']; // 1..5
const TACTIC_FLAGS = ['offside_trap', 'overlapping_fullbacks'];
const DEFAULT_TACTICS = {
  mentality: 'balanced', passing: 'mixed', pressing: 'mid_block', marking: 'zonal', approach: 'possession', time_wasting: 'never',
  tempo: 3, width: 3, pressing_intensity: 3, defensive_line: 3, compactness: 3, tackling_intensity: 3, offside_trap: false, overlapping_fullbacks: false,
};

module.exports = {
  ATTR_GROUPS, ALL_ATTRS, POSITIONS, POS_GROUP, weightsFor, computeOverall, posFit, ratingAt,
  FORMATIONS, formationSlots, ROLES, ROLE_ATTRS, rolesFor, roleFit, INSTRUCTIONS,
  TACTIC_ENUMS, TACTIC_SLIDERS, TACTIC_FLAGS, DEFAULT_TACTICS,
};
