'use strict';
const { bad, forbidden, notFound, conflict } = require('./http');
const { tx } = require('./db');
const { generateClubs } = require('./generate');
const { insertSquad } = require('./players');
const { generateSeason } = require('./fixtures');
const crypto = require('node:crypto');

const MAX_WORLDS_PER_USER = 3;

function listWorlds(db, userId) {
  return db.prepare(
    `SELECT w.id, w.code, w.name, w.status, w.season, w.game_date, w.max_clubs,
            (SELECT COUNT(*) FROM clubs c WHERE c.world_id = w.id) AS club_count,
            (SELECT COUNT(*) FROM clubs c WHERE c.world_id = w.id AND c.manager_user_id IS NOT NULL) AS human_count,
            (SELECT c.id FROM clubs c WHERE c.world_id = w.id AND c.manager_user_id = ?) AS my_club_id
     FROM worlds w ORDER BY w.id`
  ).all(userId);
}

function createWorld(db, user, { name, clubs }) {
  name = String(name || '').trim();
  const n = clubs === undefined ? 20 : Number(clubs);
  if (name.length < 3 || name.length > 40) throw bad('World name must be 3-40 characters');
  if (!Number.isInteger(n) || n < 4 || n > 40 || n % 2) throw bad('Clubs must be an even number from 4 to 40');
  return tx(db, () => {
    if (user.role === 'player') {
      const mine = db.prepare('SELECT COUNT(*) AS n FROM worlds WHERE created_by = ?').get(user.id).n;
      if (mine >= MAX_WORLDS_PER_USER) throw forbidden(`You can create at most ${MAX_WORLDS_PER_USER} worlds`);
    }
    const seed = crypto.randomInt(1, 2 ** 31);
    const next = db.prepare('SELECT COALESCE(MAX(id),0)+1 AS n FROM worlds').get().n;
    const code = `W${String(next).padStart(3, '0')}`;
    const info = db.prepare('INSERT INTO worlds (code, name, seed, max_clubs, created_by) VALUES (?,?,?,?,?)').run(code, name, seed, n, user.id);
    const worldId = Number(info.lastInsertRowid);
    const ins = db.prepare(
      `INSERT INTO clubs (world_id, name, short_name, city, color1, color2, reputation, stadium_name, stadium_capacity, balance, ai_manager_name)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`
    );
    for (const c of generateClubs(seed, n)) {
      ins.run(worldId, c.name, c.short_name, c.city, c.color1, c.color2, c.reputation, c.stadium_name, c.stadium_capacity, c.balance, c.ai_manager_name);
    }
    const world = db.prepare('SELECT id, seed, game_date, season FROM worlds WHERE id = ?').get(worldId);
    for (const club of db.prepare('SELECT id, reputation FROM clubs WHERE world_id = ?').all(worldId)) insertSquad(db, world, club);
    generateSeason(db, world, world.season);
    return worldId;
  });
}

function getWorld(db, worldId, userId) {
  const w = db.prepare('SELECT id, code, name, status, season, game_date, max_clubs, created_at FROM worlds WHERE id = ?').get(worldId);
  if (!w) throw notFound('World not found');
  // Only public fields of other managers are exposed (username, never email).
  const clubs = db.prepare(
    `SELECT c.id, c.name, c.short_name, c.city, c.color1, c.color2, c.reputation, c.stadium_name, c.stadium_capacity,
            c.ai_manager_name, c.manager_user_id, u.username AS manager_username, c.claimed_at
     FROM clubs c LEFT JOIN users u ON u.id = c.manager_user_id
     WHERE c.world_id = ? ORDER BY c.reputation DESC, c.name`
  ).all(worldId);
  const my = clubs.find((c) => c.manager_user_id === userId) || null;
  return { world: w, clubs, my_club_id: my ? my.id : null };
}

/** Claim a club (explicit id, or random free one when clubId is omitted). Race-safe via transaction + unique index. */
function joinWorld(db, user, worldId, clubId) {
  return tx(db, () => {
    const w = db.prepare('SELECT * FROM worlds WHERE id = ?').get(worldId);
    if (!w) throw notFound('World not found');
    if (w.status !== 'open') throw conflict('This world is closed to new managers', 'world_closed');
    const already = db.prepare('SELECT id, name FROM clubs WHERE world_id = ? AND manager_user_id = ?').get(worldId, user.id);
    if (already) throw conflict(`You already manage ${already.name} in this world`, 'already_joined');
    let club;
    if (clubId === undefined || clubId === null || clubId === '') {
      const free = db.prepare('SELECT * FROM clubs WHERE world_id = ? AND manager_user_id IS NULL').all(worldId);
      if (!free.length) throw conflict('No free clubs left in this world', 'world_full');
      club = free[crypto.randomInt(free.length)];
    } else {
      // world_id in the WHERE clause is what stops a club from another world being claimed.
      club = db.prepare('SELECT * FROM clubs WHERE id = ? AND world_id = ?').get(Number(clubId), worldId);
      if (!club) throw notFound('Club not found in this world');
      if (club.manager_user_id) throw conflict('That club already has a manager', 'club_taken');
    }
    const res = db.prepare(
      `UPDATE clubs SET manager_user_id = ?, claimed_at = datetime('now') WHERE id = ? AND world_id = ? AND manager_user_id IS NULL`
    ).run(user.id, club.id, worldId);
    if (res.changes !== 1) throw conflict('That club was just taken', 'club_taken');
    db.prepare('INSERT INTO notifications (user_id, world_id, kind, title, body) VALUES (?,?,?,?,?)')
      .run(user.id, worldId, 'welcome', `Welcome to ${club.name}`, `You are now manager of ${club.name} in ${w.name}. The board expects a strong season.`);
    return { club_id: club.id, club_name: club.name };
  });
}

function leaveWorld(db, user, worldId) {
  return tx(db, () => {
    const club = db.prepare('SELECT id, name FROM clubs WHERE world_id = ? AND manager_user_id = ?').get(worldId, user.id);
    if (!club) throw notFound('You do not manage a club in this world');
    db.prepare('UPDATE clubs SET manager_user_id = NULL, claimed_at = NULL WHERE id = ?').run(club.id);
    return { club_id: club.id, club_name: club.name };
  });
}

function worldMemberIds(db, worldId) {
  return db.prepare('SELECT manager_user_id AS id FROM clubs WHERE world_id = ? AND manager_user_id IS NOT NULL').all(worldId).map((r) => r.id);
}

module.exports = { listWorlds, createWorld, getWorld, joinWorld, leaveWorld, worldMemberIds };
