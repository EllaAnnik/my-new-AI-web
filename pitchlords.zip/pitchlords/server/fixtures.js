'use strict';
// League scheduling and read models (table, schedules, leaders).
const { rng } = require('./generate');

function addDays(iso, n) {
  const d = new Date(iso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/**
 * Double round robin by the circle method. Returns rounds of [homeId, awayId].
 * Properties (asserted in tests): every club plays once per round; every ordered pair meets exactly once;
 * the second half mirrors the first with venues swapped; home/away runs are kept short.
 */
function roundRobin(ids) {
  const n = ids.length;
  if (n < 2 || n % 2) throw new Error('An even number of clubs (at least 2) is required');
  // 1. pairings by the circle method (who plays whom, round by round)
  let arr = [...ids];
  const pairings = [];
  for (let r = 0; r < n - 1; r++) {
    const pairs = [];
    for (let i = 0; i < n / 2; i++) pairs.push([arr[i], arr[n - 1 - i]]);
    pairings.push(pairs);
    arr = [arr[0], arr[n - 1], ...arr.slice(1, n - 1)];
  }
  // 2. venues: greedily give home advantage to whichever club has gone longer without it
  const last = new Map();
  const need = (c) => { const l = last.get(c); return !l ? 0 : l.v === 'A' ? l.n : -l.n; };
  const bump = (c, v) => { const l = last.get(c); last.set(c, l && l.v === v ? { v, n: l.n + 1 } : { v, n: 1 }); };
  const first = pairings.map((pairs) => pairs.map(([x, y]) => {
    const nx = need(x), ny = need(y);
    const xHome = nx !== ny ? nx > ny : (x * 31 + y) % 2 === 0;
    bump(x, xHome ? 'H' : 'A'); bump(y, xHome ? 'A' : 'H');
    return xHome ? [x, y] : [y, x];
  }));
  // 3. second half mirrors the first with venues swapped
  const second = first.map((round) => round.map(([h, a]) => [a, h]));
  return [...first, ...second];
}

function generateSeason(db, world, season) {
  const ids = db.prepare('SELECT id FROM clubs WHERE world_id = ? ORDER BY id').all(world.id).map((c) => c.id);
  const r = rng((world.seed ^ Math.imul(season, 2246822519)) >>> 0);
  for (let i = ids.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [ids[i], ids[j]] = [ids[j], ids[i]]; }
  const ins = db.prepare('INSERT INTO fixtures (world_id, season, round, home_club_id, away_club_id, game_date) VALUES (?,?,?,?,?,?)');
  roundRobin(ids).forEach((round, i) => {
    const date = addDays(world.game_date, 7 * i);
    for (const [h, a] of round) ins.run(world.id, season, i + 1, h, a, date);
  });
  return ids.length;
}

/** Create the schedule for any world that has none (new worlds and worlds from earlier phases). */
function ensureFixtures(db, tx) {
  const worlds = db.prepare('SELECT * FROM worlds w WHERE NOT EXISTS (SELECT 1 FROM fixtures f WHERE f.world_id = w.id AND f.season = w.season)').all();
  for (const w of worlds) tx(db, () => generateSeason(db, w, w.season));
  return worlds.length;
}

const totalRounds = (db, worldId, season) => db.prepare('SELECT COALESCE(MAX(round),0) AS n FROM fixtures WHERE world_id = ? AND season = ?').get(worldId, season).n;

function standings(db, worldId, season) {
  const clubs = db.prepare(
    `SELECT c.id, c.name, c.short_name, c.color1, c.color2, c.manager_user_id, u.username AS manager_username
     FROM clubs c LEFT JOIN users u ON u.id = c.manager_user_id WHERE c.world_id = ?`
  ).all(worldId);
  const t = new Map(clubs.map((c) => [c.id, { club_id: c.id, name: c.name, short_name: c.short_name, color1: c.color1, color2: c.color2, manager_user_id: c.manager_user_id, manager_username: c.manager_username,
    played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, gd: 0, points: 0, form: [] }]));
  const played = db.prepare("SELECT * FROM fixtures WHERE world_id = ? AND season = ? AND status = 'played' ORDER BY round, id").all(worldId, season);
  for (const f of played) {
    for (const [id, gf, ga] of [[f.home_club_id, f.home_goals, f.away_goals], [f.away_club_id, f.away_goals, f.home_goals]]) {
      const e = t.get(id);
      e.played++; e.gf += gf; e.ga += ga;
      if (gf > ga) { e.won++; e.points += 3; e.form.push('W'); } else if (gf === ga) { e.drawn++; e.points += 1; e.form.push('D'); } else { e.lost++; e.form.push('L'); }
    }
  }
  const rows = [...t.values()];
  for (const e of rows) { e.gd = e.gf - e.ga; e.form = e.form.slice(-5); }
  rows.sort((a, b) => b.points - a.points || b.gd - a.gd || b.gf - a.gf || a.name.localeCompare(b.name));
  rows.forEach((e, i) => { e.position = i + 1; });
  return rows;
}

const FIX_SELECT = `SELECT f.id, f.round, f.season, f.game_date, f.status, f.home_goals, f.away_goals, f.match_id,
    f.home_club_id, h.name AS home_name, h.short_name AS home_short, h.color1 AS home_color1, h.color2 AS home_color2,
    f.away_club_id, a.name AS away_name, a.short_name AS away_short, a.color1 AS away_color1, a.color2 AS away_color2
  FROM fixtures f JOIN clubs h ON h.id = f.home_club_id JOIN clubs a ON a.id = f.away_club_id`;

const roundFixtures = (db, worldId, season, round) =>
  db.prepare(`${FIX_SELECT} WHERE f.world_id = ? AND f.season = ? AND f.round = ? ORDER BY f.id`).all(worldId, season, round);

function clubSchedule(db, clubId) {
  const club = db.prepare('SELECT c.id, c.world_id, w.season, w.rounds_played FROM clubs c JOIN worlds w ON w.id = c.world_id WHERE c.id = ?').get(clubId);
  if (!club) return null;
  const fixtures = db.prepare(`${FIX_SELECT} WHERE f.world_id = ? AND f.season = ? AND (f.home_club_id = ? OR f.away_club_id = ?) ORDER BY f.round`).all(club.world_id, club.season, clubId, clubId)
    .map((f) => {
      const home = f.home_club_id === clubId;
      let result = null;
      if (f.status === 'played') result = f.home_goals === f.away_goals ? 'D' : (f.home_goals > f.away_goals) === home ? 'W' : 'L';
      return { ...f, home, result };
    });
  const table = standings(db, club.world_id, club.season);
  return { club_id: clubId, world_id: club.world_id, season: club.season, rounds_played: club.rounds_played, total_rounds: totalRounds(db, club.world_id, club.season), fixtures, position: (table.find((e) => e.club_id === clubId) || {}).position, table_row: table.find((e) => e.club_id === clubId) };
}

function leaders(db, worldId, season) {
  const q = (col, order, having) => db.prepare(
    `SELECT s.player_id, s.name, c.name AS club_name, c.short_name AS club_short, c.id AS club_id,
            SUM(s.goals) AS goals, SUM(s.assists) AS assists, COUNT(*) AS apps, ROUND(AVG(s.rating), 2) AS avg_rating, SUM(s.minutes) AS minutes
     FROM player_match_stats s JOIN clubs c ON c.id = s.club_id
     WHERE s.world_id = ? AND s.season = ? GROUP BY s.player_id, s.club_id ${having}
     ORDER BY ${order} LIMIT 10`).all(worldId, season);
  return {
    scorers: q('goals', 'goals DESC, assists DESC, apps ASC, s.name', 'HAVING SUM(s.goals) > 0'),
    assists: q('assists', 'assists DESC, goals DESC, apps ASC, s.name', 'HAVING SUM(s.assists) > 0'),
    ratings: q('avg_rating', 'avg_rating DESC, apps DESC', 'HAVING COUNT(*) >= 3'),
  };
}

module.exports = { roundRobin, generateSeason, ensureFixtures, standings, roundFixtures, clubSchedule, leaders, totalRounds, addDays };
