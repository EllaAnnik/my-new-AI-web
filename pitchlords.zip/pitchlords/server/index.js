'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { open, tx } = require('./db');
const H = require('./http');
const auth = require('./auth');
const worlds = require('./worlds');
const { Hub } = require('./realtime');
const squad = require('./squad');
const { ensureSquads } = require('./players');
const FX = require('./fixtures');
const matchday = require('./matchday');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json', '.ico': 'image/x-icon' };
const COOKIE = 'pl_session';

function createApp({ dbFile = path.join(__dirname, '..', 'data', 'pitchlords.db'), secureCookies = process.env.COOKIE_SECURE === '1', registerLimitPerHour = 10 } = {}) {
  const db = open(dbFile);
  ensureSquads(db, tx); // backfill squads for worlds created before players existed
  FX.ensureFixtures(db, tx); // ...and schedules for worlds created before fixtures existed
  const hub = new Hub();
  const limiter = new H.RateLimiter();
  const sweeper = setInterval(() => limiter.sweep(), 60_000);
  sweeper.unref();
  const router = new H.Router();
  const publicDir = path.join(__dirname, '..', 'public');

  const audit = (actor, action, target, detail, ip) =>
    db.prepare('INSERT INTO audit_log (actor_id, action, target, detail, ip) VALUES (?,?,?,?,?)').run(actor, action, target, detail || null, ip || null);

  const cookie = (token, maxAge) =>
    `${COOKIE}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secureCookies ? '; Secure' : ''}`;

  const notify = (userId, worldId, kind, title, body) => {
    const info = db.prepare('INSERT INTO notifications (user_id, world_id, kind, title, body) VALUES (?,?,?,?,?)').run(userId, worldId, kind, title, body || '');
    hub.sendTo(userId, 'notification', { id: Number(info.lastInsertRowid), kind, title, body, world_id: worldId });
  };

  // ---- Auth ----
  router.add('POST', '/api/auth/register', (req) => {
    limiter.hit(`reg:${req.ip}`, registerLimitPerHour, 3600_000);
    const u = auth.register(db, req.body, req.ip);
    const s = auth.createSession(db, u.id);
    return { status: 201, body: { user: auth.publicUser(u) }, headers: { 'Set-Cookie': cookie(s.token, s.maxAge) } };
  });
  router.add('POST', '/api/auth/login', (req) => {
    limiter.hit(`login:ip:${req.ip}`, 30, 900_000);
    limiter.hit(`login:id:${String(req.body.identifier || '').toLowerCase()}`, 10, 900_000);
    const u = auth.login(db, req.body);
    const s = auth.createSession(db, u.id);
    return { body: { user: auth.publicUser(u) }, headers: { 'Set-Cookie': cookie(s.token, s.maxAge) } };
  });
  router.add('POST', '/api/auth/logout', (req) => {
    if (req.sessionToken) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(H.sha256(req.sessionToken));
    return { body: { ok: true }, headers: { 'Set-Cookie': cookie('', 0) } };
  });
  router.add('GET', '/api/me', (req) => {
    const u = auth.requireUser(req);
    const clubs = db.prepare(
      `SELECT c.id AS club_id, c.name AS club_name, c.world_id, w.name AS world_name, w.code AS world_code
       FROM clubs c JOIN worlds w ON w.id = c.world_id WHERE c.manager_user_id = ? ORDER BY w.id`
    ).all(u.id);
    const unread = db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read = 0').get(u.id).n;
    return { body: { user: auth.publicUser(u), clubs, unread } };
  });

  // ---- Worlds ----
  router.add('GET', '/api/worlds', (req) => ({ body: { worlds: worlds.listWorlds(db, auth.requireUser(req).id) } }));
  router.add('POST', '/api/worlds', (req) => {
    const u = auth.requireUser(req);
    limiter.hit(`mkworld:${u.id}`, 5, 3600_000);
    const id = worlds.createWorld(db, u, req.body);
    audit(u.id, 'world_created', `world:${id}`, req.body.name, req.ip);
    hub.broadcastAll('worlds_changed', { world_id: id });
    return { status: 201, body: { world_id: id } };
  });
  router.add('GET', '/api/worlds/:id', (req) => ({ body: worlds.getWorld(db, Number(req.params.id), auth.requireUser(req).id) }));
  router.add('POST', '/api/worlds/:id/join', (req) => {
    const u = auth.requireUser(req);
    limiter.hit(`join:${u.id}`, 20, 600_000);
    const worldId = Number(req.params.id);
    const r = worlds.joinWorld(db, u, worldId, req.body.club_id);
    hub.broadcast('world_changed', { world_id: worldId, club_id: r.club_id, manager: u.username }, worlds.worldMemberIds(db, worldId));
    hub.broadcastAll('worlds_changed', { world_id: worldId });
    return { body: r };
  });
  router.add('POST', '/api/worlds/:id/leave', (req) => {
    const u = auth.requireUser(req);
    const worldId = Number(req.params.id);
    const r = worlds.leaveWorld(db, u, worldId);
    hub.broadcastAll('worlds_changed', { world_id: worldId });
    return { body: r };
  });

  // ---- Squad, lineup, tactics ----
  router.add('GET', '/api/clubs/:id/squad', (req) => ({ body: squad.getSquad(db, auth.requireUser(req), Number(req.params.id)) }));
  router.add('GET', '/api/clubs/:id/lineup', (req) => ({ body: squad.getLineup(db, auth.requireUser(req), Number(req.params.id)) }));
  router.add('GET', '/api/clubs/:id/lineup/suggest', (req) => ({ body: squad.suggestLineup(db, auth.requireUser(req), Number(req.params.id), req.query.formation) }));
  router.add('PUT', '/api/clubs/:id/lineup', (req) => ({ body: squad.setLineup(db, auth.requireUser(req), Number(req.params.id), req.body) }));
  router.add('PUT', '/api/clubs/:id/tactics', (req) => ({ body: squad.setTactics(db, auth.requireUser(req), Number(req.params.id), req.body) }));
  router.add('POST', '/api/clubs/:id/players/:pid/transfer-list', (req) =>
    ({ body: squad.setTransferListed(db, auth.requireUser(req), Number(req.params.id), Number(req.params.pid), req.body.listed) }));
  router.add('POST', '/api/clubs/:id/players/:pid/promote', (req) =>
    ({ body: squad.promoteYouth(db, auth.requireUser(req), Number(req.params.id), Number(req.params.pid)) }));

  router.add('GET', '/api/clubs/:id/players/:pid/contract-quote', (req) =>
    ({ body: squad.contractQuote(db, auth.requireUser(req), Number(req.params.id), Number(req.params.pid), req.query.years) }));
  router.add('POST', '/api/clubs/:id/players/:pid/renew', (req) => {
    const u = auth.requireUser(req);
    limiter.hit(`contract:${u.id}`, 60, 60_000);
    return { body: squad.renewContract(db, u, Number(req.params.id), Number(req.params.pid), req.body) };
  });
  router.add('POST', '/api/clubs/:id/players/:pid/release', (req) => {
    const u = auth.requireUser(req);
    limiter.hit(`contract:${u.id}`, 60, 60_000);
    return { body: squad.releasePlayer(db, u, Number(req.params.id), Number(req.params.pid)) };
  });
  router.add('GET', '/api/clubs/:id/ledger', (req) => ({ body: squad.ledger(db, auth.requireUser(req), Number(req.params.id)) }));

  // ---- Competition, fixtures, matches ----
  router.add('GET', '/api/worlds/:id/competition', (req) => ({ body: matchday.worldCompetition(db, auth.requireUser(req), Number(req.params.id)) }));
  router.add('GET', '/api/worlds/:id/rounds/:n', (req) => {
    auth.requireUser(req);
    const w = db.prepare('SELECT id, season FROM worlds WHERE id = ?').get(Number(req.params.id));
    if (!w) throw H.notFound('World not found');
    return { body: { round: Number(req.params.n), fixtures: FX.roundFixtures(db, w.id, w.season, Number(req.params.n)) } };
  });
  router.add('GET', '/api/worlds/:id/leaders', (req) => {
    auth.requireUser(req);
    const w = db.prepare('SELECT id, season FROM worlds WHERE id = ?').get(Number(req.params.id));
    if (!w) throw H.notFound('World not found');
    return { body: FX.leaders(db, w.id, w.season) };
  });
  router.add('GET', '/api/clubs/:id/schedule', (req) => {
    auth.requireUser(req);
    const s = FX.clubSchedule(db, Number(req.params.id));
    if (!s) throw H.notFound('Club not found');
    return { body: s };
  });
  router.add('GET', '/api/matches/:id', (req) => ({ body: matchday.getMatch(db, auth.requireUser(req), Number(req.params.id)) }));
  router.add('POST', '/api/worlds/:id/play-round', (req) => {
    const u = auth.requireUser(req);
    limiter.hit(`play:${u.id}`, 30, 60_000);
    const worldId = Number(req.params.id);
    const count = req.body.count === undefined ? 1 : Number(req.body.count);
    if (!Number.isInteger(count) || count < 1 || count > 60) throw H.bad('count must be a whole number from 1 to 60');
    const played = [];
    let expected = req.body.round;
    for (let i = 0; i < count; i++) {
      let r;
      try { r = matchday.playRound(db, u, worldId, expected); }
      catch (e) { if (i > 0 && e.code === 'season_complete') break; throw e; }
      played.push({ round: r.round, results: r.results });
      for (const n of r.notifications) hub.sendTo(n.user_id, 'notification', { kind: n.kind, title: n.title, body: n.body, world_id: worldId, match_id: n.match_id });
      expected = r.round + 1;
    }
    audit(u.id, 'rounds_played', `world:${worldId}`, `rounds ${played[0].round}-${played[played.length - 1].round}`, req.ip);
    hub.broadcast('competition_changed', { world_id: worldId }, worlds.worldMemberIds(db, worldId));
    return { body: { played_rounds: played.length, last_round: played[played.length - 1].round, rounds: played } };
  });

  // ---- Notifications ----
  router.add('GET', '/api/notifications', (req) => {
    const u = auth.requireUser(req);
    return { body: { notifications: db.prepare('SELECT id, world_id, kind, title, body, read, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50').all(u.id) } };
  });
  router.add('POST', '/api/notifications/read', (req) => {
    const u = auth.requireUser(req);
    db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').run(u.id);
    return { body: { ok: true } };
  });

  // ---- Admin (Phase 1 subset; every action is audited) ----
  router.add('GET', '/api/admin/users', (req) => {
    auth.requireRole(req, 'admin', 'moderator');
    return { body: { users: db.prepare('SELECT id, username, email, role, status, suspended_reason, created_at FROM users ORDER BY id').all() } };
  });
  router.add('POST', '/api/admin/users/:id/suspend', (req) => {
    const actor = auth.requireRole(req, 'admin', 'moderator');
    const id = Number(req.params.id);
    const target = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (!target) throw H.notFound('User not found');
    if (target.role === 'admin') throw H.forbidden('Admins cannot be suspended');
    if (target.id === actor.id) throw H.bad('You cannot suspend yourself');
    const reason = String(req.body.reason || '').slice(0, 200);
    if (!reason) throw H.bad('A reason is required');
    tx(db, () => {
      db.prepare("UPDATE users SET status = 'suspended', suspended_reason = ? WHERE id = ?").run(reason, id);
      db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
      audit(actor.id, 'user_suspended', `user:${id}`, reason, req.ip);
    });
    return { body: { ok: true } };
  });
  router.add('POST', '/api/admin/users/:id/restore', (req) => {
    const actor = auth.requireRole(req, 'admin');
    const id = Number(req.params.id);
    const r = db.prepare("UPDATE users SET status = 'active', suspended_reason = NULL WHERE id = ?").run(id);
    if (!r.changes) throw H.notFound('User not found');
    audit(actor.id, 'user_restored', `user:${id}`, null, req.ip);
    return { body: { ok: true } };
  });
  router.add('GET', '/api/admin/audit', (req) => {
    auth.requireRole(req, 'admin');
    return { body: { entries: db.prepare('SELECT id, actor_id, action, target, detail, ip, created_at FROM audit_log ORDER BY id DESC LIMIT 200').all() } };
  });

  // ---- Request handling ----
  function serveStatic(req, res, pathname) {
    let rel = pathname === '/' ? '/index.html' : pathname;
    const file = path.normalize(path.join(publicDir, rel));
    if (!file.startsWith(publicDir + path.sep) && file !== publicDir) { res.writeHead(403); return res.end(); }
    fs.readFile(file, (err, data) => {
      if (err) {
        // SPA fallback for non-file routes
        if (!path.extname(rel)) return fs.readFile(path.join(publicDir, 'index.html'), (e2, d2) => {
          if (e2) { res.writeHead(404); return res.end('Not found'); }
          res.writeHead(200, { 'Content-Type': MIME['.html'] }); res.end(d2);
        });
        res.writeHead(404); return res.end('Not found');
      }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
      res.end(data);
    });
  }

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    req.ip = req.socket.remoteAddress;
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'");
    if (!url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
      return serveStatic(req, res, url.pathname);
    }
    try {
      limiter.hit(`api:${req.ip}`, 600, 60_000);
      // CSRF defence: reject cross-origin state-changing requests.
      if (req.method !== 'GET') {
        const origin = req.headers.origin;
        if (origin && new URL(origin).host !== req.headers.host) throw H.forbidden('Cross-origin request blocked');
      }
      req.sessionToken = H.parseCookies(req.headers.cookie)[COOKIE];
      req.user = auth.userFromToken(db, req.sessionToken);

      if (req.method === 'GET' && url.pathname === '/api/events') {
        const u = auth.requireUser(req);
        return hub.subscribe(u.id, res);
      }
      const m = router.match(req.method, url.pathname);
      if (!m) throw H.notFound('Unknown endpoint');
      req.params = m.params;
      req.query = Object.fromEntries(url.searchParams);
      req.body = await H.readJson(req);
      if (req.body === null || typeof req.body !== 'object' || Array.isArray(req.body)) throw H.bad('JSON object expected');
      const out = await m.route.handler(req);
      H.send(res, out.status || 200, out.body, out.headers);
    } catch (e) {
      if (e instanceof H.HttpError) return H.send(res, e.status, { error: e.message, code: e.code });
      if (e && /UNIQUE constraint failed/.test(e.message)) return H.send(res, 409, { error: 'That change conflicts with existing data', code: 'conflict' });
      console.error('[error]', req.method, req.url, e);
      H.send(res, 500, { error: 'Internal server error' });
    }
  });

  return {
    db, server, hub, notify,
    listen: (port = 3000, host = '0.0.0.0') => new Promise((r) => server.listen(port, host, () => r(server.address().port))),
    close: () => new Promise((r) => { hub.close(); clearInterval(sweeper); server.closeAllConnections?.(); server.close(() => { db.close(); r(); }); }),
  };
}

module.exports = { createApp };

if (require.main === module) {
  const app = createApp();
  const port = Number(process.env.PORT || 3000);
  app.listen(port).then((p) => console.log(`PITCHLORDS listening on http://localhost:${p}`));
  for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => app.close().then(() => process.exit(0)));
}
