'use strict';
// Pure, seeded match engine. No database, no clock: same inputs + same seed => identical match.
//
// Model: the match is played minute by minute. Each minute:
//   1. fatigue drains (stamina, tempo, pressing, work rate)
//   2. AI-style substitutions are considered
//   3. possession is decided from midfield strength (+ tactics)
//   4. the side in possession may build an attacking sequence; the defence may stop it
//      (tackle / interception / offside); otherwise a chance is created, shot, saved or scored
//   5. fouls, cards and injuries happen independently
// Team strength comes from the XI's position-adjusted ratings, modified by energy, morale, chemistry,
// roles and instructions, then tactics are compared head to head (see tacticMods).
const F = require('./football');
const { rng } = require('./generate');

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const MENT = { very_defensive: -2, defensive: -1, balanced: 0, attacking: 1, very_attacking: 2 };
const PRESS = { low_block: 0, mid_block: 1, high_press: 2, gegenpressing: 3 };
const ZONE_W = {
  GK: {}, CB: { d: 1 }, LB: { d: 0.7, m: 0.15, a: 0.15 }, RB: { d: 0.7, m: 0.15, a: 0.15 },
  DM: { d: 0.5, m: 0.5 }, CM: { m: 1 }, AM: { m: 0.5, a: 0.5 }, LM: { m: 0.5, a: 0.5 }, RM: { m: 0.5, a: 0.5 },
  LW: { a: 1 }, RW: { a: 1 }, ST: { a: 1 },
};
const MAX_SUBS = 5;

// ---------- commentary ----------
const TXT = {
  kickoff: ['We are underway.', 'The referee blows his whistle and the match begins.'],
  halftime: ['Half-time. The players head down the tunnel.', 'The whistle goes for half-time.'],
  secondhalf: ['The second half is under way.', 'Back out for the second half.'],
  fulltime: ['Full-time.', 'That is the final whistle.'],
  build_central: ['{t} work the ball through the middle and {c} slips in {p}.', '{c} threads a pass between the lines for {p}.', 'A neat one-two in midfield opens the door for {p}.', 'Patient build-up from {t}, then {c} finds {p} in space.'],
  build_left: ['{c} drives down the left and swings in a dangerous cross towards {p}.', 'A quick move down the left flank. {c} gets to the byline and picks out {p}.'],
  build_right: ['{c} breaks down the right and delivers a dangerous cross for {p}.', 'The right winger {c} beats his man and finds {p} inside the box.'],
  build_counter: ['{t} win it back and break at speed. {c} releases {p}.', 'A rapid counter-attack from {t}! {c} slides it through to {p}.'],
  build_trap: ['{p} beats the offside trap and is clean through!'],
  goal: ['GOAL! {p} gets ahead of his marker and finishes brilliantly.', 'GOAL! {p} calmly slots it past the goalkeeper.', 'GOAL! {p} hits it first time and it flies into the net.', 'GOAL! A superb finish from {p}.', 'GOAL! {p} heads the ball into the bottom corner.'],
  goal_header: ['GOAL! {p} rises highest and powers a header into the net.', 'GOAL! {p} directs a bullet header past the keeper.'],
  goal_pen: ['GOAL! {p} sends the goalkeeper the wrong way from the spot.', 'GOAL! {p} steps up and buries the penalty.'],
  goal_fk: ['GOAL! {p} curls the free kick over the wall and into the corner.', 'GOAL! A stunning free kick from {p}.'],
  save: ['Great save! {k} dives to keep out the effort from {p}.', '{p} shoots on target but {k} pushes it away.', '{k} gets down well to stop {p}\'s shot.'],
  miss: ['{p} drags the shot wide of the post.', '{p} fires over the bar.', '{p} blazes it off target.', '{p} cannot keep his effort down.'],
  block: ['{p}\'s shot is blocked by {d}.', '{d} throws himself in front of the shot from {p}.'],
  corner: ['Corner to {t}.', '{t} win a corner.'],
  pen_save: ['{k} saves the penalty from {p}!', 'What a save! {k} keeps out {p}\'s penalty.'],
  pen_miss: ['{p} puts the penalty wide!', '{p} blazes the penalty over the bar.'],
  penalty: ['{t} are awarded a penalty after a foul by {d}.'],
  freekick: ['Free kick in a dangerous position for {t}.'],
  foul: ['{p} commits a foul.', 'The referee blows for a foul by {p}.'],
  yellow: ['Yellow card for {p}.', '{p} goes into the book.'],
  second_yellow: ['A second yellow for {p} and he is sent off!'],
  red: ['RED CARD! {p} is sent off for a reckless challenge.'],
  injury: ['{p} is down and needs treatment. He cannot continue.', '{p} pulls up injured.'],
  injury_played_on: ['{p} is hurt but there are no substitutes left; he limps on.'],
  sub: ['Substitution for {t}: {on} replaces {off}.'],
  offside: ['{p} is flagged offside.', 'The flag goes up against {p}.'],
  tackle: ['{p} makes a crucial tackle to stop the attack.', '{p} wins the ball back with a strong challenge.'],
  inter: ['{p} reads the pass and intercepts.', 'Good anticipation from {p} to cut out the through ball.'],
};
const pickTxt = (r, key) => TXT[key][Math.floor(r() * TXT[key].length)];
const fill = (s, o) => s.replace(/\{(\w+)\}/g, (_, k) => (o[k] != null ? o[k] : ''));

// ---------- helpers ----------
function eff(pl, T) {
  let m = (0.78 + (0.22 * clamp(pl.energy, 0, 100)) / 100) * (0.96 + (0.08 * pl.p.morale) / 100) * T.chem;
  if (pl.role) m *= 1 + (F.roleFit(pl.p.attrs, pl.role) - 65) / 400;
  return pl.rating0 * m;
}
function zw(pl) {
  const w = { ...(ZONE_W[pl.pos] || {}) };
  if (pl.instr === 'get_forward') { const s = 0.25 * (w.d || 0); w.d = (w.d || 0) - s; w.a = (w.a || 0) + s; }
  else if (pl.instr === 'stay_back') { const s = 0.25 * (w.a || 0); w.a = (w.a || 0) - s; w.d = (w.d || 0) + s; }
  return w;
}
function zones(T) {
  const z = { d: 0, m: 0, a: 0 };
  for (const pl of T.onp) {
    if (pl.pos === 'GK') continue;
    const w = zw(pl), e = eff(pl, T);
    z.d += (w.d || 0) * e; z.m += (w.m || 0) * e; z.a += (w.a || 0) * e;
  }
  return { d: z.d / T.base.d, m: z.m / T.base.m, a: z.a / T.base.a };
}
const avgAttr = (pls, k) => (pls.length ? pls.reduce((s, x) => s + x.p.attrs[k], 0) / pls.length : 60);
const fwdPace = (T) => avgAttr(T.onp.filter((x) => ['LW', 'RW', 'ST', 'AM'].includes(x.pos)), 'pace');

function mkTeam(side, inp) {
  const tac = { ...F.DEFAULT_TACTICS, ...inp.tactics };
  const T = { side, id: inp.id, name: inp.name, tac, formation: inp.formation, onp: [], bench: [], subsUsed: 0, goals: 0, everyone: [], emergencyGK: false,
    setPieces: { pen: inp.penalty_taker_id, fk: inp.freekick_taker_id, corner: inp.corner_taker_id, captain: inp.captain_id },
    st: { shots: 0, sot: 0, blocked: 0, corners: 0, fouls: 0, yc: 0, rc: 0, offsides: 0, tackles: 0, inter: 0, saves: 0, xg: 0, possTicks: 0, channels: { left: 0, central: 0, right: 0 } } };
  const mk = (p, pos, role, instr, started) => ({ p, pos, role: role || null, instr: instr || null, rating0: F.ratingAt(p, pos), energy: p.fitness, started, minOn: started ? 0 : null, minOff: null, yc: 0, out: false,
    s: { goals: 0, assists: 0, shots: 0, sot: 0, saves: 0, tackles: 0, inter: 0, fouls: 0, yc: 0, rc: 0, conceded: 0, bonus: 0 } });
  for (const s of inp.xi) { const pl = mk(s.player, s.pos, s.role, s.instruction, true); T.onp.push(pl); T.everyone.push(pl); }
  T.benchPlayers = inp.bench.slice();
  T.base = { d: 0, m: 0, a: 0 };
  for (const pl of T.onp) { const w = zw(pl); T.base.d += w.d || 0; T.base.m += w.m || 0; T.base.a += w.a || 0; }
  // chemistry: nationality cohesion and how naturally the XI fits its slots
  const nat = {};
  for (const pl of T.onp) nat[pl.p.nationality] = (nat[pl.p.nationality] || 0) + 1;
  const pairs = Object.values(nat).reduce((s, c) => s + (c * (c - 1)) / 2, 0);
  const fit = T.onp.reduce((s, pl) => s + F.posFit(pl.p.position, pl.pos), 0) / T.onp.length;
  T.cohesion = pairs / 55;
  T.chem = clamp(0.98 + 0.05 * T.cohesion + 0.03 * fit, 0.97, 1.04);
  T.chemPct = Math.round(((T.chem - 0.97) / 0.07) * 100);
  return T;
}

// Head-to-head tactical modifiers for team A when attacking/defending against D.
function tacticMods(A, D, ctx) {
  const a = A.tac, d = D.tac;
  let m = MENT[a.mentality];
  if (ctx.t >= 75 && ctx.diff < 0) m += 1;   // late urgency when trailing
  if (ctx.t >= 80 && ctx.diff > 0) m -= 1;   // protecting a lead
  m = clamp(m, -2, 2);
  const pressA = PRESS[a.pressing] + (a.pressing_intensity - 3) * 0.5;
  const pressD = PRESS[d.pressing] + (d.pressing_intensity - 3) * 0.5;
  const dHighPress = PRESS[d.pressing] >= 2;
  let mid = 1 + 0.012 * m + 0.015 * pressA - 0.008 * pressD * (a.passing === 'short' ? 1 : 0.3) + 0.01 * (a.compactness - 3);
  mid += { possession: 0.03, counter: -0.02, wing_play: 0, central: 0.01, direct: -0.015 }[a.approach];
  mid += { short: 0.015, mixed: 0, direct: -0.01, long: -0.02 }[a.passing];
  let att = 1 + 0.05 * m + (a.overlapping_fullbacks ? 0.01 : 0);
  let def = 1 - 0.04 * m + 0.01 * (a.compactness - 3) + 0.01 * (a.tackling_intensity - 3) + (a.marking === 'man' ? 0.01 : 0) - (a.overlapping_fullbacks ? 0.015 : 0);
  let q = 1;
  const counterOpen = MENT[d.mentality] >= 1 || d.defensive_line >= 4;
  switch (a.approach) {
    case 'possession': q += d.pressing === 'low_block' ? -0.05 : 0.01; break;
    case 'counter': q += counterOpen ? 0.07 : -0.03; break;
    case 'direct': q += dHighPress ? 0.05 : -0.02; break;
    default: break;
  }
  if (a.passing === 'direct' || a.passing === 'long') q += dHighPress ? 0.03 : a.passing === 'long' && d.pressing === 'low_block' ? -0.04 : 0;
  if (a.passing === 'short' && dHighPress) q -= 0.03;
  q += (d.defensive_line - 3) * 0.03 * (ctx.fwdPaceA / 70); // pace in behind a high line
  return { mid, att, def, q, tempo: 1 + 0.06 * (a.tempo - 3) };
}

// ---------- the match ----------
function simulateMatch(homeIn, awayIn, seed) {
  const r = rng(seed);
  const H = mkTeam('home', homeIn), A = mkTeam('away', awayIn);
  const teams = { home: H, away: A };
  const opp = (T) => (T === H ? A : H);
  const events = [], shots = [];
  const s1 = 1 + Math.floor(r() * 4), s2 = 2 + Math.floor(r() * 5);
  const total = 90 + s1 + s2;
  let label = '1', minute = 1;
  const injuries = [];
  const ev = (type, T, o = {}) => events.push({ min: minute, label, type, team: T ? T.side : null, ...o });
  const wpick = (list, wf) => {
    let tot = 0; const ws = list.map((x) => { const w = Math.max(0.0001, wf(x)); tot += w; return w; });
    let u = r() * tot;
    for (let i = 0; i < list.length; i++) { u -= ws[i]; if (u <= 0) return list[i]; }
    return list[list.length - 1];
  };
  const field = (T) => T.onp.filter((x) => x.pos !== 'GK');
  const keeper = (T) => T.onp.find((x) => x.pos === 'GK');
  const gkQ = (T) => { const k = keeper(T); if (!k) return 22; const a = k.p.attrs; return ((a.gk_reflexes + a.gk_handling + a.gk_positioning + a.gk_diving) / 4) * (0.85 + 0.15 * (k.energy / 100)); };
  const nm = (pl) => pl.p.last_name;
  const finishSk = (pl) => 0.6 * pl.p.attrs.finishing + 0.2 * pl.p.attrs.shooting + 0.2 * pl.p.attrs.composure;
  const score = () => H.goals - A.goals;

  // --- core: resolve a shot. cq = base scoring chance before shooter/keeper skill.
  function shoot(T, shooter, cq, kind, extra = {}) {
    const D = opp(T);
    const sk = clamp(1 + (finishSk(shooter) - 60) / 100, 0.35, 1.6) * (kind === 'header' ? clamp(0.75 + shooter.p.attrs.heading / 160, 0.7, 1.3) : 1);
    const gk = clamp(1.25 - gkQ(D) / 260 - 0.0, 0.7, 1.25) * 1; // gk 65 -> ~1.0
    const gkF = clamp(1 - (gkQ(D) - 65) / 100, 0.65, 1.4);
    const pGoal = clamp(cq * sk * gkF * (kind === 'penalty' ? 1 : 1), 0.005, 0.92);
    T.st.shots++; shooter.s.shots++; T.st.xg += cq;
    const loc = extra.loc || { x: 50, y: 88 };
    const base = { player_id: shooter.p.id, x: Math.round(loc.x), y: Math.round(loc.y), xg: Math.round(cq * 100) / 100, kind };
    if (r() < pGoal) {
      T.goals++; T.st.sot++; shooter.s.sot++; shooter.s.goals++;
      for (const pl of D.onp) pl.s.conceded++;
      let assist = null;
      if (extra.creator && extra.creator !== shooter && r() < 0.78) { assist = extra.creator; assist.s.assists++; }
      const key = kind === 'penalty' ? 'goal_pen' : kind === 'freekick' ? 'goal_fk' : kind === 'header' ? 'goal_header' : 'goal';
      shots.push({ ...base, team: T.side, min: minute, result: 'goal' });
      ev('goal', T, { player_id: shooter.p.id, assist_id: assist ? assist.p.id : null, score: [H.goals, A.goals], text: fill(pickTxt(r, key), { p: nm(shooter) }), xg: base.xg });
      return 'goal';
    }
    const blockP = kind === 'penalty' || kind === 'freekick' ? 0 : 0.13;
    const saveP = kind === 'penalty' ? 0.55 : 0.27;
    const x = r();
    if (x < saveP) {
      T.st.sot++; shooter.s.sot++; D.st.saves++;
      const k = keeper(D); if (k) k.s.saves++;
      shots.push({ ...base, team: T.side, min: minute, result: 'saved' });
      ev('save', T, { player_id: shooter.p.id, keeper_id: k ? k.p.id : null, text: fill(pickTxt(r, kind === 'penalty' ? 'pen_save' : 'save'), { p: nm(shooter), k: k ? nm(k) : 'the keeper' }), xg: base.xg });
      return 'saved';
    }
    if (x < saveP + blockP) {
      T.st.blocked++;
      const bd = wpick(field(D), (z) => (ZONE_W[z.pos].d || 0.1) * z.p.attrs.tackling);
      shots.push({ ...base, team: T.side, min: minute, result: 'blocked' });
      ev('block', T, { player_id: shooter.p.id, text: fill(pickTxt(r, 'block'), { p: nm(shooter), d: nm(bd) }), xg: base.xg });
      return 'blocked';
    }
    shots.push({ ...base, team: T.side, min: minute, result: 'off' });
    ev('miss', T, { player_id: shooter.p.id, text: fill(pickTxt(r, kind === 'penalty' ? 'pen_miss' : 'miss'), { p: nm(shooter) }), xg: base.xg });
    return 'off';
  }
  const shooterPick = (T, wide) => wpick(field(T), (pl) => {
    const w = zw(pl);
    return (pl.p.attrs.finishing + pl.p.attrs.shooting) / 2 * ((w.a || 0) + 0.12) * (pl.instr === 'shoot_more' ? 1.5 : 1) * (wide && pl.pos === 'ST' ? 1.2 : 1);
  });
  const takerOn = (T, id, fallbackKey) => T.onp.find((x) => x.p.id === id && x.pos !== null) || wpick(field(T), (pl) => pl.p.attrs[fallbackKey]);

  function corner(T) {
    T.st.corners++;
    ev('corner', T, { text: fill(pickTxt(r, 'corner'), { t: T.name }) });
    if (r() < 0.5) {
      const taker = takerOn(T, T.setPieces.corner, 'crossing');
      const h = wpick(field(T).filter((x) => x !== taker), (pl) => pl.p.attrs.heading * pl.p.attrs.jumping * (['CB', 'ST'].includes(pl.pos) ? 1.8 : 1));
      shoot(T, h, 0.085 * clamp(taker.p.attrs.crossing / 65, 0.7, 1.3), 'header', { creator: taker, loc: { x: 42 + r() * 16, y: 91 + r() * 4 } });
    }
  }
  function freeKick(T, near) {
    const taker = takerOn(T, T.setPieces.fk, 'set_pieces');
    if (!near) return;
    ev('freekick', T, { text: fill(pickTxt(r, 'freekick'), { t: T.name }) });
    shoot(T, taker, 0.055 * clamp((taker.p.attrs.set_pieces + taker.p.attrs.long_shots) / 110, 0.6, 1.5), 'freekick', { loc: { x: 35 + r() * 30, y: 78 + r() * 6 } });
  }
  function penalty(T, fouler) {
    ev('penalty', T, { text: fill(pickTxt(r, 'penalty'), { t: T.name, d: nm(fouler) }) });
    const taker = takerOn(T, T.setPieces.pen, 'finishing');
    shoot(T, taker, 0.74 * clamp((taker.p.attrs.composure + taker.p.attrs.finishing) / 130, 0.75, 1.15), 'penalty', { loc: { x: 50, y: 89 } });
  }

  function givePlayerCard(T, pl, forceStraight) {
    if (pl.out) return;
    if (forceStraight) return sendOff(T, pl, 'red');
    pl.yc++; pl.s.yc++; T.st.yc++;
    if (pl.yc >= 2) { T.st.yc--; pl.s.yc--; return sendOff(T, pl, 'second_yellow'); }
    ev('yellow', T, { player_id: pl.p.id, text: fill(pickTxt(r, 'yellow'), { p: nm(pl) }) });
  }
  function sendOff(T, pl, key) {
    pl.s.rc = 1; pl.out = true; pl.minOff = minute; T.st.rc++;
    ev(key === 'red' ? 'red' : 'red', T, { player_id: pl.p.id, second_yellow: key === 'second_yellow', text: fill(pickTxt(r, key), { p: nm(pl) }) });
    T.onp = T.onp.filter((x) => x !== pl);
    fixKeeper(T);
  }
  function fixKeeper(T) {
    if (keeper(T)) { T.emergencyGK = false; return; }
    const bg = T.benchPlayers.find((p) => p.position === 'GK');
    if (bg && T.subsUsed < MAX_SUBS) {
      const sac = [...field(T)].sort((x, y) => y.rating0 * (ZONE_W[y.pos].a || 0) - x.rating0 * (ZONE_W[x.pos].a || 0))[0];
      if (sac) { substitute(T, sac, bg, 'GK'); return; }
    }
    T.emergencyGK = true;
  }
  function substitute(T, off, onP, posOverride) {
    const pos = posOverride || off.pos;
    T.onp = T.onp.filter((x) => x !== off);
    off.out = true; off.minOff = minute;
    T.benchPlayers = T.benchPlayers.filter((p) => p !== onP);
    const pl = { p: onP, pos, role: null, instr: null, rating0: F.ratingAt(onP, pos), energy: onP.fitness, started: false, minOn: minute, minOff: null, yc: 0, out: false,
      s: { goals: 0, assists: 0, shots: 0, sot: 0, saves: 0, tackles: 0, inter: 0, fouls: 0, yc: 0, rc: 0, conceded: 0, bonus: 0 } };
    T.onp.push(pl); T.everyone.push(pl); T.subsUsed++;
    ev('sub', T, { player_id: onP.id, off_id: off.p.id, text: fill(pickTxt(r, 'sub'), { t: T.name, on: nm(pl), off: nm(off) }) });
  }
  function considerSubs(T, t, diff) {
    if (T.subsUsed >= MAX_SUBS || !T.benchPlayers.length) return;
    const lead = T === H ? diff : -diff;
    const tired = field(T).filter((x) => x.energy < 58).sort((x, y) => x.energy - y.energy)[0];
    const bestBench = (grp) => T.benchPlayers.filter((p) => !grp || F.POS_GROUP[p.position] === grp).sort((x, y) => y.overall - x.overall)[0];
    if (tired && r() < 0.5) {
      const rep = bestBench(F.POS_GROUP[tired.pos]) || bestBench(null);
      if (rep && rep.position !== 'GK') return substitute(T, tired, rep);
    }
    if (t >= 70 && lead < 0 && r() < 0.35) { // chasing the game: bring on a forward for a defender
      const fw = bestBench('FWD'); const df = field(T).filter((x) => F.POS_GROUP[x.pos] === 'DEF' || x.pos === 'DM').sort((x, y) => x.rating0 - y.rating0)[0];
      if (fw && df) return substitute(T, df, fw, F.POS_GROUP[df.pos] === 'DEF' || df.pos === 'DM' ? 'ST' : df.pos);
    }
    if (t >= 75 && lead > 0 && r() < 0.35) { // protecting a lead: bring on a defender for a forward
      const dfb = bestBench('DEF'); const fw = field(T).filter((x) => F.POS_GROUP[x.pos] === 'FWD').sort((x, y) => x.rating0 - y.rating0)[0];
      if (dfb && fw) return substitute(T, fw, dfb, 'CB');
    }
  }
  function handleFoul(T) { // T committed the foul
    const D = opp(T);
    const fouler = wpick(field(T), (pl) => ((ZONE_W[pl.pos].d || 0.4) + (ZONE_W[pl.pos].m || 0) + 0.2) * (pl.yc > 0 ? 0.3 : 1));
    T.st.fouls++; fouler.s.fouls++;
    ev('foul', T, { player_id: fouler.p.id, text: fill(pickTxt(r, 'foul'), { p: nm(fouler) }) });
    const zoneRoll = r();
    const inBox = zoneRoll < 0.035, nearBox = zoneRoll < 0.2;
    const card = (inBox ? 0.3 : 0.15) * (0.8 + 0.1 * T.tac.tackling_intensity);
    if (r() < 0.003) givePlayerCard(T, fouler, true);
    else if (r() < card * (fouler.yc > 0 ? 0.5 : 1)) givePlayerCard(T, fouler, false);
    if (inBox) penalty(D, fouler);
    else if (nearBox) freeKick(D, true);
  }

  // kick-off
  label = '1'; ev('kickoff', null, { text: pickTxt(r, 'kickoff') });
  let possH = 0, possA = 0, htDone = false;

  for (let t = 1; t <= total; t++) {
    if (t <= 45) { minute = t; label = String(t); }
    else if (t <= 45 + s1) { minute = 45; label = `45+${t - 45}`; }
    else { const u = t - s1; if (u <= 90) { minute = u; label = String(u); } else { minute = 90; label = `90+${u - 90}`; } }
    if (!htDone && t === 46 + s1) { htDone = true; ev('halftime', null, { text: pickTxt(r, 'halftime') }); ev('secondhalf', null, { text: pickTxt(r, 'secondhalf') }); }
    const diff = score();

    // 1. fatigue
    for (const T of [H, A]) {
      const pf = (PRESS[T.tac.pressing] === 0 ? 0.85 : PRESS[T.tac.pressing] === 1 ? 1 : PRESS[T.tac.pressing] === 2 ? 1.15 : 1.3) * (0.8 + 0.1 * T.tac.pressing_intensity);
      for (const pl of T.onp) {
        pl.energy -= 0.36 * (1.5 - (pl.p.attrs.stamina / 100) * 0.8) / 0.94 * (0.7 + 0.1 * T.tac.tempo) * pf * (0.9 + pl.p.attrs.work_rate / 500) * (T.tac.marking === 'man' ? 1.04 : 1);
        if (pl.energy < 0) pl.energy = 0;
      }
    }
    // 2. substitutions
    if (t > 50 && t % 5 === 0) { considerSubs(H, minute, diff); considerSubs(A, minute, diff); }

    // 3. possession
    const zH = zones(H), zA = zones(A);
    const mH = tacticMods(H, A, { t: minute, diff, fwdPaceA: fwdPace(H) });
    const mA = tacticMods(A, H, { t: minute, diff: -diff, fwdPaceA: fwdPace(A) });
    const midH = zH.m * mH.mid * 1.04, midA = zA.m * mA.mid;
    const ph = midH ** 2 / (midH ** 2 + midA ** 2);
    const homeHas = r() < ph;
    if (homeHas) { H.st.possTicks++; possH++; } else { A.st.possTicks++; possA++; }

    // 4. attacking sequence for the side in possession
    const T = homeHas ? H : A, D = opp(T), zT = homeHas ? zH : zA, zD = homeHas ? zA : zH, mT = homeHas ? mH : mA, mD = homeHas ? mA : mH;
    const lead = homeHas ? diff : -diff;
    const wasting = lead > 0 ? { never: 1, sometimes: 0.97, often: 0.93 }[T.tac.time_wasting] : 1;
    const ratio = clamp((zT.a * mT.att * (homeHas ? 1.03 : 1)) / (zD.d * mD.def), 0.6, 1.7);
    const pSeq = 0.31 * mT.tempo * wasting * ratio ** 0.4;
    if (r() < pSeq) {
      const pWing = clamp(0.38 + 0.07 * (T.tac.width - 3) + (T.tac.approach === 'wing_play' ? 0.15 : 0) - (T.tac.approach === 'central' ? 0.1 : 0), 0.15, 0.8);
      const route = r() < pWing ? 'wing' : 'central';
      const side = route === 'wing' ? (r() < 0.5 ? 'left' : 'right') : 'central';
      T.st.channels[side]++;
      const stopP = 0.3 * clamp(zD.d * mD.def / (zT.a * mT.att), 0.6, 1.5) ** 0.8 * (1 + 0.03 * (D.tac.tackling_intensity - 3));
      if (r() < stopP) {
        const isTackle = r() < 0.55;
        const def = wpick(field(D), (z) => (ZONE_W[z.pos].d || 0.2) * (isTackle ? z.p.attrs.tackling : z.p.attrs.anticipation));
        if (isTackle) { def.s.tackles++; D.st.tackles++; } else { def.s.inter++; D.st.inter++; }
        if (r() < 0.22) ev(isTackle ? 'tackle' : 'inter', D, { player_id: def.p.id, text: fill(pickTxt(r, isTackle ? 'tackle' : 'inter'), { p: nm(def) }) });
        if (isTackle && r() < 0.09) handleFoul(D);
      } else if (r() < (D.tac.offside_trap ? 0.1 : 0.04)) {
        const off = wpick(field(T), (z) => (ZONE_W[z.pos].a || 0.05));
        T.st.offsides++;
        if (D.tac.offside_trap && r() < 0.28 * (fwdPace(T) / 70)) { // trap beaten: clean through on goal
          const sh = shooterPick(T, false);
          ev('chance', T, { player_id: sh.p.id, text: fill(pickTxt(r, 'build_trap'), { p: nm(sh) }) });
          shoot(T, sh, 0.33 * mT.q, 'open', { loc: { x: 44 + r() * 12, y: 90 + r() * 5 } });
        } else ev('offside', T, { player_id: off.p.id, text: fill(pickTxt(r, 'offside'), { p: nm(off) }) });
      } else {
        const counter = T.tac.approach === 'counter' && r() < 0.3;
        let cq = (route === 'central' ? 0.1 : 0.086) * mT.q * ratio ** 0.65;
        if (route === 'wing') cq *= (T.tac.approach === 'wing_play' ? 1.05 : 1) * (1 + 0.02 * (D.tac.compactness - 3)) * (1 + 0.015 * (T.tac.width - 3));
        else cq *= (T.tac.approach === 'central' ? 1.05 : 1) * (1 - 0.025 * (D.tac.compactness - 3));
        if (counter) cq *= 1.35;
        const sh = shooterPick(T, route === 'wing');
        const cr = wpick(field(T).filter((x) => x !== sh), (z) => (z.p.attrs.passing + z.p.attrs.vision + (route === 'wing' ? z.p.attrs.crossing : z.p.attrs.dribbling)) * (z.instr === 'cross_more' && route === 'wing' ? 1.4 : 1) * ((ZONE_W[z.pos].m || 0) + (ZONE_W[z.pos].a || 0) + 0.1));
        const bk = counter ? 'build_counter' : route === 'central' ? 'build_central' : side === 'left' ? 'build_left' : 'build_right';
        ev('chance', T, { player_id: sh.p.id, creator_id: cr.p.id, text: fill(pickTxt(r, bk), { t: T.name, c: nm(cr), p: nm(sh) }) });
        const x = route === 'central' ? 40 + r() * 20 : side === 'left' ? 18 + r() * 14 : 68 + r() * 14;
        const res = shoot(T, sh, cq, 'open', { creator: cr, loc: { x, y: 78 + r() * 17 } });
        if ((res === 'saved' || res === 'blocked') && r() < 0.28) corner(T);
      }
    }

    // 5. fouls and injuries
    if (r() < 0.215) {
      const wH = (1 - ph) * (0.7 + 0.1 * H.tac.tackling_intensity), wA = ph * (0.7 + 0.1 * A.tac.tackling_intensity) * 1.05;
      handleFoul(r() < wH / (wH + wA) ? H : A);
    }
    if (r() < 0.0035) {
      const T2 = r() < 0.5 ? H : A;
      const cand = wpick(T2.onp, (pl) => 1 + (100 - pl.energy) / 40);
      if (cand) {
        cand.injury_days = r() < 0.55 ? 5 + Math.floor(r() * 10) : r() < 0.67 ? 15 + Math.floor(r() * 21) : 36 + Math.floor(r() * 65);
        injuries.push({ player_id: cand.p.id, team: T2.side, days: cand.injury_days, min: minute });
        const rep = T2.benchPlayers.filter((p) => (cand.pos === 'GK') === (p.position === 'GK')).sort((x, y) => (F.POS_GROUP[y.position] === F.POS_GROUP[cand.pos]) - (F.POS_GROUP[x.position] === F.POS_GROUP[cand.pos]) || y.overall - x.overall)[0];
        if (rep && T2.subsUsed < MAX_SUBS) {
          ev('injury', T2, { player_id: cand.p.id, text: fill(pickTxt(r, 'injury'), { p: nm(cand) }) });
          substitute(T2, cand, rep);
        } else ev('injury', T2, { player_id: cand.p.id, text: fill(pickTxt(r, 'injury_played_on'), { p: nm(cand) }) });
        cand.injured = true;
        if (cand.pos === 'GK' && !rep) T2.emergencyGK = false;
      }
    }
  }
  minute = 90; label = `90+${s2}`;
  ev('fulltime', null, { text: pickTxt(r, 'fulltime'), score: [H.goals, A.goals] });
  for (const T of [H, A]) for (const pl of T.everyone) { if (pl.minOff == null) pl.minOff = 90; }

  // ---------- results ----------
  const hg = H.goals, ag = A.goals;
  const players = [];
  for (const T of [H, A]) {
    const won = T === H ? hg > ag : ag > hg, lost = T === H ? hg < ag : ag < hg;
    const conceded = T === H ? ag : hg;
    for (const pl of T.everyone) {
      let mins = Math.max(0, (pl.minOff == null ? 90 : pl.minOff) - (pl.minOn || 0));
      if (!pl.started) mins = Math.max(1, mins); // a late sub (even in stoppage time) still played and can still score
      const s = pl.s;
      let rt = 6.0 + s.goals * 0.9 + s.assists * 0.55 + s.saves * 0.2 + s.sot * 0.06 + s.shots * 0.03 + s.tackles * 0.07 + s.inter * 0.07 - s.yc * 0.3 - s.rc * 1.8 - s.fouls * 0.03;
      rt += won ? 0.35 : lost ? -0.25 : 0;
      const grp = F.POS_GROUP[pl.pos];
      if ((grp === 'GK' || grp === 'DEF') && mins >= 60 && conceded === 0) rt += 0.4;
      if (grp === 'GK') rt -= s.conceded * 0.3; else if (grp === 'DEF') rt -= s.conceded * 0.18;
      rt += (r() + r() - 1) * 0.35;
      rt = Math.round(clamp(rt, 3, 10) * 10) / 10;
      players.push({ player_id: pl.p.id, team: T.side, name: `${pl.p.first_name} ${pl.p.last_name}`, pos: pl.pos, started: pl.started, minutes: mins,
        goals: s.goals, assists: s.assists, shots: s.shots, sot: s.sot, saves: s.saves, tackles: s.tackles, inter: s.inter, yc: s.yc, rc: s.rc, rating: rt, energy: Math.round(pl.energy),
        injury_days: pl.injured ? pl.injury_days : 0 });
    }
  }
  const motm = players.reduce((a, b) => (b.rating > a.rating ? b : a), players[0]);
  const totalPoss = Math.max(1, possH + possA);
  const passRate = { short: 6.2, mixed: 5.4, direct: 4.4, long: 3.6 };
  const stats = {};
  for (const T of [H, A]) {
    const ticks = T.st.possTicks;
    const passes = Math.round(ticks * passRate[T.tac.passing] * (0.9 + 0.05 * T.tac.tempo));
    const acc = clamp(0.64 + (avgAttr(T.onp, 'passing') - 50) / 220 - (T.tac.passing === 'long' ? 0.1 : T.tac.passing === 'direct' ? 0.05 : 0), 0.5, 0.93);
    const ch = T.st.channels, chT = Math.max(1, ch.left + ch.central + ch.right);
    stats[T.side] = { goals: T.goals, possession: Math.round((ticks / totalPoss) * 100), shots: T.st.shots, shots_on_target: T.st.sot, blocked: T.st.blocked, corners: T.st.corners, fouls: T.st.fouls,
      yellow_cards: T.st.yc, red_cards: T.st.rc, offsides: T.st.offsides, passes, pass_accuracy: Math.round(acc * 100), tackles: T.st.tackles, interceptions: T.st.inter, saves: T.st.saves,
      xg: Math.round(T.st.xg * 100) / 100, chemistry: T.chemPct, subs_used: T.subsUsed,
      attack_channels: { left: Math.round((ch.left / chT) * 100), central: Math.round((ch.central / chT) * 100), right: Math.round((ch.right / chT) * 100) } };
  }
  stats.home.possession = 100 - stats.away.possession;
  const lineups = {};
  for (const T of [H, A]) lineups[T.side] = { formation: T.formation, name: T.name, starters: players.filter((p) => p.team === T.side && p.started).map((p) => p.player_id), subs_used: players.filter((p) => p.team === T.side && !p.started).map((p) => p.player_id), bench_unused: T.benchPlayers.map((p) => p.id) };
  return { home_goals: hg, away_goals: ag, events, stats, players, shots, injuries, motm_player_id: motm.player_id, lineups, stoppage: [s1, s2] };
}

// Variety for computer-controlled managers, deterministic per club + season.
function aiTactics(club, seed, relativeStrength) {
  const r = rng((seed ^ Math.imul(club.id, 40503)) >>> 0);
  const pick = (a) => a[Math.floor(r() * a.length)];
  const strong = relativeStrength > 0.04, weak = relativeStrength < -0.04;
  const t = { ...F.DEFAULT_TACTICS };
  t.mentality = strong ? pick(['balanced', 'attacking', 'attacking']) : weak ? pick(['defensive', 'balanced', 'defensive']) : pick(['balanced', 'balanced', 'attacking', 'defensive']);
  t.approach = pick(['possession', 'counter', 'wing_play', 'central', 'direct']);
  t.passing = { possession: 'short', counter: 'direct', wing_play: 'mixed', central: 'mixed', direct: 'long' }[t.approach];
  t.pressing = strong ? pick(['mid_block', 'high_press']) : weak ? pick(['low_block', 'mid_block']) : pick(['mid_block', 'mid_block', 'high_press']);
  t.tempo = clamp(3 + Math.floor(r() * 3) - 1, 1, 5); t.width = clamp(3 + Math.floor(r() * 3) - 1, 1, 5);
  t.defensive_line = clamp(3 + (strong ? 1 : weak ? -1 : 0) + Math.floor(r() * 3) - 1, 1, 5); t.compactness = clamp(3 + Math.floor(r() * 3) - 1, 1, 5);
  t.offside_trap = r() < 0.25 && t.defensive_line >= 4;
  return t;
}

module.exports = { simulateMatch, aiTactics, zones, mkTeam, MAX_SUBS };
