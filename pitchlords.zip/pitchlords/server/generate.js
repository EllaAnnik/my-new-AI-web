'use strict';
// Seeded procedural generation of fictional clubs. Same seed => same world.

function rng(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const pick = (r, arr) => arr[Math.floor(r() * arr.length)];
const shuffle = (r, arr) => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

const CITIES = ['Aldermoor','Brackenford','Castlewick','Dunmere','Eastholm','Falconridge','Greywater','Harrowgate','Ironbridge','Jasperton','Kingsmead','Lowenport','Marlowe','Northcliff','Oakhaven','Pennywell','Queensferry','Redhaven','Stonebridge','Thornbury','Underhill','Valemouth','Westbourne','Yarrowdale','Ashcombe','Blackmoor','Cinderfield','Driftwood','Elmstead','Foxbury','Glenhollow','Hartwell','Ivybridge','Kestrel Bay','Larkspur','Millbrook','Netherby','Ostenford','Pinecrest','Ravenshaw'];
const SUFFIX = ['United','City','Rovers','Athletic','Town','Wanderers','Albion','Rangers','Borough','Argyle','Dynamo','Sporting'];
const COLORS = ['#c8102e','#0057b8','#f2c200','#0b8a42','#6b2fa3','#ff6a13','#00a3a3','#111827','#e11d74','#7a1f2b','#2e86de','#8bc34a','#f5f5f5','#374151'];
const FIRST = ['Marco','Dario','Tomas','Elias','Luca','Kofi','Rafael','Stefan','Idris','Mateo','Hugo','Jonas','Viktor','Amadou','Nico','Felix','Declan','Emre','Oskar','Tariq'];
const LAST = ['Valdez','Okafor','Lindqvist','Moreau','Kowalski','Hartmann','Silva','Adeyemi','Novak','Brennan','Castellano','Ibrahim','Petrov','Dubois','Rossi','Mbeki','Fischer','Costa','Haddad','Larsen'];

function generateClubs(seed, count) {
  const r = rng(seed);
  const cities = shuffle(r, CITIES).slice(0, count);
  const used = new Set();
  const clubs = cities.map((city, i) => {
    let name;
    do { name = `${city} ${pick(r, SUFFIX)}`; } while (used.has(name));
    used.add(name);
    const [c1, c2] = shuffle(r, COLORS);
    // Spread reputation so the league has big and small clubs.
    const reputation = Math.max(20, Math.min(95, Math.round(90 - (i * 60) / Math.max(1, count - 1) + (r() - 0.5) * 10)));
    const cap = Math.round((8000 + reputation * 650 + r() * 3000) / 100) * 100;
    const balance = Math.round((1.5 + reputation * 0.14 + r()) * 1_000_000 / 10_000) * 10_000;
    return {
      name,
      short_name: city.replace(/[^A-Za-z ]/g, '').split(' ').map((w) => w[0]).join('').padEnd(3, city[1] || 'X').slice(0, 3).toUpperCase(),
      city,
      color1: c1,
      color2: c2,
      reputation,
      stadium_name: `${pick(r, ['','Victoria ','Memorial ','Riverside ','Highfield '])}${pick(r, ['Park','Ground','Arena','Stadium'])}`.replace(/^ /, '') || 'Home Ground',
      stadium_capacity: cap,
      balance,
      ai_manager_name: `${pick(r, FIRST)} ${pick(r, LAST)}`,
    };
  });
  return shuffle(r, clubs);
}

module.exports = { generateClubs, rng };
