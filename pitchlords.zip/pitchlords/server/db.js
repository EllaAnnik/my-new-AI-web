'use strict';
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

// Ordered migrations. Never edit an applied one; append a new entry.
const MIGRATIONS = [
  `
  CREATE TABLE users (
    id            INTEGER PRIMARY KEY,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    pass_hash     TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'player' CHECK (role IN ('player','moderator','admin')),
    status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
    suspended_reason TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE sessions (
    id          INTEGER PRIMARY KEY,
    token_hash  TEXT NOT NULL UNIQUE,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    expires_at  TEXT NOT NULL
  );
  CREATE INDEX idx_sessions_user ON sessions(user_id);

  CREATE TABLE worlds (
    id          INTEGER PRIMARY KEY,
    code        TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    seed        INTEGER NOT NULL,
    max_clubs   INTEGER NOT NULL CHECK (max_clubs BETWEEN 4 AND 40),
    status      TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','closed')),
    season      INTEGER NOT NULL DEFAULT 1,
    game_date   TEXT NOT NULL DEFAULT '2026-07-01',
    created_by  INTEGER REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE clubs (
    id               INTEGER PRIMARY KEY,
    world_id         INTEGER NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
    name             TEXT NOT NULL,
    short_name       TEXT NOT NULL,
    city             TEXT NOT NULL,
    color1           TEXT NOT NULL,
    color2           TEXT NOT NULL,
    reputation       INTEGER NOT NULL CHECK (reputation BETWEEN 1 AND 100),
    stadium_name     TEXT NOT NULL,
    stadium_capacity INTEGER NOT NULL,
    balance          INTEGER NOT NULL,
    ai_manager_name  TEXT NOT NULL,
    manager_user_id  INTEGER REFERENCES users(id),
    claimed_at       TEXT,
    UNIQUE (world_id, name)
  );
  -- One club per human per world, enforced by the database itself.
  CREATE UNIQUE INDEX uq_one_club_per_user_world ON clubs(world_id, manager_user_id) WHERE manager_user_id IS NOT NULL;
  CREATE INDEX idx_clubs_world ON clubs(world_id);

  CREATE TABLE notifications (
    id         INTEGER PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    world_id   INTEGER REFERENCES worlds(id) ON DELETE CASCADE,
    kind       TEXT NOT NULL,
    title      TEXT NOT NULL,
    body       TEXT NOT NULL DEFAULT '',
    read       INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX idx_notif_user ON notifications(user_id, read, id);

  CREATE TABLE audit_log (
    id         INTEGER PRIMARY KEY,
    actor_id   INTEGER REFERENCES users(id),
    action     TEXT NOT NULL,
    target     TEXT,
    detail     TEXT,
    ip         TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  `,
  // Phase 2: players, lineups, tactics
  `
  CREATE TABLE players (
    id               INTEGER PRIMARY KEY,
    world_id         INTEGER NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
    club_id          INTEGER REFERENCES clubs(id) ON DELETE SET NULL,
    first_name       TEXT NOT NULL,
    last_name        TEXT NOT NULL,
    age              INTEGER NOT NULL CHECK (age BETWEEN 15 AND 45),
    nationality      TEXT NOT NULL,
    position         TEXT NOT NULL,
    height_cm        INTEGER NOT NULL,
    foot             TEXT NOT NULL CHECK (foot IN ('left','right','both')),
    shirt_number     INTEGER,
    contract_expires INTEGER NOT NULL,
    wage             INTEGER NOT NULL,
    value            INTEGER NOT NULL,
    overall          INTEGER NOT NULL CHECK (overall BETWEEN 1 AND 100),
    potential        INTEGER NOT NULL CHECK (potential BETWEEN 1 AND 100),
    attrs            TEXT NOT NULL,
    fitness          INTEGER NOT NULL DEFAULT 100 CHECK (fitness BETWEEN 0 AND 100),
    morale           INTEGER NOT NULL DEFAULT 70 CHECK (morale BETWEEN 0 AND 100),
    injured_until    TEXT,
    suspended_matches INTEGER NOT NULL DEFAULT 0,
    is_youth         INTEGER NOT NULL DEFAULT 0,
    transfer_listed  INTEGER NOT NULL DEFAULT 0,
    UNIQUE (club_id, shirt_number)
  );
  CREATE INDEX idx_players_club ON players(club_id);
  CREATE INDEX idx_players_world ON players(world_id);
  -- Database-level guarantee that a player can never sit in a club of another world.
  CREATE TRIGGER players_world_ins BEFORE INSERT ON players
  WHEN NEW.club_id IS NOT NULL AND (SELECT world_id FROM clubs WHERE id = NEW.club_id) != NEW.world_id
  BEGIN SELECT RAISE(ABORT, 'player/club world mismatch'); END;
  CREATE TRIGGER players_world_upd BEFORE UPDATE OF club_id, world_id ON players
  WHEN NEW.club_id IS NOT NULL AND (SELECT world_id FROM clubs WHERE id = NEW.club_id) != NEW.world_id
  BEGIN SELECT RAISE(ABORT, 'player/club world mismatch'); END;

  CREATE TABLE lineups (
    club_id          INTEGER PRIMARY KEY REFERENCES clubs(id) ON DELETE CASCADE,
    formation        TEXT NOT NULL,
    slots            TEXT NOT NULL,
    bench            TEXT NOT NULL,
    captain_id       INTEGER REFERENCES players(id) ON DELETE SET NULL,
    penalty_taker_id  INTEGER REFERENCES players(id) ON DELETE SET NULL,
    freekick_taker_id INTEGER REFERENCES players(id) ON DELETE SET NULL,
    corner_taker_id   INTEGER REFERENCES players(id) ON DELETE SET NULL,
    updated_at       TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE tactics (
    club_id    INTEGER PRIMARY KEY REFERENCES clubs(id) ON DELETE CASCADE,
    data       TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  `,
  // Phase 2 (completion): append-only money ledger. clubs.balance is only ever changed through server/money.js.
  `
  CREATE TABLE finance_ledger (
    id            INTEGER PRIMARY KEY,
    club_id       INTEGER NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
    world_id      INTEGER NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
    amount        INTEGER NOT NULL,
    balance_after INTEGER NOT NULL,
    kind          TEXT NOT NULL,
    description   TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX idx_ledger_club ON finance_ledger(club_id, id);
  CREATE TRIGGER ledger_no_update BEFORE UPDATE ON finance_ledger BEGIN SELECT RAISE(ABORT, 'ledger is append-only'); END;
  `,
  // Phase 3: fixtures, matches, per-player match stats
  `
  ALTER TABLE worlds ADD COLUMN rounds_played INTEGER NOT NULL DEFAULT 0;

  CREATE TABLE fixtures (
    id           INTEGER PRIMARY KEY,
    world_id     INTEGER NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
    season       INTEGER NOT NULL,
    round        INTEGER NOT NULL,
    home_club_id INTEGER NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
    away_club_id INTEGER NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
    game_date    TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled','played')),
    home_goals   INTEGER,
    away_goals   INTEGER,
    match_id     INTEGER,
    CHECK (home_club_id != away_club_id),
    UNIQUE (world_id, season, home_club_id, away_club_id),   -- no duplicate fixtures
    UNIQUE (world_id, season, round, home_club_id),
    UNIQUE (world_id, season, round, away_club_id)
  );
  CREATE INDEX idx_fixtures_world ON fixtures(world_id, season, round);
  -- A club may play at most once per round, and both clubs must belong to the fixture's world.
  CREATE TRIGGER fixtures_valid BEFORE INSERT ON fixtures
  WHEN (SELECT world_id FROM clubs WHERE id = NEW.home_club_id) != NEW.world_id
    OR (SELECT world_id FROM clubs WHERE id = NEW.away_club_id) != NEW.world_id
    OR EXISTS (SELECT 1 FROM fixtures f WHERE f.world_id = NEW.world_id AND f.season = NEW.season AND f.round = NEW.round
               AND (f.home_club_id IN (NEW.home_club_id, NEW.away_club_id) OR f.away_club_id IN (NEW.home_club_id, NEW.away_club_id)))
  BEGIN SELECT RAISE(ABORT, 'invalid fixture'); END;

  CREATE TABLE matches (
    id             INTEGER PRIMARY KEY,
    world_id       INTEGER NOT NULL REFERENCES worlds(id) ON DELETE CASCADE,
    fixture_id     INTEGER NOT NULL UNIQUE REFERENCES fixtures(id) ON DELETE CASCADE,
    seed           INTEGER NOT NULL,
    home_club_id   INTEGER NOT NULL REFERENCES clubs(id),
    away_club_id   INTEGER NOT NULL REFERENCES clubs(id),
    home_goals     INTEGER NOT NULL,
    away_goals     INTEGER NOT NULL,
    events         TEXT NOT NULL,
    stats          TEXT NOT NULL,
    players        TEXT NOT NULL,
    shots          TEXT NOT NULL,
    lineups        TEXT NOT NULL,
    motm_player_id INTEGER,
    auto_lineup    TEXT NOT NULL DEFAULT '[]',
    created_at     TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX idx_matches_world ON matches(world_id);

  CREATE TABLE player_match_stats (
    match_id  INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
    world_id  INTEGER NOT NULL,
    season    INTEGER NOT NULL,
    player_id INTEGER NOT NULL,
    club_id   INTEGER NOT NULL,
    name      TEXT NOT NULL,
    started   INTEGER NOT NULL,
    minutes   INTEGER NOT NULL,
    goals     INTEGER NOT NULL,
    assists   INTEGER NOT NULL,
    shots     INTEGER NOT NULL,
    sot       INTEGER NOT NULL,
    yc        INTEGER NOT NULL,
    rc        INTEGER NOT NULL,
    rating    REAL NOT NULL,
    PRIMARY KEY (match_id, player_id)
  );
  CREATE INDEX idx_pms_world ON player_match_stats(world_id, season, player_id);
  `,
];

function open(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  const current = db.prepare('PRAGMA user_version').get().user_version;
  for (let v = current; v < MIGRATIONS.length; v++) {
    db.exec('BEGIN IMMEDIATE');
    try {
      db.exec(MIGRATIONS[v]);
      db.exec(`PRAGMA user_version = ${v + 1}`);
      db.exec('COMMIT');
    } catch (e) {
      db.exec('ROLLBACK');
      throw e;
    }
  }
  return db;
}

/** Run fn inside an immediate (write-locking) transaction; rolls back on throw. */
function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch (_) { /* already rolled back */ }
    throw e;
  }
}

module.exports = { open, tx };
