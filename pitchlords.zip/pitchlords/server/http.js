'use strict';
const crypto = require('node:crypto');

class HttpError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code || null;
  }
}
const bad = (m, c) => new HttpError(400, m, c);
const unauthorized = (m = 'Sign in required') => new HttpError(401, m, 'unauthorized');
const forbidden = (m = 'Not allowed') => new HttpError(403, m, 'forbidden');
const notFound = (m = 'Not found') => new HttpError(404, m, 'not_found');
const conflict = (m, c) => new HttpError(409, m, c || 'conflict');

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function readJson(req, limit = 100_000) {
  return new Promise((resolve, reject) => {
    if (req.method === 'GET' || req.method === 'HEAD') return resolve({});
    const ct = (req.headers['content-type'] || '').toLowerCase();
    if (!ct.startsWith('application/json')) {
      // Requiring JSON blocks simple cross-site form posts.
      const len = Number(req.headers['content-length'] || 0);
      if (len === 0) return resolve({});
      return reject(new HttpError(415, 'Content-Type must be application/json'));
    }
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'Body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(bad('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function send(res, status, body, headers = {}) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(data),
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(data);
}

/** Fixed-window in-memory rate limiter. Move to Redis when running >1 process. */
class RateLimiter {
  constructor() { this.buckets = new Map(); }
  hit(key, max, windowMs) {
    const now = Date.now();
    let b = this.buckets.get(key);
    if (!b || b.reset <= now) { b = { count: 0, reset: now + windowMs }; this.buckets.set(key, b); }
    b.count++;
    if (b.count > max) throw new HttpError(429, 'Too many requests, slow down', 'rate_limited');
  }
  sweep() {
    const now = Date.now();
    for (const [k, b] of this.buckets) if (b.reset <= now) this.buckets.delete(k);
  }
}

class Router {
  constructor() { this.routes = []; }
  add(method, pattern, handler, opts = {}) {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
    this.routes.push({ method, re, keys, handler, opts });
  }
  match(method, pathname) {
    for (const r of this.routes) {
      if (r.method !== method) continue;
      const m = r.re.exec(pathname);
      if (m) {
        const params = {};
        r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
        return { route: r, params };
      }
    }
    return null;
  }
}

const randomToken = () => crypto.randomBytes(32).toString('base64url');
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

module.exports = {
  HttpError, bad, unauthorized, forbidden, notFound, conflict,
  parseCookies, readJson, send, RateLimiter, Router, randomToken, sha256,
};
