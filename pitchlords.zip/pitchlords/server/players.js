'use strict';
// Seeded procedural player generation. Same world seed => same squads.
const F = require('./football');
const { rng } = require('./generate');

const NAT = {
  England: { f: ['Jack', 'Harry', 'Callum', 'Reece', 'Ollie', 'Mason', 'Jordan', 'Ben', 'Kyle', 'Declan', 'Tyler', 'Sam'], l: ['Whitaker', 'Holloway', 'Pritchard', 'Garrity', 'Ashworth', 'Cresswell', 'Marlow', 'Tennant', 'Hargreaves', 'Pickford', 'Larkin', 'Dobson'] },
  Spain: { f: ['Carlos', 'Mateo', 'Alvaro', 'Sergio', 'Iker', 'Hugo', 'Pablo', 'Adrian', 'Diego', 'Raul', 'Jorge', 'Dani'], l: ['Navarro', 'Ibarra', 'Quintero', 'Serrano', 'Villalba', 'Ortega', 'Cabello', 'Montoya', 'Lozano', 'Bermudez', 'Arroyo', 'Salcedo'] },
  Brazil: { f: ['Thiago', 'Lucas', 'Rafael', 'Gabriel', 'Mateus', 'Caio', 'Bruno', 'Vitor', 'Henrique', 'Leandro', 'Arthur', 'Joao'], l: ['Almeida', 'Barbosa', 'Cardoso', 'Dantas', 'Esteves', 'Figueira', 'Guedes', 'Macedo', 'Nogueira', 'Pacheco', 'Rezende', 'Teixeira'] },
  Nigeria: { f: ['Emeka', 'Chidi', 'Tunde', 'Segun', 'Kelechi', 'Obinna', 'Femi', 'Ikenna', 'Tobi', 'Ayo', 'Uche', 'Dayo'], l: ['Okonkwo', 'Adeleke', 'Balogun', 'Eze', 'Nwosu', 'Oladipo', 'Abiola', 'Chukwu', 'Ibe', 'Lawal', 'Obi', 'Yusuf'] },
  France: { f: ['Louis', 'Theo', 'Antoine', 'Maxime', 'Julien', 'Remi', 'Hugo', 'Baptiste', 'Quentin', 'Olivier', 'Yann', 'Corentin'], l: ['Lefevre', 'Girard', 'Marchand', 'Boucher', 'Delmas', 'Fontaine', 'Gauthier', 'Huet', 'Lacroix', 'Perrin', 'Roche', 'Vidal'] },
  Germany: { f: ['Jonas', 'Felix', 'Lukas', 'Niklas', 'Moritz', 'Tim', 'Leon', 'Florian', 'Jannik', 'Kai', 'Stefan', 'Matthias'], l: ['Bergmann', 'Dietrich', 'Eberle', 'Fuchs', 'Graf', 'Hoffmann', 'Kaiser', 'Lindner', 'Neumann', 'Rademacher', 'Schaefer', 'Vogel'] },
  Argentina: { f: ['Matias', 'Nicolas', 'Franco', 'Lautaro', 'Facundo', 'Emiliano', 'Santiago', 'Ezequiel', 'Tomas', 'Joaquin', 'Agustin', 'Bautista'], l: ['Aguero', 'Benitez', 'Correa', 'Dominguez', 'Escobar', 'Funes', 'Gimenez', 'Herrera', 'Medina', 'Paredes', 'Rojas', 'Sosa'] },
  Italy: { f: ['Marco', 'Matteo', 'Federico', 'Andrea', 'Davide', 'Simone', 'Lorenzo', 'Alessio', 'Riccardo', 'Fabio', 'Nicolo', 'Gianluca'], l: ['Barone', 'Conti', 'De Luca', 'Farina', 'Greco', 'Lombardi', 'Monti', 'Orsini', 'Ricci', 'Santoro', 'Valente', 'Zanetti'] },
};
const NATIONS = Object.keys(NAT);

// Squad template: [position, tier]. tier 0 = first choice, 1 = backup.
const TEMPLATE = [
  ['GK', 0], ['GK', 1], ['GK', 1],
  ['CB', 0], ['CB', 0], ['CB', 1], ['CB', 1],
  ['LB', 0], ['LB', 1], ['RB', 0], ['RB', 1],
  ['DM', 0], ['DM', 1], ['CM', 0], ['CM', 0], ['CM', 1],
  ['AM', 0], ['AM', 1], ['LW', 0], ['LW', 1], ['RW', 0], ['RW', 1],
  ['ST', 0], ['ST', 0], ['ST', 1],
];
const YOUTH_POS = ['CB', 'CM', 'ST', 'GK', 'RW'];

const PREF_NUMBERS = {
  GK: [1, 13, 12, 31, 40], DEF: [2, 3, 4, 5, 15, 16, 22, 23, 24, 26], MID: [6, 8, 10, 14, 17, 18, 20, 21, 28], FWD: [7, 9, 11, 19, 27, 29, 30],
};
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const int = (r, lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
const gauss = (r) => (r() + r() + r() - 1.5) / 1.5; // approx -1..1, bell-shaped

function makeAttrs(r, pos, target) {
  const w = F.weightsFor(pos);
  const a = {};
  for (const k of F.ALL_ATTRS) {
    const isKey = k in w;
    let base;
    if (k.startsWith('gk_')) base = pos === 'GK' ? target + gauss(r) * 7 : 4 + r() * 14;
    else if (pos === 'GK') base = 14 + r() * 28; // keepers are poor outfield
    else base = isKey ? target + 2 + gauss(r) * 8 : target - 9 + gauss(r) * 10;
    a[k] = clamp(Math.round(base), 1, 99);
  }
  // Pull key attributes so the position overall lands on the intended target.
  const diff = target - F.computeOverall(a, pos);
  for (const k in w) a[k] = clamp(a[k] + diff, 1, 99);
  return a;
}

function valueOf(overall, potential, age) {
  let v = 3000 * Math.exp(0.1 * overall);
  if (age <= 22) v *= 1 + (potential - overall) * 0.04;
  else if (age >= 31) v *= Math.max(0.2, 1 - (age - 30) * 0.12);
  return Math.max(10_000, Math.round(v / 10_000) * 10_000);
}
const wageOf = (value) => Math.max(500, Math.round(value / 1600 / 10) * 10);

function heightFor(r, pos) {
  const ranges = { GK: [184, 198], CB: [180, 195], LB: [170, 184], RB: [170, 184], DM: [174, 190], CM: [171, 187], AM: [169, 184], LM: [168, 182], RM: [168, 182], LW: [166, 181], RW: [166, 181], ST: [172, 195] };
  const [lo, hi] = ranges[pos];
  return int(r, lo, hi);
}

function generatePlayer(r, { pos, target, age, youth, year, usedNames }) {
  const nat = NATIONS[Math.floor(r() * NATIONS.length)];
  let first, last, tries = 0;
  do {
    first = NAT[nat].f[Math.floor(r() * 12)];
    last = NAT[nat].l[Math.floor(r() * 12)];
  } while (usedNames.has(first + last) && ++tries < 20);
  usedNames.add(first + last);
  const attrs = makeAttrs(r, pos, target);
  const overall = F.computeOverall(attrs, pos);
  let potential;
  if (youth) potential = clamp(overall + int(r, 12, 40), overall, 94);
  else if (age <= 27) potential = clamp(overall + Math.round((28 - age) * (0.3 + r() * 1.3)), overall, 97);
  else potential = overall;
  const value = valueOf(overall, potential, age);
  const leftBias = pos === 'LB' || pos === 'LW' || pos === 'LM';
  const fr = r();
  const foot = fr < 0.06 ? 'both' : (leftBias ? fr < 0.6 : fr > 0.72) ? 'left' : 'right';
  return {
    first_name: first, last_name: last, age, nationality: nat, position: pos, height_cm: heightFor(r, pos), foot,
    contract_expires: year + int(r, youth ? 2 : 1, 5), wage: youth ? 300 : wageOf(value), value, overall, potential, attrs,
    fitness: int(r, 92, 100), morale: int(r, 62, 80), is_youth: youth ? 1 : 0,
  };
}

function generateSquad(worldSeed, club, year) {
  const r = rng((worldSeed ^ Math.imul(club.id, 2654435761)) >>> 0);
  const mean = 40 + club.reputation * 0.38;
  const used = new Set();
  const players = [];
  for (const [pos, tier] of TEMPLATE) {
    let target = mean + (tier === 0 ? 4 : -4) + gauss(r) * 4;
    if (tier === 0 && r() < 0.06) target += 6; // occasional star
    target = clamp(Math.round(target), 30, 92);
    const age = tier === 0 ? int(r, 22, 33) : int(r, 19, 35);
    players.push(generatePlayer(r, { pos, target, age, youth: false, year, usedNames: used }));
  }
  for (let i = 0; i < 4; i++) {
    const pos = YOUTH_POS[int(r, 0, YOUTH_POS.length - 1)];
    const target = clamp(Math.round(mean - 20 + gauss(r) * 5), 22, 60);
    players.push(generatePlayer(r, { pos, target, age: int(r, 16, 18), youth: true, year, usedNames: used }));
  }
  assignNumbers(players);
  return players;
}

function assignNumbers(players) {
  const taken = new Set();
  const take = (list) => { for (const n of list) if (!taken.has(n)) { taken.add(n); return n; } return null; };
  for (const p of players) {
    const g = p.position === 'GK' ? 'GK' : F.POS_GROUP[p.position];
    let n = p.is_youth ? null : take(PREF_NUMBERS[g]);
    if (n == null) { n = 32; while (taken.has(n)) n++; taken.add(n); }
    p.shirt_number = n;
  }
}

const INSERT_SQL = `INSERT INTO players (world_id, club_id, first_name, last_name, age, nationality, position, height_cm, foot, shirt_number,
  contract_expires, wage, value, overall, potential, attrs, fitness, morale, is_youth)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;

function insertSquad(db, world, club) {
  const ins = db.prepare(INSERT_SQL);
  const year = Number(String(world.game_date).slice(0, 4));
  for (const p of generateSquad(world.seed, club, year)) {
    ins.run(world.id, club.id, p.first_name, p.last_name, p.age, p.nationality, p.position, p.height_cm, p.foot, p.shirt_number,
      p.contract_expires, p.wage, p.value, p.overall, p.potential, JSON.stringify(p.attrs), p.fitness, p.morale, p.is_youth);
  }
}

/** Create squads for any club that has none (new worlds, and worlds created before Phase 2). */
function ensureSquads(db, tx) {
  const clubs = db.prepare(
    `SELECT c.id, c.world_id, c.reputation FROM clubs c WHERE NOT EXISTS (SELECT 1 FROM players p WHERE p.club_id = c.id)`
  ).all();
  if (!clubs.length) return 0;
  tx(db, () => {
    for (const c of clubs) {
      const world = db.prepare('SELECT id, seed, game_date FROM worlds WHERE id = ?').get(c.world_id);
      insertSquad(db, world, c);
    }
  });
  return clubs.length;
}

module.exports = { generateSquad, insertSquad, ensureSquads, NATIONS };
