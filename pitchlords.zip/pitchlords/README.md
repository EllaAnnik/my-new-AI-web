# Pitchlords

Persistent multiplayer football-management game (original IP, fictional clubs). See `docs/ARCHITECTURE.md`.

## Run
Requires Node.js >= 22.13 (uses built-in `node:sqlite`; no npm install needed).

```
npm start          # http://localhost:3000  (PORT=… to change)
npm test           # backend test suite
```
The first account registered becomes the administrator. Data lives in `data/pitchlords.db`.
Set `COOKIE_SECURE=1` when serving over HTTPS.

## Status
**Phase 1 (foundation) - done and tested.** Accounts (scrypt, hashed server-side sessions, rate limits, CSRF origin check), Game Worlds (create/browse/join/resign), procedural clubs, race-safe club claiming, world isolation (DB trigger + unique indexes), notifications + live SSE push, admin suspension with audit log.

**Phase 2 (football management) - done and tested.** Seeded player database (31 attributes, position-specific overall, potential, value, wages), 25 senior players + 4 academy players per club, squad table with filters/sorting/detail, 10 formations, interactive pitch lineup editor, roles, player instructions, captain and set-piece takers, full team instructions (mentality, passing, pressing, marking, approach, sliders, offside trap, overlaps), youth promotion, transfer-listing, contract renewal and release with an append-only finance ledger. Other managers see only public player data.

**Phase 3 (match engine and league) - done and tested (53 backend tests + browser check).** Seeded minute-by-minute match engine (possession, chances, shots with xG, fouls, cards, injuries, substitutions, stoppage time, ratings, man of the match) in which formation, roles, mentality, pressing, line height, tempo, chemistry, energy and morale all affect the result. Double round-robin fixture generator with DB-enforced integrity, league table with form, results by round, top scorers/assists/ratings, club schedule, and a Match centre (commentary replay with speed control, stats, lineups and ratings, shot map). Rounds are played in one atomic, double-submit-safe transaction: fitness, morale, injuries and 2-match red-card bans carry over; clubs without a valid lineup get an assistant-manager pick. Until the Phase 5 world clock exists, the world's creator (or an admin) advances rounds from Competitions.

**Not built yet** (nav items are disabled and tagged with their phase): transfers/negotiations, scouting, finance income and expenses (P4), cups, promotion/relegation, training, season rollover and the automatic world clock (P5), messaging, rankings (P6), load/security hardening and deployment (P7).

Honest Phase 3 limits: matches are simulated instantly on the server and the Match centre *replays* the events (no live in-match tactical changes); only red cards cause bans (no yellow-card accumulation yet); the "heatmap" is a shot map plus attack-channel percentages.

## Known limitations
- SQLite instead of PostgreSQL and vanilla JS instead of React/Next/Tailwind, because package installs are blocked in the build environment. SQL is isolated and portable; see ARCHITECTURE.md §1.
- Rate limiting and SSE hub are in-memory (single process). Multi-process needs Redis or similar.
